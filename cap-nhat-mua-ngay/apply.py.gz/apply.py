#!/usr/bin/env python3
"""MENS STORE: direct single-product checkout, independent of saved cart."""
from pathlib import Path
import sys, tempfile, shutil, os, re

root = Path(sys.argv[1] if len(sys.argv) > 1 else '/workspaces/mens-store/mens-store').resolve()
if not (root/'pom.xml').is_file() or not (root/'compose.yaml').is_file():
    raise SystemExit('Khong tim thay du an: '+str(root))
J='src/main/java/com/example/mens_store/'
T='src/main/resources/templates/'
A='src/main/resources/static/assets/'
TEST='src/test/java/com/example/mens_store/'
pending={}
def read(p):
    return pending[p] if p in pending else (root/p).read_text(encoding='utf-8')
def save(p,s):
    f=root/p
    if f.is_file() and f.read_text(encoding='utf-8')==s:
        pending.pop(p,None)
    else: pending[p]=s
def replace(p,old,new):
    s=read(p)
    if new in s: return
    if s.count(old)!=1: raise SystemExit('Khong khop phien ban: '+p+'. Chua ghi file nao.')
    save(p,s.replace(old,new,1))
def add(p,s):
    if (root/p).exists() and read(p)!=s: raise SystemExit('File da ton tai voi noi dung khac: '+p)
    save(p,s)
def region(p,start,end,new):
    s=read(p)
    if new in s: return
    if s.count(start)!=1 or end not in s[s.index(start):]: raise SystemExit('Khong khop phien ban: '+p)
    a=s.index(start); b=s.index(end,a)
    save(p,s[:a]+new+s[b:])

# The existing security filter already protects all /dat-hang/** routes.
security=read(J+'config/SecurityConfig.java')
if '"/dat-hang", "/dat-hang/**"' not in security or '.hasRole("CUSTOMER")' not in security:
    raise SystemExit('Khong xac nhan duoc phan quyen khach hang. Chua ghi file nao.')

p=J+'service/OrderService.java'
replace(p,'''            Map<Integer, Integer> cart, Long accountId) {
        if (accountId == null)''','''            Map<Integer, Integer> cart, Long accountId) {
        return placeInternal(form, cart, accountId, true);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public OrderReceipt placeDirect(CheckoutForm form, int productId, int quantity, Long accountId) {
        if (productId <= 0 || quantity < 1 || quantity > CartService.MAX_QUANTITY)
            throw new IllegalArgumentException("Sản phẩm hoặc số lượng không hợp lệ");
        return placeInternal(form, Map.of(productId, quantity), accountId, false);
    }

    private OrderReceipt placeInternal(CheckoutForm form, Map<Integer, Integer> cart,
            Long accountId, boolean fromCart) {
        if (accountId == null)''')
replace(p,'        cart = carts.valuesForUpdate(accountId);','        if (fromCart) cart = carts.valuesForUpdate(accountId);')
replace(p,'        carts.clear(accountId);','        if (fromCart) carts.clear(accountId);')

# Direct order uses a separate server-side, account-bound single-use checkout token.
add(J+'controller/DirectCheckoutController.java','''package com.example.mens_store.controller;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.example.mens_store.model.*;
import com.example.mens_store.repository.ShopRepository;
import com.example.mens_store.service.*;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/dat-hang/mua-ngay")
public class DirectCheckoutController {
    private static final String KEY = "DIRECT_CHECKOUT_SELECTION";
    private static final long MAX_AGE = 30 * 60 * 1000L;
    private record Selection(long owner, int id, int quantity, String token, long createdAt) {}
    private final ShopRepository shop;
    private final OrderService orders;
    private final CustomerAccountService customers;
    private final BankTransferService transfers;

    public DirectCheckoutController(ShopRepository shop, OrderService orders,
            CustomerAccountService customers, BankTransferService transfers) {
        this.shop = shop; this.orders = orders; this.customers = customers; this.transfers = transfers;
    }

    private CustomerAccount account(Authentication auth) {
        if (auth == null || !auth.isAuthenticated() || auth.getAuthorities().stream()
                .noneMatch(a -> "ROLE_CUSTOMER".equals(a.getAuthority())))
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        return customers.findAuthenticatedAccount(auth).filter(CustomerAccount::active)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
    }

    private CartItem item(int id, int quantity) {
        if (id <= 0 || quantity < 1 || quantity > CartService.MAX_QUANTITY)
            throw new IllegalArgumentException("Số lượng phải từ 1 đến 99");
        Product product = shop.activeById(id)
                .orElseThrow(() -> new IllegalArgumentException("Sản phẩm không còn được bán"));
        if (product.stock() < quantity || product.price() <= 0)
            throw new IllegalArgumentException("Sản phẩm không đủ tồn kho hoặc giá chưa hợp lệ");
        return new CartItem(product, quantity);
    }

    private void populate(Model model, Selection selected, CartItem item) {
        model.addAttribute("directPurchase", true);
        model.addAttribute("directProductId", selected.id());
        model.addAttribute("checkoutToken", selected.token());
        model.addAttribute("items", List.of(item));
        model.addAttribute("total", item.subtotal());
        model.addAttribute("transferConfigured", transfers.isConfigured());
        model.addAttribute("bankAccount", transfers.getBankAccount());
        model.addAttribute("bankName", transfers.getBankName());
    }

    // The shared quantity form submits here; no cart or order mutation occurs.
    @PostMapping("/bat-dau")
    public String start(@RequestParam int id, @RequestParam(defaultValue="1") int quantity,
            Authentication auth, RedirectAttributes redirect) {
        account(auth);
        redirect.addAttribute("id", id);
        redirect.addAttribute("quantity", quantity);
        return "redirect:/dat-hang/mua-ngay";
    }

    @GetMapping
    public String show(@RequestParam int id, @RequestParam(defaultValue="1") int quantity,
            HttpSession session, Model model, Authentication auth, RedirectAttributes flash) {
        CustomerAccount account = account(auth);
        try {
            CartItem selectedItem = item(id, quantity);
            Selection selected = new Selection(account.id(), id, quantity, UUID.randomUUID().toString(), System.currentTimeMillis());
            synchronized (session) { session.setAttribute(KEY, selected); }
            CheckoutForm form = new CheckoutForm();
            form.setFullName(account.fullName()); form.setPhone(account.phone());
            form.setEmail(account.email()); form.setAddress(account.address());
            model.addAttribute("checkoutForm", form);
            populate(model, selected, selectedItem);
            return "checkout";
        } catch (IllegalArgumentException | ArithmeticException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
            return backToProduct(id);
        }
    }

    @PostMapping
    public String place(@Valid @ModelAttribute("checkoutForm") CheckoutForm form, BindingResult errors,
            @RequestParam(required=false) String checkoutToken, HttpSession session, Model model,
            Authentication auth, RedirectAttributes flash) {
        CustomerAccount account = account(auth);
        synchronized (session) {
            if (!(session.getAttribute(KEY) instanceof Selection selected)
                    || selected.owner() != account.id() || !selected.token().equals(checkoutToken)
                    || System.currentTimeMillis() - selected.createdAt() > MAX_AGE) {
                flash.addFlashAttribute("error", "Phiên mua ngay đã hết hạn hoặc đã sử dụng. Vui lòng chọn lại sản phẩm.");
                return "redirect:/san-pham";
            }
            try {
                CartItem selectedItem = item(selected.id(), selected.quantity());
                populate(model, selected, selectedItem);
                if (errors.hasErrors()) return "checkout";
                if ("CHUYEN_KHOAN".equals(form.getPaymentMethod()) && !transfers.isConfigured()) {
                    model.addAttribute("checkoutError", "Chuyển khoản chưa sẵn sàng. Vui lòng chọn COD.");
                    return "checkout";
                }
                OrderReceipt receipt = orders.placeDirect(form, selected.id(), selected.quantity(), account.id());
                session.removeAttribute(KEY);
                return "redirect:/tai-khoan/don-hang/" + receipt.code();
            } catch (IllegalArgumentException | ArithmeticException ex) {
                try {
                    populate(model, selected, item(selected.id(), selected.quantity()));
                    model.addAttribute("checkoutError", ex.getMessage());
                    return "checkout";
                } catch (IllegalArgumentException | ArithmeticException unavailable) {
                    session.removeAttribute(KEY);
                    flash.addFlashAttribute("error", unavailable.getMessage());
                    return backToProduct(selected.id());
                }
            }
        }
    }

    private String backToProduct(int id) {
        return shop.activeById(id).isPresent() ? "redirect:/san-pham/" + id : "redirect:/san-pham";
    }
}
''')

# Cart always remains a listing; hidden items still appear but cannot be bought.
replace(J+'service/CartService.java','    public List<CartItem> items(HttpSession ignored) {','    public boolean isVisible(int id) { return products.activeById(id).isPresent(); }\n    public List<CartItem> items(HttpSession ignored) {')
p=J+'controller/CartController.java'
replace(p,'        m.addAttribute("items",cart.items(session));m.addAttribute("total",cart.total(session));return "cart";','''        var items = cart.items(session);
        m.addAttribute("items", items);
        m.addAttribute("visibleCartProductIds", items.stream().map(i -> i.product().id())
                .filter(cart::isVisible).collect(java.util.stream.Collectors.toSet()));
        m.addAttribute("total", items.stream().mapToLong(i -> i.subtotal()).reduce(0, Math::addExact));
        return "cart";''')
region(p,'    @PostMapping("/gio-hang/them")','    @PostMapping("/gio-hang/cap-nhat")','''    @PostMapping("/gio-hang/them")
    public String add(@RequestParam int id,@RequestParam(defaultValue="1") int quantity,
            @RequestParam(defaultValue="false") boolean stayOnDetail,
            HttpSession session,RedirectAttributes flash){
        try { cart.add(session,id,quantity); flash.addFlashAttribute("message","Đã thêm vào giỏ hàng. Bạn có thể tiếp tục mua sắm."); }
        catch (IllegalArgumentException | ArithmeticException ex) { flash.addFlashAttribute("error",ex.getMessage()); }
        if (stayOnDetail && cart.isVisible(id)) return "redirect:/san-pham/" + id;
        return "redirect:/gio-hang";
    }
''')
replace(J+'controller/CartApiController.java','"subtotal", item.subtotal())).toList()','"subtotal", item.subtotal(), "visible", cart.isVisible(item.product().id()))).toList()')

# Works with both original detail and the previous purchase-flow update.
p=T+'detail.html'; s=read(p)
if 'id="directPurchaseActions"' not in s:
    start='    <section class="purchase-add-box"' if '    <section class="purchase-add-box"' in s else '    <form th:action="@{/gio-hang/them}" method="post" class="buy-form">'
    region(p,start,'    <section class="info-panel">','''    <section id="directPurchaseActions" class="direct-buy-box">
      <p class="direct-kicker">CHỌN SẢN PHẨM</p>
      <form th:action="@{/gio-hang/them}" method="post" class="direct-buy-form">
        <input type="hidden" th:name="${_csrf.parameterName}" th:value="${_csrf.token}">
        <input type="hidden" name="id" th:value="${product.id()}">
        <input type="hidden" name="stayOnDetail" value="true">
        <label>Số lượng
          <input type="number" name="quantity" class="input" min="1" th:max="${T(java.lang.Math).min(99, product.stock())}" value="1" required th:disabled="${product.stock() == 0}">
        </label>
        <div class="direct-buy-buttons">
          <button class="btn btn-outline" type="submit" th:disabled="${product.stock() == 0}">Thêm vào giỏ hàng</button>
          <button class="btn btn-orange" type="submit" th:formaction="@{/dat-hang/mua-ngay/bat-dau}" th:disabled="${product.stock() == 0}">Mua ngay</button>
        </div>
      </form>
      <p class="note">Thêm vào giỏ chỉ lưu sản phẩm. Mua ngay chỉ đặt mua mẫu này, không thay đổi giỏ hàng.</p>
      <p th:unless="${customerLoggedIn}" class="note">Đăng nhập tài khoản khách hàng để mua ngay hoặc lưu giỏ hàng.</p>
      <a class="link" th:href="@{/gio-hang}">Xem giỏ hàng (<span th:text="${cartCount}">0</span>) →</a>
    </section>
''')

p=T+'cart.html'; s=read(p)
if 'id="savedCartList"' not in s:
    s=s.replace('Những món đồ bạn đã chọn</h1>','Giỏ hàng của bạn</h1>')
    s=re.sub(r'(?s)<nav class="purchase-steps"[^>]*>.*?</nav>\s*','',s,count=1)
    s=s.replace('class="checkout-layout">','class="checkout-layout" id="savedCartList">',1)
    save(p,s)
    replace(p,'<h2>Trang phục và phụ kiện đã chọn</h2>','<h2>Sản phẩm đã lưu vào giỏ</h2>')
    replace(p,'<p class="note">Bạn có thể đổi số lượng hoặc bỏ bớt món đồ trước khi đặt hàng.</p>','<p class="note">Bấm ảnh hoặc tên để xem chi tiết. Bạn có thể mua riêng từng sản phẩm, hoặc lưu lại để xem sau.</p>')
    replace(p,'''        <img th:src="${#strings.startsWith(item.product().image(), '/') ? item.product().image() : '/' + item.product().image()}"
             th:alt="${item.product().name()}">''','''        <a class="saved-cart-photo" th:if="${visibleCartProductIds.contains(item.product().id())}" th:href="@{/san-pham/{id}(id=${item.product().id()})}">
          <img th:src="${#strings.startsWith(item.product().image(), '/') ? item.product().image() : '/' + item.product().image()}" th:alt="${item.product().name()}">
        </a>
        <div class="saved-cart-photo" th:unless="${visibleCartProductIds.contains(item.product().id())}">
          <img th:src="${#strings.startsWith(item.product().image(), '/') ? item.product().image() : '/' + item.product().image()}" th:alt="${item.product().name()}">
        </div>''')
    replace(p,'''          <a class="product-name" th:href="@{/san-pham/{id}(id=${item.product().id()})}"
             th:text="${item.product().name()}">Trang phục MENS STORE</a>''','''          <a class="product-name" th:if="${visibleCartProductIds.contains(item.product().id())}" th:href="@{/san-pham/{id}(id=${item.product().id()})}"
             th:text="${item.product().name()}">Trang phục MENS STORE</a>
          <strong th:unless="${visibleCartProductIds.contains(item.product().id())}" th:text="${item.product().name()}"></strong>
          <small class="stock-no" th:unless="${visibleCartProductIds.contains(item.product().id())}">Đã ngừng bán</small>
          <small class="stock-no" th:if="${visibleCartProductIds.contains(item.product().id()) and item.product().stock() < item.quantity()}">Số lượng lưu vượt tồn kho hiện tại</small>
          <a class="btn btn-small btn-orange saved-buy" th:if="${visibleCartProductIds.contains(item.product().id()) and item.quantity() > 0 and item.quantity() <= item.product().stock() and item.product().price() > 0}" th:href="@{/dat-hang/mua-ngay(id=${item.product().id()},quantity=${item.quantity()})}">Mua ngay mẫu này</a>''')
    s=read(p)
    s,n=re.subn(r'<a class="btn btn-orange block[^"\n]*" th:href="@\{/dat-hang\}">[^<]*</a>\s*<p class="note">[^<]*</p>', '''<a class="btn btn-outline block" th:href="@{/san-pham}">Tiếp tục mua sắm</a>
      <p class="note">Đây là danh sách đã lưu, không phải đơn hàng. Mua riêng một mẫu bằng nút Mua ngay; các món trong giỏ vẫn được giữ nguyên.</p>''',s,count=1)
    if n!=1: raise SystemExit('Khong tim thay nut dat hang cu trong gio hang. Chua ghi file nao.')
    save(p,s)

p=T+'checkout.html'
replace(p,'th:action="@{/dat-hang}" th:object="${checkoutForm}"','th:action="@{${directPurchase == true ? \'/dat-hang/mua-ngay\' : \'/dat-hang\'}}" th:object="${checkoutForm}"')
replace(p,'    <form class="panel checkout-form"','''    <form class="panel checkout-form"''') # no-op; keeps prior layout
replace(p,'      <input type="hidden" name="checkoutToken" th:value="${checkoutToken}">','''      <input type="hidden" name="checkoutToken" th:value="${checkoutToken}">
      <p class="direct-checkout-notice" th:if="${directPurchase == true}">MUA NGAY · Đơn này chỉ gồm sản phẩm bạn vừa chọn. Giỏ hàng không bị thay đổi.</p>''')
replace(p,'      <a class="link" th:href="@{/gio-hang}">← Chỉnh sửa giỏ hàng</a>','''      <a class="link" th:if="${directPurchase == true}" th:href="@{/san-pham/{id}(id=${directProductId})}">← Quay lại sản phẩm</a>
      <a class="link" th:unless="${directPurchase == true}" th:href="@{/gio-hang}">← Chỉnh sửa giỏ hàng</a>''')
s=read(p)
if '<nav class="purchase-steps"' in s: replace(p,'<nav class="purchase-steps"','<nav class="purchase-steps" th:unless="${directPurchase == true}"')

p=T+'home.mens.html'; s=read(p)
if '                Tiếp tục đặt hàng\n' in s: replace(p,'                Tiếp tục đặt hàng\n','                Xem giỏ hàng\n')
p=A+'js/home-store.js'; s=read(p)
if "window.location.href = '/dat-hang';" in s: replace(p,"window.location.href = '/dat-hang';","window.location.href = '/gio-hang';")
if "        if (!cart.length) { notify('Vui lòng thêm sản phẩm trước khi đặt hàng.'); return; }\n" in read(p):
    save(p,read(p).replace("        if (!cart.length) { notify('Vui lòng thêm sản phẩm trước khi đặt hàng.'); return; }\n",'',1))
replace(p,'<div class="fw-semibold mb-1">${safe(item.name)}</div>', '''<div class="fw-semibold mb-1">${item.visible ? '<a class="text-reset" href="/san-pham/' + Number(item.id) + '">' + safe(item.name) + '</a>' : safe(item.name) + ' (Ngừng bán)'}</div>''')

p=T+'fragments.html'
replace(p,'</head>','    <link rel="stylesheet" th:href="@{/assets/css/direct-buy.css}">\n</head>')
add(A+'css/direct-buy.css','''/* Separate saved cart and direct purchase */
.direct-buy-box{padding:20px;border:1px solid #e4ddd4;border-radius:16px;margin:20px 0;background:#fff}
.direct-kicker{font-size:11px;font-weight:800;letter-spacing:.1em;color:#a65f39;margin:0 0 12px}
.direct-buy-form{display:grid;gap:14px;margin:0 0 12px}
.direct-buy-form label{display:grid;gap:6px;width:110px;font-size:13px;font-weight:700}
.direct-buy-buttons{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.direct-buy-buttons .btn{min-height:48px;text-align:center;font-weight:800;white-space:normal}
.saved-cart-photo{display:block;width:93px;height:93px;border-radius:9px;overflow:hidden;background:#f2efe8}
.saved-cart-photo img{width:100%;height:100%;object-fit:contain}
.saved-buy{display:inline-flex;margin-top:7px}
.direct-checkout-notice{padding:12px;border:1px solid #e8d4c0;background:#faf1e6;color:#784522;border-radius:10px;font-size:13px;font-weight:700}
@media(max-width:760px){.direct-buy-box{padding:14px}.direct-buy-buttons{grid-template-columns:1fr}.saved-cart-photo{width:64px;height:76px}}
''')

# Regression tests focus on the transaction distinction, not a live database.
add(TEST+'service/DirectOrderTest.java','''package com.example.mens_store.service;

import com.example.mens_store.model.*;
import com.example.mens_store.repository.*;
import org.junit.jupiter.api.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import java.util.Map;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DirectOrderTest {
    private OrderRepository orders;
    private ShopRepository shop;
    private CartRepository carts;
    private OrderService service;
    private CheckoutForm form;
    @BeforeEach void setUp() {
        orders = mock(OrderRepository.class); shop = mock(ShopRepository.class);
        carts = mock(CartRepository.class);
        CustomerAccountService customers = mock(CustomerAccountService.class);
        var auth = UsernamePasswordAuthenticationToken.authenticated("test", null,
                AuthorityUtils.createAuthorityList("ROLE_CUSTOMER"));
        SecurityContextHolder.getContext().setAuthentication(auth);
        when(customers.findAuthenticatedAccount(auth)).thenReturn(Optional.of(
                new CustomerAccount(42L, "Test Buyer", "test@example.com", "0901234567", "hash", true,
                        null, "Test address", null, 0)));
        service = new OrderService(orders, shop, carts, customers);
        form = new CheckoutForm(); form.setFullName("Test Buyer"); form.setPhone("0901234567");
        form.setAddress("Test address"); form.setPaymentMethod("COD");
        when(shop.activeById(7)).thenReturn(Optional.of(new Product(7,"SKU7","Hoodie",1,"Ao khoac","","","img",489000L,5,false,true)));
        when(orders.insertCustomer(form)).thenReturn(11L);
        when(orders.insertOrder(eq(11L), anyString(), eq(form), anyLong(), eq("COD"), eq(42L))).thenReturn(22L);
        when(orders.decrementStock(eq(7), anyInt())).thenReturn(true);
    }
    @AfterEach void clearAuth() { SecurityContextHolder.clearContext(); }
    @Test void directPurchaseNeverReadsOrClearsCart() {
        OrderReceipt receipt = service.placeDirect(form,7,2,42L);
        assertEquals(978000L, receipt.total());
        verify(orders).insertLine(22L,7,"Hoodie",2,489000L,978000L);
        verify(carts,never()).valuesForUpdate(anyLong());
        verify(carts,never()).clear(anyLong());
    }
    @Test void previousCartCheckoutStillClearsCart() {
        when(carts.valuesForUpdate(42L)).thenReturn(Map.of(7,1));
        service.place(form, Map.of(), 42L);
        verify(orders).insertLine(22L,7,"Hoodie",1,489000L,489000L);
        verify(carts).clear(42L);
    }
    @Test void stockFailureDoesNotCreateOrder() {
        assertThrows(IllegalArgumentException.class,()->service.placeDirect(form,7,6,42L));
        verify(orders,never()).insertCustomer(any());
        verify(carts,never()).clear(anyLong());
    }
}
''')

if not pending:
    print('Da cap nhat, khong can ghi lai.'); raise SystemExit(0)
backup=Path(tempfile.mkdtemp(prefix='mens-store-direct-backup-',dir=Path.home()))
for p in pending:
    if (root/p).is_file():
        dst=backup/p; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(root/p,dst)
print('Sao luu:',backup)
written=[]
try:
    for path,content in pending.items():
        p=root/path; p.parent.mkdir(parents=True,exist_ok=True)
        tmp=p.with_name(p.name+'.direct-update.tmp'); tmp.write_text(content,encoding='utf-8')
        if p.exists(): shutil.copymode(p,tmp)
        os.replace(tmp,p); written.append(path); print('OK:',path)
except Exception:
    for path in reversed(written):
        if (backup/path).is_file(): shutil.copy2(backup/path,root/path)
        else: (root/path).unlink(missing_ok=True)
    raise
print('Hoan tat. Khong thay doi SQL, .env, gio hang hay don hang hien co.')
