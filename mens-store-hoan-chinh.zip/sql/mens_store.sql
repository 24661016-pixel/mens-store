-- MENS STORE: CSDL website bán quần áo nam.
-- Script tạo bảng và dữ liệu mẫu khi khởi tạo database mới.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS danh_muc (
  danh_muc_id INT AUTO_INCREMENT PRIMARY KEY,
  ma_danh_muc VARCHAR(30) NOT NULL UNIQUE,
  ten_danh_muc VARCHAR(100) NOT NULL,
  mo_ta VARCHAR(255),
  thu_tu INT NOT NULL DEFAULT 0,
  trang_thai TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS san_pham (
  san_pham_id INT AUTO_INCREMENT PRIMARY KEY,
  ma_san_pham VARCHAR(30) NOT NULL UNIQUE,
  ten_san_pham VARCHAR(150) NOT NULL,
  danh_muc_id INT NOT NULL,
  mo_ta TEXT,
  thong_so TEXT,
  hinh_anh VARCHAR(255),
  gia_ban DECIMAL(12,0) NOT NULL,
  so_luong_ton INT NOT NULL DEFAULT 0,
  noi_bat TINYINT(1) NOT NULL DEFAULT 0,
  trang_thai TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_sp_dm FOREIGN KEY(danh_muc_id) REFERENCES danh_muc(danh_muc_id),
  INDEX idx_sp_danh_muc(danh_muc_id),
  INDEX idx_sp_trang_thai(trang_thai)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tai_khoan (
  tai_khoan_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  ho_ten VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL,
  so_dien_thoai VARCHAR(20) NOT NULL,
  dia_chi VARCHAR(255) NOT NULL DEFAULT '',
  ngay_sinh DATE NULL,
  mat_khau_version INT NOT NULL DEFAULT 0,
  mat_khau_hash VARCHAR(100) NOT NULL,
  trang_thai TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_tai_khoan_email(email),
  UNIQUE KEY uq_tai_khoan_phone(so_dien_thoai)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS khach_hang (
  khach_hang_id INT AUTO_INCREMENT PRIMARY KEY,
  ho_ten VARCHAR(120) NOT NULL,
  so_dien_thoai VARCHAR(20) NOT NULL,
  email VARCHAR(150),
  dia_chi VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS don_hang (
  don_hang_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  ma_don_hang VARCHAR(40) NOT NULL UNIQUE,
  tai_khoan_id BIGINT NULL,
  khach_hang_id INT NOT NULL,
  ten_nguoi_nhan VARCHAR(120) NOT NULL,
  sdt_nguoi_nhan VARCHAR(20) NOT NULL,
  dia_chi_giao_hang VARCHAR(255) NOT NULL,
  ghi_chu VARCHAR(500),
  tam_tinh DECIMAL(12,0) NOT NULL DEFAULT 0,
  phi_giao_hang DECIMAL(12,0) NOT NULL DEFAULT 0,
  tong_tien DECIMAL(12,0) NOT NULL DEFAULT 0,
  phuong_thuc_thanh_toan ENUM('COD','CHUYEN_KHOAN') NOT NULL DEFAULT 'COD',
  trang_thai_thanh_toan ENUM('CHUA_THANH_TOAN','CHO_KIEM_TRA','DA_THANH_TOAN') NOT NULL DEFAULT 'CHUA_THANH_TOAN',
  thoi_gian_thanh_toan DATETIME NULL,
  ma_giao_dich_ngan_hang VARCHAR(100) NULL,
  trang_thai ENUM('CHO_XAC_NHAN','DA_XAC_NHAN','DANG_GIAO','HOAN_TAT','DA_HUY') NOT NULL DEFAULT 'CHO_XAC_NHAN',
  thoi_gian_dat DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_dh_tk FOREIGN KEY(tai_khoan_id) REFERENCES tai_khoan(tai_khoan_id),
  INDEX idx_dh_tai_khoan(tai_khoan_id),
  CONSTRAINT fk_dh_kh FOREIGN KEY(khach_hang_id) REFERENCES khach_hang(khach_hang_id),
  INDEX idx_dh_thoi_gian(thoi_gian_dat),
  INDEX idx_dh_trang_thai(trang_thai)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chi_tiet_don_hang (
  chi_tiet_don_hang_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  don_hang_id BIGINT NOT NULL,
  san_pham_id INT NOT NULL,
  ten_san_pham VARCHAR(150) NOT NULL,
  so_luong INT NOT NULL,
  don_gia DECIMAL(12,0) NOT NULL,
  thanh_tien DECIMAL(12,0) NOT NULL,
  CONSTRAINT fk_ct_dh FOREIGN KEY(don_hang_id) REFERENCES don_hang(don_hang_id),
  CONSTRAINT fk_ct_sp FOREIGN KEY(san_pham_id) REFERENCES san_pham(san_pham_id),
  INDEX idx_ct_dh(don_hang_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS gio_hang (
  tai_khoan_id BIGINT NOT NULL,
  san_pham_id INT NOT NULL,
  so_luong INT NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(tai_khoan_id, san_pham_id),
  FOREIGN KEY(tai_khoan_id) REFERENCES tai_khoan(tai_khoan_id),
  FOREIGN KEY(san_pham_id) REFERENCES san_pham(san_pham_id),
  CHECK(so_luong BETWEEN 1 AND 99)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tai_khoan_id BIGINT NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(tai_khoan_id) REFERENCES tai_khoan(tai_khoan_id),
  INDEX idx_reset_account(tai_khoan_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS binh_luan (
  binh_luan_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tai_khoan_id BIGINT NOT NULL,
  san_pham_id INT NOT NULL,
  noi_dung VARCHAR(1000) NOT NULL,
  trang_thai VARCHAR(20) NOT NULL DEFAULT 'CHO_DUYET',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(tai_khoan_id) REFERENCES tai_khoan(tai_khoan_id),
  FOREIGN KEY(san_pham_id) REFERENCES san_pham(san_pham_id),
  INDEX idx_comment_product(san_pham_id, trang_thai)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS khuyen_mai (
  khuyen_mai_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  ma_khuyen_mai VARCHAR(30) NOT NULL UNIQUE,
  ten_khuyen_mai VARCHAR(120) NOT NULL,
  phan_tram_giam INT NOT NULL,
  bat_dau DATE NOT NULL,
  ket_thuc DATE NOT NULL,
  trang_thai TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK(phan_tram_giam BETWEEN 1 AND 80),
  CHECK(ket_thuc >= bat_dau)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO danh_muc (danh_muc_id, ma_danh_muc, ten_danh_muc, mo_ta, thu_tu) VALUES
(1,'AO_THUN','Áo thun','Áo thun nam cotton với phom regular, relaxed và oversize; lựa chọn nền tảng để phối cùng jeans, chino hoặc quần short khi đi học, dạo phố và sinh hoạt hằng ngày.',1),
(2,'SO_MI','Sơ mi','Sơ mi Oxford, denim và linen pha cho tủ đồ nam; chọn phom vừa hoặc rộng nhẹ để mặc công sở, gặp gỡ bạn bè hay khoác ngoài áo thun, tùy chất liệu và cách phối.',2),
(3,'AO_POLO','Áo polo','Áo polo nam cổ bẻ với bề mặt pique hoặc cotton pha; kết hợp nét gọn gàng của sơ mi và sự linh hoạt của áo thun, dễ phối quần chino, jeans và quần short.',3),
(4,'QUAN_NAM','Quần nam','Quần nam gồm chino, jeans ống đứng, cargo túi hộp và short kaki; chọn theo vòng eo, độ rộng đùi, chiều dài ống và nhu cầu mặc đi làm, đi học hoặc cuối tuần.',4),
(5,'AO_KHOAC','Áo khoác','Bomber, hoodie và cardigan dành cho cách mặc nhiều lớp; cân nhắc độ rộng vai, khoảng trống cho áo bên trong và chất liệu khi chọn trang phục cho ngày se lạnh.',5),
(6,'PHU_KIEN','Phụ kiện','Thắt lưng, nón và túi tote hoàn thiện bộ trang phục MENS STORE; ưu tiên màu dễ phối, kiểm tra kích thước phù hợp và chăm sóc theo đặc điểm từng chất liệu.',6);

-- Danh mục minh họa MENS STORE: nội dung về chất liệu, phom, phối đồ và chăm sóc là dữ liệu mẫu.
-- Gợi ý size không xác nhận biến thể còn hàng; cần bổ sung số đo, thành phần và nhãn chăm sóc thực tế trước khi kinh doanh.
INSERT IGNORE INTO san_pham
(ma_san_pham,ten_san_pham,danh_muc_id,mo_ta,thong_so,hinh_anh,gia_ban,so_luong_ton,noi_bat)
VALUES
('SP001','Áo thun nam Basic Cotton trắng',1,'Áo thun cotton trắng phom regular fit là lớp nền gọn gàng cho tủ đồ nam. Phối cùng jeans xanh để đi học, hoặc quần chino be và sơ mi khoác ngoài khi gặp bạn bè. Khi chọn áo, so sánh độ rộng vai và ngực với chiếc áo bạn đang mặc vừa.','Chất liệu: Cotton; thành phần cụ thể cần đối chiếu nhãn sản phẩm.\nPhom dáng: Regular fit, gợi ý mặc vừa người và có khoảng cử động.\nMàu sắc: Trắng.\nPhối đồ: Jeans xanh, chino be hoặc quần short đơn sắc.\nHoàn cảnh: Đi học, dạo phố, mặc thường ngày hoặc làm lớp áo trong.\nChăm sóc tham khảo: Giặt nhẹ, tách đồ sáng màu; làm theo ký hiệu trên nhãn.\nGợi ý size mẫu: Đo ngang ngực, rộng vai và dài áo đang mặc vừa để đối chiếu bảng đo; chưa có số đo để chốt size cụ thể.','/images/products/sp1.svg',189000,45,1),
('SP002','Áo thun nam Oversize đen',1,'Áo thun cotton đen phom oversize tạo dáng rộng cho phong cách thường ngày. Kết hợp quần jeans ống đứng hoặc chino sáng màu để giữ tổng thể cân đối. Độ rộng đã nằm ở phom áo, vì vậy hãy đối chiếu số đo trước khi quyết định tăng size.','Chất liệu: Cotton; thông tin thành phần chi tiết cần xem trên nhãn.\nPhom dáng: Oversize, dáng rộng theo thiết kế.\nMàu sắc: Đen.\nPhối đồ: Jeans ống đứng, chino be; dùng phụ kiện đơn giản để giữ điểm nhấn.\nHoàn cảnh: Đi học, dạo phố, gặp bạn bè.\nChăm sóc tham khảo: Lộn trái khi giặt, tránh chất tẩy mạnh; ưu tiên hướng dẫn của nhãn.\nGợi ý size mẫu: So ngang ngực và dài áo với áo oversize đang mặc; không tự tăng size chỉ dựa trên tên phom.','/images/products/sp2.svg',219000,38,1),
('SP003','Áo thun Graphic Streetwear',1,'Áo thun cotton màu kem phom relaxed fit dùng họa tiết graphic làm điểm nhấn cho bộ đồ dạo phố. Quần jeans hoặc cargo đơn sắc giúp phần hình in dễ nổi bật. Có thể thêm nón đen khi muốn bộ trang phục mang tinh thần streetwear.','Chất liệu: Cotton.\nPhom dáng: Relaxed fit, gợi ý mặc rộng nhẹ.\nMàu sắc: Kem; điểm nhấn graphic.\nPhối đồ: Jeans xanh hoặc cargo đen, hạn chế thêm họa tiết lớn.\nHoàn cảnh: Dạo phố, gặp bạn bè và những ngày mặc thoải mái.\nChăm sóc tham khảo: Lộn trái khi giặt; không ủi trực tiếp lên hình in; xem nhãn trước khi làm sạch.\nGợi ý size mẫu: Đối chiếu ngang ngực và dài thân áo; chọn độ rộng theo sở thích sau khi có bảng đo thực tế.','/images/products/sp3.svg',249000,26,1),
('SP004','Áo thun nam kẻ ngang',1,'Áo thun cotton kẻ ngang phom regular fit mang nét gọn gàng cho trang phục cuối tuần. Phối với quần short kaki hoặc jeans trơn để cân bằng họa tiết. Đây là gợi ý cho bộ đồ đi học, đi dạo và những buổi gặp gỡ thoải mái.','Chất liệu: Cotton.\nPhom dáng: Regular fit.\nHọa tiết: Kẻ ngang.\nPhối đồ: Quần short kaki, jeans trơn hoặc chino đơn sắc.\nHoàn cảnh: Mặc thường ngày, đi học, dạo phố cuối tuần.\nChăm sóc tham khảo: Giặt nhẹ và phân loại đồ theo màu; tuân theo nhãn chăm sóc.\nGợi ý size mẫu: Kiểm tra đường vai, ngang ngực và chiều dài áo bằng bảng đo; chưa xác định size chỉ từ chiều cao hoặc cân nặng.','/images/products/sp4.svg',199000,30,0),
('SP005','Sơ mi Oxford trắng',2,'Sơ mi cotton Oxford trắng phom regular fit phù hợp bộ đồ nam gọn gàng. Phối với chino và thắt lưng đen cho ngày làm việc, hoặc mặc ngoài áo thun khi đi chơi. Trước khi chọn size, hãy kiểm tra thêm vòng cổ và độ dài tay áo.','Chất liệu: Cotton Oxford.\nPhom dáng: Regular fit.\nMàu sắc: Trắng.\nPhối đồ: Chino be hoặc jeans xanh; thêm thắt lưng cho bộ đồ sơ vin.\nHoàn cảnh: Công sở có trang phục linh hoạt, gặp gỡ và sinh hoạt thường ngày.\nChăm sóc tham khảo: Phân loại đồ trắng, giặt theo nhãn và chỉnh cổ, nẹp áo trước khi phơi.\nGợi ý size mẫu: Đối chiếu vòng cổ, rộng vai, ngang ngực và dài tay; chọn áo đủ khoảng cử động khi cài nút.','/images/products/sp5.svg',329000,22,1),
('SP006','Sơ mi nam Denim xanh',2,'Sơ mi denim xanh phom regular fit có thể mặc cài nút hoặc khoác ngoài áo thun trắng. Kết hợp chino be để tạo tương phản chất liệu, hoặc jeans khác sắc độ cho cách phối denim. Nếu mặc nhiều lớp, hãy tính thêm độ rộng cho áo bên trong.','Chất liệu: Denim.\nPhom dáng: Regular fit.\nMàu sắc: Xanh denim.\nPhối đồ: Áo thun trắng và chino be; jeans khác sắc độ khi phối cùng denim.\nHoàn cảnh: Đi học, dạo phố và trang phục thường ngày.\nChăm sóc tham khảo: Giặt riêng đồ denim khi cần, tránh chất tẩy mạnh; ưu tiên chỉ dẫn trên nhãn.\nGợi ý size mẫu: So rộng vai, ngang ngực và dài tay; kiểm tra khoảng trống nếu dùng làm áo khoác ngoài.','/images/products/sp6.svg',359000,17,0),
('SP007','Sơ mi Linen tay dài',2,'Sơ mi linen pha màu be phom relaxed fit hướng tới cách mặc nhẹ nhàng trong ngày ấm. Phối với quần chino hoặc short kaki để có bộ đồ đơn giản, sáng màu. Dáng rộng nhẹ và nếp vải tự nhiên là những yếu tố nên cân nhắc khi chọn phong cách.','Chất liệu: Linen blend; tỷ lệ sợi cần xem nhãn sản phẩm.\nPhom dáng: Relaxed fit, tay dài.\nMàu sắc: Be.\nPhối đồ: Chino, short kaki hoặc áo thun sáng màu mặc bên trong.\nHoàn cảnh: Dạo phố, gặp bạn bè và những dịp mặc thường ngày.\nChăm sóc tham khảo: Giặt và ủi theo nhãn; tránh vặn xoắn mạnh, chỉnh phom trước khi phơi.\nGợi ý size mẫu: Đối chiếu ngang ngực, vai và dài tay; xác định mức rộng mong muốn bằng số đo áo thực tế.','/images/products/sp7.svg',379000,19,1),
('SP008','Áo polo nam Classic Navy',3,'Áo polo pique cotton màu navy phom regular fit giúp bộ đồ nam có điểm nhấn ở phần cổ. Kết hợp chino be khi cần gọn gàng, hoặc short kaki cho buổi đi chơi. Màu áo trầm dễ làm nền cho quần sáng màu và phụ kiện tối giản.','Chất liệu: Pique cotton.\nPhom dáng: Regular fit, cổ polo.\nMàu sắc: Navy.\nPhối đồ: Chino be, short kaki xám hoặc jeans xanh.\nHoàn cảnh: Đi làm với trang phục linh hoạt, đi học và gặp gỡ cuối tuần.\nChăm sóc tham khảo: Giặt theo nhãn, chỉnh cổ áo trước khi phơi và tránh kéo giãn phần cổ.\nGợi ý size mẫu: Kiểm tra rộng vai, ngang ngực, dài áo và độ ôm bắp tay bằng bảng đo thực tế.','/images/products/sp8.svg',289000,33,1),
('SP009','Áo polo nam Pique kem',3,'Áo polo pique cotton màu kem phom regular fit dành cho cách phối màu sáng và gọn. Mặc cùng jeans xanh đậm hoặc chino để tạo sự cân đối. Khi thử áo, chú ý phần vai và tay áo để chọn độ vừa phù hợp với cách mặc sơ vin hoặc thả ngoài.','Chất liệu: Pique cotton.\nPhom dáng: Regular fit, cổ polo.\nMàu sắc: Kem.\nPhối đồ: Jeans xanh, chino và thắt lưng đen khi sơ vin.\nHoàn cảnh: Đi học, gặp gỡ bạn bè hoặc ngày làm việc với trang phục linh hoạt.\nChăm sóc tham khảo: Phân loại đồ sáng màu, xử lý vết bẩn theo nhãn và tránh chất tẩy không phù hợp.\nGợi ý size mẫu: Đối chiếu vai, ngang ngực, bắp tay và dài áo; chưa có bảng số đo để xác nhận size cụ thể.','/images/products/sp9.svg',299000,28,1),
('SP010','Áo polo nam Sport xanh rêu',3,'Áo polo cotton pha xanh rêu phom slim fit tạo đường nét gọn cho trang phục hằng ngày. Kết hợp short kaki xám hoặc jeans để giữ tinh thần năng động. Tên phong cách Sport không thay thế thông tin về tính năng chuyên dụng của chất liệu.','Chất liệu: Cotton blend; tỷ lệ thành phần cần đối chiếu nhãn.\nPhom dáng: Slim fit, cổ polo.\nMàu sắc: Xanh rêu.\nPhối đồ: Short kaki xám, jeans xanh hoặc chino be.\nHoàn cảnh: Mặc thường ngày, đi học và đi chơi; chưa có thông số trang phục thể thao chuyên dụng.\nChăm sóc tham khảo: Giặt theo nhãn, lộn trái khi cần và tránh sấy nhiệt không phù hợp.\nGợi ý size mẫu: Ưu tiên số đo ngực và bắp tay; phom slim vẫn cần đủ khoảng cử động, không chốt size từ cân nặng đơn lẻ.','/images/products/sp10.svg',279000,21,0),
('SP011','Quần Chino nam màu be',4,'Quần chino kaki cotton màu be phom straight fit tạo dáng ống đứng cho tủ đồ nam. Phối với áo polo navy khi đi làm, hoặc áo thun trắng cho ngày nghỉ. Hãy kiểm tra vòng eo, đùi và chiều dài ống theo kiểu mặc sơ vin hoặc thả áo bạn thích.','Chất liệu: Kaki cotton.\nPhom dáng: Straight fit, ống đứng.\nMàu sắc: Be.\nPhối đồ: Polo navy, áo thun trắng hoặc sơ mi Oxford.\nHoàn cảnh: Đi học, công sở có trang phục linh hoạt và gặp gỡ thường ngày.\nChăm sóc tham khảo: Giặt theo nhãn, làm sạch túi và chỉnh đường ống trước khi phơi.\nGợi ý size mẫu: Đo vòng eo, mông, đùi và dài ống của quần đang vừa; cần bảng đo thực tế trước khi chọn cỡ.','/images/products/sp11.svg',399000,24,1),
('SP012','Quần Jeans nam Straight xanh',4,'Quần jeans denim xanh phom straight fit là lựa chọn ống đứng cho bộ đồ thường ngày. Có thể phối với áo thun graphic khi dạo phố hoặc sơ mi Oxford khi cần gọn gàng hơn. Độ vừa ở eo và đùi nên được kiểm tra cùng chiều dài ống.','Chất liệu: Denim.\nPhom dáng: Straight fit, ống đứng.\nMàu sắc: Xanh denim.\nPhối đồ: Áo thun graphic, polo trơn hoặc sơ mi Oxford trắng.\nHoàn cảnh: Đi học, dạo phố và gặp bạn bè.\nChăm sóc tham khảo: Giặt theo nhãn, phân loại màu và tránh chất tẩy mạnh; không mặc định denim không ra màu.\nGợi ý size mẫu: Đối chiếu vòng eo, đùi, chiều cao cạp và dài ống; chưa có tỷ lệ co giãn để suy ra cỡ mặc.','/images/products/sp12.svg',449000,20,1),
('SP013','Quần Cargo nam đen',4,'Quần cargo kaki đen có dáng túi hộp làm điểm nhấn cho trang phục dạo phố. Phối với áo thun trơn hoặc hoodie để cân đối phần túi và độ rộng của quần. Khi chọn cỡ, chú ý không gian ở đùi và đầu gối để có khoảng cử động phù hợp.','Chất liệu: Kaki.\nPhom dáng: Cargo fit với chi tiết túi hộp.\nMàu sắc: Đen.\nPhối đồ: Áo thun trắng hoặc đen, hoodie xám; tiết chế họa tiết lớn.\nHoàn cảnh: Đi học, dạo phố và sinh hoạt thường ngày.\nChăm sóc tham khảo: Lấy hết vật trong túi, giặt theo nhãn và chỉnh nắp túi trước khi phơi.\nGợi ý size mẫu: Đối chiếu vòng eo, mông, đùi và dài quần; kiểm tra độ rộng khi ngồi hoặc bước đi.','/images/products/sp13.svg',429000,15,0),
('SP014','Quần short kaki nam',4,'Quần short kaki cotton xám phom regular fit phù hợp bộ đồ cuối tuần gọn nhẹ. Kết hợp polo hoặc áo thun kẻ ngang khi đi dạo và gặp bạn bè. Hãy đối chiếu chiều dài quần thực tế với sở thích về vị trí gấu, cùng độ vừa ở eo và đùi.','Chất liệu: Kaki cotton.\nPhom dáng: Regular fit, quần short.\nMàu sắc: Xám.\nPhối đồ: Polo navy, áo thun trắng hoặc áo thun kẻ ngang.\nHoàn cảnh: Đi dạo, đi chơi và những ngày nghỉ với trang phục thoải mái.\nChăm sóc tham khảo: Kiểm tra túi, giặt nhẹ theo nhãn và phơi ở nơi thông thoáng.\nGợi ý size mẫu: Đo vòng eo, mông, đùi và dài quần; chọn vị trí gấu theo số đo thực tế, không suy từ ảnh minh họa.','/images/products/sp14.svg',259000,35,0),
('SP015','Áo khoác Bomber nam',5,'Áo khoác vải dù đen kiểu bomber là lớp ngoài cho bộ đồ nam khi trời se lạnh. Phối áo thun trắng và jeans, hoặc khoác cùng chino để tạo tổng thể gọn. Khoảng rộng vai và ngực cần tính thêm lớp áo bên trong khi lựa chọn kích cỡ.','Chất liệu: Vải dù; chưa có thông số chống nước hoặc giữ nhiệt.\nPhom dáng: Bomber.\nMàu sắc: Đen.\nPhối đồ: Áo thun trắng, jeans xanh hoặc chino be.\nHoàn cảnh: Mặc nhiều lớp khi thời tiết se lạnh, đi học và dạo phố.\nChăm sóc tham khảo: Đóng khóa trước khi giặt nếu nhãn hướng dẫn; tránh nhiệt cao không phù hợp với vải.\nGợi ý size mẫu: So vai, ngang ngực, dài tay và dài áo; chừa khoảng cho áo bên trong theo bảng đo thực tế.','/images/products/sp15.svg',599000,12,1),
('SP016','Áo Hoodie nam màu xám',5,'Áo hoodie nỉ cotton xám phom oversize dành cho cách mặc nhiều lớp với dáng rộng. Kết hợp jeans ống đứng hoặc cargo đen cho ngày đi học và dạo phố. Khi chọn áo, hãy xem chiều dài thân và tay để độ rộng không làm mất cân đối bộ đồ.','Chất liệu: Nỉ cotton.\nPhom dáng: Oversize, kiểu hoodie.\nMàu sắc: Xám.\nPhối đồ: Jeans ống đứng, cargo đen hoặc áo thun làm lớp trong.\nHoàn cảnh: Đi học, dạo phố và mặc nhiều lớp khi trời se lạnh.\nChăm sóc tham khảo: Lộn trái, giặt theo nhãn và tránh kéo giãn phần bo khi phơi.\nGợi ý size mẫu: Đối chiếu ngang ngực, dài thân và dài tay; kiểm tra độ rộng với lớp áo bên trong, không tự tăng cỡ.','/images/products/sp16.svg',489000,18,1),
('SP017','Áo khoác Cardigan nam',5,'Áo cardigan len dệt màu nâu phom regular fit mang nét nhẹ nhàng cho bộ đồ nhiều lớp. Mặc cùng áo thun sáng màu và chino, hoặc khoác ngoài sơ mi Oxford khi gặp gỡ. Độ rộng vai và chiều dài áo cần phù hợp với lớp áo bạn dự định mặc bên trong.','Chất liệu: Len dệt; thành phần sợi cụ thể cần xem nhãn.\nPhom dáng: Regular fit, kiểu cardigan.\nMàu sắc: Nâu.\nPhối đồ: Áo thun trắng, sơ mi Oxford và quần chino.\nHoàn cảnh: Gặp gỡ bạn bè, không gian làm việc có trang phục linh hoạt, ngày se lạnh.\nChăm sóc tham khảo: Làm sạch theo nhãn đồ dệt, tránh vặn mạnh hoặc treo khi còn nặng nước; chỉnh phom khi phơi.\nGợi ý size mẫu: So vai, ngang ngực, dài áo và tay; kiểm tra khoảng rộng nếu mặc cùng sơ mi.','/images/products/sp17.svg',529000,10,0),
('SP018','Thắt lưng da nam tối giản',6,'Thắt lưng da tổng hợp đen bản 3,2 cm giúp hoàn thiện bộ đồ nam với thiết kế khóa kim loại tối giản. Có thể phối cùng chino hoặc jeans khi sơ vin áo. Hãy kiểm tra chiều dài dây và độ rộng đỉa quần trước khi chọn phụ kiện.','Chất liệu: Da tổng hợp; không mô tả là da thật.\nThiết kế: Thắt lưng khóa kim loại, phong cách tối giản.\nBản dây: 3,2 cm theo dữ liệu mẫu.\nMàu sắc: Đen.\nPhối đồ và sử dụng: Chino, jeans và các bộ đồ sơ vin áo thun, polo hoặc sơ mi.\nChăm sóc tham khảo: Lau bằng khăn phù hợp, để khô tự nhiên; tránh ngâm nước và tuân theo nhãn sản phẩm.\nGợi ý kích cỡ mẫu: Đối chiếu vòng eo, độ dài thắt lưng đang dùng và đỉa quần; chưa có chiều dài dây để xác nhận cỡ.','/images/products/sp18.svg',199000,40,0),
('SP019','Nón lưỡi trai MENS STORE',6,'Nón lưỡi trai cotton đen MENS STORE có thiết kế điều chỉnh để bổ sung điểm nhấn cho bộ đồ thường ngày. Phối cùng áo thun, jeans hoặc quần short khi dạo phố. Kiểm tra vòng đầu và khoảng điều chỉnh thực tế trước khi chọn, thay vì mặc định vừa mọi người.','Chất liệu: Cotton.\nThiết kế: Nón lưỡi trai có phần điều chỉnh.\nMàu sắc: Đen.\nPhối đồ: Áo thun basic, áo graphic, jeans hoặc quần short.\nHoàn cảnh: Dạo phố và trang phục thường ngày; chưa có chỉ số bảo vệ UV được công bố.\nChăm sóc tham khảo: Làm sạch theo nhãn, giữ phom vành nón, tránh vặn xoắn.\nGợi ý kích cỡ mẫu: Đo vòng đầu và đối chiếu dải điều chỉnh của nón; dữ liệu mẫu chưa nêu dải số đo cụ thể.','/images/products/sp19.svg',159000,32,1),
('SP020','Túi tote canvas nam',6,'Túi tote canvas màu natural là phụ kiện cho bộ đồ đi học, đi dạo và các việc hằng ngày. Phối với áo thun, sơ mi khoác ngoài hoặc nón đen để giữ tổng thể đơn giản. Trước khi mang đồ, kiểm tra kích thước túi và giới hạn tải của sản phẩm thực tế.','Chất liệu: Canvas.\nThiết kế: Túi tote.\nMàu sắc: Natural.\nPhối đồ: Áo thun basic, sơ mi khoác ngoài và jeans hoặc chino.\nHoàn cảnh: Đi học, đi dạo và mang vật dụng hằng ngày phù hợp kích thước túi.\nChăm sóc tham khảo: Làm sạch theo nhãn, chỉnh phom sau khi giặt và để khô tự nhiên.\nGợi ý kích thước mẫu: Đối chiếu chiều rộng, cao và đáy túi với vật cần mang.','/images/products/sp20.svg',179000,27,0);

CREATE OR REPLACE VIEW v_san_pham AS
SELECT sp.san_pham_id, sp.ma_san_pham, sp.ten_san_pham, dm.ten_danh_muc,
       sp.gia_ban, sp.so_luong_ton, sp.hinh_anh, sp.trang_thai
FROM san_pham sp JOIN danh_muc dm ON sp.danh_muc_id=dm.danh_muc_id;

CREATE OR REPLACE VIEW v_don_hang AS
SELECT dh.don_hang_id, dh.ma_don_hang, dh.ten_nguoi_nhan,
       dh.sdt_nguoi_nhan, dh.dia_chi_giao_hang, dh.tong_tien,
       dh.trang_thai, dh.thoi_gian_dat
FROM don_hang dh;
