-- MENS STORE — cập nhật nội dung danh mục, tùy chọn cho database đã dùng dữ liệu mẫu bản trước.
-- Chọn đúng database MENS STORE trước khi chạy; nên sao lưu theo quy trình vận hành hiện có.
-- Chỉ sửa mo_ta của 6 danh mục, mo_ta/thong_so của tối đa 20 SKU mẫu SP001–SP020.
-- Đối chiếu BINARY để giữ nguyên cả những chỉnh sửa khác chữ hoa/thường, dấu hoặc khoảng trắng.
-- Một sản phẩm chỉ được cập nhật khi SKU, tên, danh mục và CẢ HAI trường nội dung còn đúng mẫu cũ.
-- Nếu chủ cửa hàng đã sửa mô tả hoặc thông tin sản phẩm, cả hai trường của sản phẩm đó được giữ nguyên.
-- Không thêm/xóa bảng hoặc dòng; không đổi tên, mã, ảnh, giá, tồn kho, tài khoản, giỏ hàng hay đơn hàng.
-- Chạy lại không sửa tiếp những dòng đã cập nhật. Không cần chạy script này khi vừa import mens_store.sql mới.
-- Nội dung thay thế là dữ liệu minh họa; gợi ý kích cỡ không thay cho bảng đo và tồn kho từng size thực tế.
SET NAMES utf8mb4;
START TRANSACTION;

UPDATE danh_muc
SET mo_ta = 'Áo thun nam cotton với phom regular, relaxed và oversize; lựa chọn nền tảng để phối cùng jeans, chino hoặc quần short khi đi học, dạo phố và sinh hoạt hằng ngày.'
WHERE BINARY ma_danh_muc = BINARY 'AO_THUN'
  AND BINARY ten_danh_muc = BINARY 'Áo thun'
  AND BINARY mo_ta = BINARY 'Áo thun nam basic, oversize và graphic';

UPDATE danh_muc
SET mo_ta = 'Sơ mi Oxford, denim và linen pha cho tủ đồ nam; chọn phom vừa hoặc rộng nhẹ để mặc công sở, gặp gỡ bạn bè hay khoác ngoài áo thun, tùy chất liệu và cách phối.'
WHERE BINARY ma_danh_muc = BINARY 'SO_MI'
  AND BINARY ten_danh_muc = BINARY 'Sơ mi'
  AND BINARY mo_ta = BINARY 'Sơ mi nam công sở và thường ngày';

UPDATE danh_muc
SET mo_ta = 'Áo polo nam cổ bẻ với bề mặt pique hoặc cotton pha; kết hợp nét gọn gàng của sơ mi và sự linh hoạt của áo thun, dễ phối quần chino, jeans và quần short.'
WHERE BINARY ma_danh_muc = BINARY 'AO_POLO'
  AND BINARY ten_danh_muc = BINARY 'Áo polo'
  AND BINARY mo_ta = BINARY 'Áo polo nam lịch sự, năng động';

UPDATE danh_muc
SET mo_ta = 'Quần nam gồm chino, jeans ống đứng, cargo túi hộp và short kaki; chọn theo vòng eo, độ rộng đùi, chiều dài ống và nhu cầu mặc đi làm, đi học hoặc cuối tuần.'
WHERE BINARY ma_danh_muc = BINARY 'QUAN_NAM'
  AND BINARY ten_danh_muc = BINARY 'Quần nam'
  AND BINARY mo_ta = BINARY 'Quần jeans, kaki, chino và short';

UPDATE danh_muc
SET mo_ta = 'Bomber, hoodie và cardigan dành cho cách mặc nhiều lớp; cân nhắc độ rộng vai, khoảng trống cho áo bên trong và chất liệu khi chọn trang phục cho ngày se lạnh.'
WHERE BINARY ma_danh_muc = BINARY 'AO_KHOAC'
  AND BINARY ten_danh_muc = BINARY 'Áo khoác'
  AND BINARY mo_ta = BINARY 'Hoodie, bomber và áo khoác hằng ngày';

UPDATE danh_muc
SET mo_ta = 'Thắt lưng, nón và túi tote hoàn thiện bộ trang phục MENS STORE; ưu tiên màu dễ phối, kiểm tra kích thước phù hợp và chăm sóc theo đặc điểm từng chất liệu.'
WHERE BINARY ma_danh_muc = BINARY 'PHU_KIEN'
  AND BINARY ten_danh_muc = BINARY 'Phụ kiện'
  AND BINARY mo_ta = BINARY 'Phụ kiện hoàn thiện phong cách nam';

UPDATE san_pham
SET mo_ta = 'Áo thun cotton trắng phom regular fit là lớp nền gọn gàng cho tủ đồ nam. Phối cùng jeans xanh để đi học, hoặc quần chino be và sơ mi khoác ngoài khi gặp bạn bè. Khi chọn áo, so sánh độ rộng vai và ngực với chiếc áo bạn đang mặc vừa.',
    thong_so = 'Chất liệu: Cotton; thành phần cụ thể cần đối chiếu nhãn sản phẩm.\nPhom dáng: Regular fit, gợi ý mặc vừa người và có khoảng cử động.\nMàu sắc: Trắng.\nPhối đồ: Jeans xanh, chino be hoặc quần short đơn sắc.\nHoàn cảnh: Đi học, dạo phố, mặc thường ngày hoặc làm lớp áo trong.\nChăm sóc tham khảo: Giặt nhẹ, tách đồ sáng màu; làm theo ký hiệu trên nhãn.\nGợi ý size mẫu: Đo ngang ngực, rộng vai và dài áo đang mặc vừa để đối chiếu bảng đo; chưa có số đo để chốt size cụ thể.'
WHERE BINARY ma_san_pham = BINARY 'SP001'
  AND BINARY ten_san_pham = BINARY 'Áo thun nam Basic Cotton trắng'
  AND danh_muc_id = 1
  AND BINARY mo_ta = BINARY 'Áo thun basic dễ mặc, chất vải cotton mềm mại, phù hợp phối đồ mỗi ngày.'
  AND BINARY thong_so = BINARY 'Chất liệu: Cotton\nKiểu dáng: Regular fit\nMàu sắc: Trắng\nGợi ý: Phối jeans hoặc kaki';

UPDATE san_pham
SET mo_ta = 'Áo thun cotton đen phom oversize tạo dáng rộng cho phong cách thường ngày. Kết hợp quần jeans ống đứng hoặc chino sáng màu để giữ tổng thể cân đối. Độ rộng đã nằm ở phom áo, vì vậy hãy đối chiếu số đo trước khi quyết định tăng size.',
    thong_so = 'Chất liệu: Cotton; thông tin thành phần chi tiết cần xem trên nhãn.\nPhom dáng: Oversize, dáng rộng theo thiết kế.\nMàu sắc: Đen.\nPhối đồ: Jeans ống đứng, chino be; dùng phụ kiện đơn giản để giữ điểm nhấn.\nHoàn cảnh: Đi học, dạo phố, gặp bạn bè.\nChăm sóc tham khảo: Lộn trái khi giặt, tránh chất tẩy mạnh; ưu tiên hướng dẫn của nhãn.\nGợi ý size mẫu: So ngang ngực và dài áo với áo oversize đang mặc; không tự tăng size chỉ dựa trên tên phom.'
WHERE BINARY ma_san_pham = BINARY 'SP002'
  AND BINARY ten_san_pham = BINARY 'Áo thun nam Oversize đen'
  AND danh_muc_id = 1
  AND BINARY mo_ta = BINARY 'Thiết kế oversize trẻ trung, tạo cảm giác thoải mái khi vận động.'
  AND BINARY thong_so = BINARY 'Chất liệu: Cotton\nKiểu dáng: Oversize\nMàu sắc: Đen';

UPDATE san_pham
SET mo_ta = 'Áo thun cotton màu kem phom relaxed fit dùng họa tiết graphic làm điểm nhấn cho bộ đồ dạo phố. Quần jeans hoặc cargo đơn sắc giúp phần hình in dễ nổi bật. Có thể thêm nón đen khi muốn bộ trang phục mang tinh thần streetwear.',
    thong_so = 'Chất liệu: Cotton.\nPhom dáng: Relaxed fit, gợi ý mặc rộng nhẹ.\nMàu sắc: Kem; điểm nhấn graphic.\nPhối đồ: Jeans xanh hoặc cargo đen, hạn chế thêm họa tiết lớn.\nHoàn cảnh: Dạo phố, gặp bạn bè và những ngày mặc thoải mái.\nChăm sóc tham khảo: Lộn trái khi giặt; không ủi trực tiếp lên hình in; xem nhãn trước khi làm sạch.\nGợi ý size mẫu: Đối chiếu ngang ngực và dài thân áo; chọn độ rộng theo sở thích sau khi có bảng đo thực tế.'
WHERE BINARY ma_san_pham = BINARY 'SP003'
  AND BINARY ten_san_pham = BINARY 'Áo thun Graphic Streetwear'
  AND danh_muc_id = 1
  AND BINARY mo_ta = BINARY 'Điểm nhấn graphic tối giản dành cho phong cách đường phố.'
  AND BINARY thong_so = BINARY 'Chất liệu: Cotton\nKiểu dáng: Relaxed fit\nMàu sắc: Kem';

UPDATE san_pham
SET mo_ta = 'Áo thun cotton kẻ ngang phom regular fit mang nét gọn gàng cho trang phục cuối tuần. Phối với quần short kaki hoặc jeans trơn để cân bằng họa tiết. Đây là gợi ý cho bộ đồ đi học, đi dạo và những buổi gặp gỡ thoải mái.',
    thong_so = 'Chất liệu: Cotton.\nPhom dáng: Regular fit.\nHọa tiết: Kẻ ngang.\nPhối đồ: Quần short kaki, jeans trơn hoặc chino đơn sắc.\nHoàn cảnh: Mặc thường ngày, đi học, dạo phố cuối tuần.\nChăm sóc tham khảo: Giặt nhẹ và phân loại đồ theo màu; tuân theo nhãn chăm sóc.\nGợi ý size mẫu: Kiểm tra đường vai, ngang ngực và chiều dài áo bằng bảng đo; chưa xác định size chỉ từ chiều cao hoặc cân nặng.'
WHERE BINARY ma_san_pham = BINARY 'SP004'
  AND BINARY ten_san_pham = BINARY 'Áo thun nam kẻ ngang'
  AND danh_muc_id = 1
  AND BINARY mo_ta = BINARY 'Họa tiết kẻ ngang cổ điển, dễ kết hợp cùng quần short hoặc jeans.'
  AND BINARY thong_so = BINARY 'Chất liệu: Cotton\nKiểu dáng: Regular fit\nHọa tiết: Kẻ ngang';

UPDATE san_pham
SET mo_ta = 'Sơ mi cotton Oxford trắng phom regular fit phù hợp bộ đồ nam gọn gàng. Phối với chino và thắt lưng đen cho ngày làm việc, hoặc mặc ngoài áo thun khi đi chơi. Trước khi chọn size, hãy kiểm tra thêm vòng cổ và độ dài tay áo.',
    thong_so = 'Chất liệu: Cotton Oxford.\nPhom dáng: Regular fit.\nMàu sắc: Trắng.\nPhối đồ: Chino be hoặc jeans xanh; thêm thắt lưng cho bộ đồ sơ vin.\nHoàn cảnh: Công sở có trang phục linh hoạt, gặp gỡ và sinh hoạt thường ngày.\nChăm sóc tham khảo: Phân loại đồ trắng, giặt theo nhãn và chỉnh cổ, nẹp áo trước khi phơi.\nGợi ý size mẫu: Đối chiếu vòng cổ, rộng vai, ngang ngực và dài tay; chọn áo đủ khoảng cử động khi cài nút.'
WHERE BINARY ma_san_pham = BINARY 'SP005'
  AND BINARY ten_san_pham = BINARY 'Sơ mi Oxford trắng'
  AND danh_muc_id = 2
  AND BINARY mo_ta = BINARY 'Sơ mi Oxford thanh lịch, phù hợp môi trường công sở và những dịp cần chỉn chu.'
  AND BINARY thong_so = BINARY 'Chất liệu: Cotton Oxford\nKiểu dáng: Regular fit\nMàu sắc: Trắng';

UPDATE san_pham
SET mo_ta = 'Sơ mi denim xanh phom regular fit có thể mặc cài nút hoặc khoác ngoài áo thun trắng. Kết hợp chino be để tạo tương phản chất liệu, hoặc jeans khác sắc độ cho cách phối denim. Nếu mặc nhiều lớp, hãy tính thêm độ rộng cho áo bên trong.',
    thong_so = 'Chất liệu: Denim.\nPhom dáng: Regular fit.\nMàu sắc: Xanh denim.\nPhối đồ: Áo thun trắng và chino be; jeans khác sắc độ khi phối cùng denim.\nHoàn cảnh: Đi học, dạo phố và trang phục thường ngày.\nChăm sóc tham khảo: Giặt riêng đồ denim khi cần, tránh chất tẩy mạnh; ưu tiên chỉ dẫn trên nhãn.\nGợi ý size mẫu: So rộng vai, ngang ngực và dài tay; kiểm tra khoảng trống nếu dùng làm áo khoác ngoài.'
WHERE BINARY ma_san_pham = BINARY 'SP006'
  AND BINARY ten_san_pham = BINARY 'Sơ mi nam Denim xanh'
  AND danh_muc_id = 2
  AND BINARY mo_ta = BINARY 'Chất denim mềm, mang lại vẻ ngoài năng động và nam tính.'
  AND BINARY thong_so = BINARY 'Chất liệu: Denim\nKiểu dáng: Regular fit\nMàu sắc: Xanh denim';

UPDATE san_pham
SET mo_ta = 'Sơ mi linen pha màu be phom relaxed fit hướng tới cách mặc nhẹ nhàng trong ngày ấm. Phối với quần chino hoặc short kaki để có bộ đồ đơn giản, sáng màu. Dáng rộng nhẹ và nếp vải tự nhiên là những yếu tố nên cân nhắc khi chọn phong cách.',
    thong_so = 'Chất liệu: Linen blend; tỷ lệ sợi cần xem nhãn sản phẩm.\nPhom dáng: Relaxed fit, tay dài.\nMàu sắc: Be.\nPhối đồ: Chino, short kaki hoặc áo thun sáng màu mặc bên trong.\nHoàn cảnh: Dạo phố, gặp bạn bè và những dịp mặc thường ngày.\nChăm sóc tham khảo: Giặt và ủi theo nhãn; tránh vặn xoắn mạnh, chỉnh phom trước khi phơi.\nGợi ý size mẫu: Đối chiếu ngang ngực, vai và dài tay; xác định mức rộng mong muốn bằng số đo áo thực tế.'
WHERE BINARY ma_san_pham = BINARY 'SP007'
  AND BINARY ten_san_pham = BINARY 'Sơ mi Linen tay dài'
  AND danh_muc_id = 2
  AND BINARY mo_ta = BINARY 'Vải linen thoáng mát, thích hợp cho ngày hè và phong cách tối giản.'
  AND BINARY thong_so = BINARY 'Chất liệu: Linen blend\nKiểu dáng: Relaxed fit\nMàu sắc: Be';

UPDATE san_pham
SET mo_ta = 'Áo polo pique cotton màu navy phom regular fit giúp bộ đồ nam có điểm nhấn ở phần cổ. Kết hợp chino be khi cần gọn gàng, hoặc short kaki cho buổi đi chơi. Màu áo trầm dễ làm nền cho quần sáng màu và phụ kiện tối giản.',
    thong_so = 'Chất liệu: Pique cotton.\nPhom dáng: Regular fit, cổ polo.\nMàu sắc: Navy.\nPhối đồ: Chino be, short kaki xám hoặc jeans xanh.\nHoàn cảnh: Đi làm với trang phục linh hoạt, đi học và gặp gỡ cuối tuần.\nChăm sóc tham khảo: Giặt theo nhãn, chỉnh cổ áo trước khi phơi và tránh kéo giãn phần cổ.\nGợi ý size mẫu: Kiểm tra rộng vai, ngang ngực, dài áo và độ ôm bắp tay bằng bảng đo thực tế.'
WHERE BINARY ma_san_pham = BINARY 'SP008'
  AND BINARY ten_san_pham = BINARY 'Áo polo nam Classic Navy'
  AND danh_muc_id = 3
  AND BINARY mo_ta = BINARY 'Áo polo cổ bẻ cổ điển, dễ mặc từ đi làm đến đi chơi.'
  AND BINARY thong_so = BINARY 'Chất liệu: Pique cotton\nKiểu dáng: Regular fit\nMàu sắc: Navy';

UPDATE san_pham
SET mo_ta = 'Áo polo pique cotton màu kem phom regular fit dành cho cách phối màu sáng và gọn. Mặc cùng jeans xanh đậm hoặc chino để tạo sự cân đối. Khi thử áo, chú ý phần vai và tay áo để chọn độ vừa phù hợp với cách mặc sơ vin hoặc thả ngoài.',
    thong_so = 'Chất liệu: Pique cotton.\nPhom dáng: Regular fit, cổ polo.\nMàu sắc: Kem.\nPhối đồ: Jeans xanh, chino và thắt lưng đen khi sơ vin.\nHoàn cảnh: Đi học, gặp gỡ bạn bè hoặc ngày làm việc với trang phục linh hoạt.\nChăm sóc tham khảo: Phân loại đồ sáng màu, xử lý vết bẩn theo nhãn và tránh chất tẩy không phù hợp.\nGợi ý size mẫu: Đối chiếu vai, ngang ngực, bắp tay và dài áo; chưa có bảng số đo để xác nhận size cụ thể.'
WHERE BINARY ma_san_pham = BINARY 'SP009'
  AND BINARY ten_san_pham = BINARY 'Áo polo nam Pique kem'
  AND danh_muc_id = 3
  AND BINARY mo_ta = BINARY 'Bề mặt vải pique thoáng khí, màu kem trang nhã và dễ phối.'
  AND BINARY thong_so = BINARY 'Chất liệu: Pique cotton\nKiểu dáng: Regular fit\nMàu sắc: Kem';

UPDATE san_pham
SET mo_ta = 'Áo polo cotton pha xanh rêu phom slim fit tạo đường nét gọn cho trang phục hằng ngày. Kết hợp short kaki xám hoặc jeans để giữ tinh thần năng động. Tên phong cách Sport không thay thế thông tin về tính năng chuyên dụng của chất liệu.',
    thong_so = 'Chất liệu: Cotton blend; tỷ lệ thành phần cần đối chiếu nhãn.\nPhom dáng: Slim fit, cổ polo.\nMàu sắc: Xanh rêu.\nPhối đồ: Short kaki xám, jeans xanh hoặc chino be.\nHoàn cảnh: Mặc thường ngày, đi học và đi chơi; chưa có thông số trang phục thể thao chuyên dụng.\nChăm sóc tham khảo: Giặt theo nhãn, lộn trái khi cần và tránh sấy nhiệt không phù hợp.\nGợi ý size mẫu: Ưu tiên số đo ngực và bắp tay; phom slim vẫn cần đủ khoảng cử động, không chốt size từ cân nặng đơn lẻ.'
WHERE BINARY ma_san_pham = BINARY 'SP010'
  AND BINARY ten_san_pham = BINARY 'Áo polo nam Sport xanh rêu'
  AND danh_muc_id = 3
  AND BINARY mo_ta = BINARY 'Phong cách thể thao gọn gàng, phù hợp hoạt động hằng ngày.'
  AND BINARY thong_so = BINARY 'Chất liệu: Cotton blend\nKiểu dáng: Slim fit\nMàu sắc: Xanh rêu';

UPDATE san_pham
SET mo_ta = 'Quần chino kaki cotton màu be phom straight fit tạo dáng ống đứng cho tủ đồ nam. Phối với áo polo navy khi đi làm, hoặc áo thun trắng cho ngày nghỉ. Hãy kiểm tra vòng eo, đùi và chiều dài ống theo kiểu mặc sơ vin hoặc thả áo bạn thích.',
    thong_so = 'Chất liệu: Kaki cotton.\nPhom dáng: Straight fit, ống đứng.\nMàu sắc: Be.\nPhối đồ: Polo navy, áo thun trắng hoặc sơ mi Oxford.\nHoàn cảnh: Đi học, công sở có trang phục linh hoạt và gặp gỡ thường ngày.\nChăm sóc tham khảo: Giặt theo nhãn, làm sạch túi và chỉnh đường ống trước khi phơi.\nGợi ý size mẫu: Đo vòng eo, mông, đùi và dài ống của quần đang vừa; cần bảng đo thực tế trước khi chọn cỡ.'
WHERE BINARY ma_san_pham = BINARY 'SP011'
  AND BINARY ten_san_pham = BINARY 'Quần Chino nam màu be'
  AND danh_muc_id = 4
  AND BINARY mo_ta = BINARY 'Quần chino phom đứng, linh hoạt khi phối cùng áo thun hoặc sơ mi.'
  AND BINARY thong_so = BINARY 'Chất liệu: Kaki cotton\nKiểu dáng: Straight fit\nMàu sắc: Be';

UPDATE san_pham
SET mo_ta = 'Quần jeans denim xanh phom straight fit là lựa chọn ống đứng cho bộ đồ thường ngày. Có thể phối với áo thun graphic khi dạo phố hoặc sơ mi Oxford khi cần gọn gàng hơn. Độ vừa ở eo và đùi nên được kiểm tra cùng chiều dài ống.',
    thong_so = 'Chất liệu: Denim.\nPhom dáng: Straight fit, ống đứng.\nMàu sắc: Xanh denim.\nPhối đồ: Áo thun graphic, polo trơn hoặc sơ mi Oxford trắng.\nHoàn cảnh: Đi học, dạo phố và gặp bạn bè.\nChăm sóc tham khảo: Giặt theo nhãn, phân loại màu và tránh chất tẩy mạnh; không mặc định denim không ra màu.\nGợi ý size mẫu: Đối chiếu vòng eo, đùi, chiều cao cạp và dài ống; chưa có tỷ lệ co giãn để suy ra cỡ mặc.'
WHERE BINARY ma_san_pham = BINARY 'SP012'
  AND BINARY ten_san_pham = BINARY 'Quần Jeans nam Straight xanh'
  AND danh_muc_id = 4
  AND BINARY mo_ta = BINARY 'Quần jeans ống đứng cơ bản, dễ ứng dụng trong nhiều phong cách.'
  AND BINARY thong_so = BINARY 'Chất liệu: Denim\nKiểu dáng: Straight fit\nMàu sắc: Xanh denim';

UPDATE san_pham
SET mo_ta = 'Quần cargo kaki đen có dáng túi hộp làm điểm nhấn cho trang phục dạo phố. Phối với áo thun trơn hoặc hoodie để cân đối phần túi và độ rộng của quần. Khi chọn cỡ, chú ý không gian ở đùi và đầu gối để có khoảng cử động phù hợp.',
    thong_so = 'Chất liệu: Kaki.\nPhom dáng: Cargo fit với chi tiết túi hộp.\nMàu sắc: Đen.\nPhối đồ: Áo thun trắng hoặc đen, hoodie xám; tiết chế họa tiết lớn.\nHoàn cảnh: Đi học, dạo phố và sinh hoạt thường ngày.\nChăm sóc tham khảo: Lấy hết vật trong túi, giặt theo nhãn và chỉnh nắp túi trước khi phơi.\nGợi ý size mẫu: Đối chiếu vòng eo, mông, đùi và dài quần; kiểm tra độ rộng khi ngồi hoặc bước đi.'
WHERE BINARY ma_san_pham = BINARY 'SP013'
  AND BINARY ten_san_pham = BINARY 'Quần Cargo nam đen'
  AND danh_muc_id = 4
  AND BINARY mo_ta = BINARY 'Thiết kế túi hộp tiện dụng, tạo điểm nhấn khỏe khoắn.'
  AND BINARY thong_so = BINARY 'Chất liệu: Kaki\nKiểu dáng: Cargo fit\nMàu sắc: Đen';

UPDATE san_pham
SET mo_ta = 'Quần short kaki cotton xám phom regular fit phù hợp bộ đồ cuối tuần gọn nhẹ. Kết hợp polo hoặc áo thun kẻ ngang khi đi dạo và gặp bạn bè. Hãy đối chiếu chiều dài quần thực tế với sở thích về vị trí gấu, cùng độ vừa ở eo và đùi.',
    thong_so = 'Chất liệu: Kaki cotton.\nPhom dáng: Regular fit, quần short.\nMàu sắc: Xám.\nPhối đồ: Polo navy, áo thun trắng hoặc áo thun kẻ ngang.\nHoàn cảnh: Đi dạo, đi chơi và những ngày nghỉ với trang phục thoải mái.\nChăm sóc tham khảo: Kiểm tra túi, giặt nhẹ theo nhãn và phơi ở nơi thông thoáng.\nGợi ý size mẫu: Đo vòng eo, mông, đùi và dài quần; chọn vị trí gấu theo số đo thực tế, không suy từ ảnh minh họa.'
WHERE BINARY ma_san_pham = BINARY 'SP014'
  AND BINARY ten_san_pham = BINARY 'Quần short kaki nam'
  AND danh_muc_id = 4
  AND BINARY mo_ta = BINARY 'Quần short gọn nhẹ cho những chuyến đi và ngày nghỉ cuối tuần.'
  AND BINARY thong_so = BINARY 'Chất liệu: Kaki cotton\nKiểu dáng: Regular fit\nMàu sắc: Xám';

UPDATE san_pham
SET mo_ta = 'Áo khoác vải dù đen kiểu bomber là lớp ngoài cho bộ đồ nam khi trời se lạnh. Phối áo thun trắng và jeans, hoặc khoác cùng chino để tạo tổng thể gọn. Khoảng rộng vai và ngực cần tính thêm lớp áo bên trong khi lựa chọn kích cỡ.',
    thong_so = 'Chất liệu: Vải dù; chưa có thông số chống nước hoặc giữ nhiệt.\nPhom dáng: Bomber.\nMàu sắc: Đen.\nPhối đồ: Áo thun trắng, jeans xanh hoặc chino be.\nHoàn cảnh: Mặc nhiều lớp khi thời tiết se lạnh, đi học và dạo phố.\nChăm sóc tham khảo: Đóng khóa trước khi giặt nếu nhãn hướng dẫn; tránh nhiệt cao không phù hợp với vải.\nGợi ý size mẫu: So vai, ngang ngực, dài tay và dài áo; chừa khoảng cho áo bên trong theo bảng đo thực tế.'
WHERE BINARY ma_san_pham = BINARY 'SP015'
  AND BINARY ten_san_pham = BINARY 'Áo khoác Bomber nam'
  AND danh_muc_id = 5
  AND BINARY mo_ta = BINARY 'Áo khoác bomber tối giản, phù hợp phối layer trong thời tiết se lạnh.'
  AND BINARY thong_so = BINARY 'Chất liệu: Vải dù\nKiểu dáng: Bomber\nMàu sắc: Đen';

UPDATE san_pham
SET mo_ta = 'Áo hoodie nỉ cotton xám phom oversize dành cho cách mặc nhiều lớp với dáng rộng. Kết hợp jeans ống đứng hoặc cargo đen cho ngày đi học và dạo phố. Khi chọn áo, hãy xem chiều dài thân và tay để độ rộng không làm mất cân đối bộ đồ.',
    thong_so = 'Chất liệu: Nỉ cotton.\nPhom dáng: Oversize, kiểu hoodie.\nMàu sắc: Xám.\nPhối đồ: Jeans ống đứng, cargo đen hoặc áo thun làm lớp trong.\nHoàn cảnh: Đi học, dạo phố và mặc nhiều lớp khi trời se lạnh.\nChăm sóc tham khảo: Lộn trái, giặt theo nhãn và tránh kéo giãn phần bo khi phơi.\nGợi ý size mẫu: Đối chiếu ngang ngực, dài thân và dài tay; kiểm tra độ rộng với lớp áo bên trong, không tự tăng cỡ.'
WHERE BINARY ma_san_pham = BINARY 'SP016'
  AND BINARY ten_san_pham = BINARY 'Áo Hoodie nam màu xám'
  AND danh_muc_id = 5
  AND BINARY mo_ta = BINARY 'Hoodie nỉ mềm, thiết kế basic cho phong cách thường ngày.'
  AND BINARY thong_so = BINARY 'Chất liệu: Nỉ cotton\nKiểu dáng: Oversize\nMàu sắc: Xám';

UPDATE san_pham
SET mo_ta = 'Áo cardigan len dệt màu nâu phom regular fit mang nét nhẹ nhàng cho bộ đồ nhiều lớp. Mặc cùng áo thun sáng màu và chino, hoặc khoác ngoài sơ mi Oxford khi gặp gỡ. Độ rộng vai và chiều dài áo cần phù hợp với lớp áo bạn dự định mặc bên trong.',
    thong_so = 'Chất liệu: Len dệt; thành phần sợi cụ thể cần xem nhãn.\nPhom dáng: Regular fit, kiểu cardigan.\nMàu sắc: Nâu.\nPhối đồ: Áo thun trắng, sơ mi Oxford và quần chino.\nHoàn cảnh: Gặp gỡ bạn bè, không gian làm việc có trang phục linh hoạt, ngày se lạnh.\nChăm sóc tham khảo: Làm sạch theo nhãn đồ dệt, tránh vặn mạnh hoặc treo khi còn nặng nước; chỉnh phom khi phơi.\nGợi ý size mẫu: So vai, ngang ngực, dài áo và tay; kiểm tra khoảng rộng nếu mặc cùng sơ mi.'
WHERE BINARY ma_san_pham = BINARY 'SP017'
  AND BINARY ten_san_pham = BINARY 'Áo khoác Cardigan nam'
  AND danh_muc_id = 5
  AND BINARY mo_ta = BINARY 'Cardigan nhẹ nhàng, dễ phối cùng áo thun và sơ mi.'
  AND BINARY thong_so = BINARY 'Chất liệu: Len dệt\nKiểu dáng: Regular fit\nMàu sắc: Nâu';

UPDATE san_pham
SET mo_ta = 'Thắt lưng da tổng hợp đen bản 3,2 cm giúp hoàn thiện bộ đồ nam với thiết kế khóa kim loại tối giản. Có thể phối cùng chino hoặc jeans khi sơ vin áo. Hãy kiểm tra chiều dài dây và độ rộng đỉa quần trước khi chọn phụ kiện.',
    thong_so = 'Chất liệu: Da tổng hợp; không mô tả là da thật.\nThiết kế: Thắt lưng khóa kim loại, phong cách tối giản.\nBản dây: 3,2 cm theo dữ liệu mẫu.\nMàu sắc: Đen.\nPhối đồ và sử dụng: Chino, jeans và các bộ đồ sơ vin áo thun, polo hoặc sơ mi.\nChăm sóc tham khảo: Lau bằng khăn phù hợp, để khô tự nhiên; tránh ngâm nước và tuân theo nhãn sản phẩm.\nGợi ý kích cỡ mẫu: Đối chiếu vòng eo, độ dài thắt lưng đang dùng và đỉa quần; chưa có chiều dài dây để xác nhận cỡ.'
WHERE BINARY ma_san_pham = BINARY 'SP018'
  AND BINARY ten_san_pham = BINARY 'Thắt lưng da nam tối giản'
  AND danh_muc_id = 6
  AND BINARY mo_ta = BINARY 'Phụ kiện cơ bản với thiết kế khóa kim loại thanh lịch.'
  AND BINARY thong_so = BINARY 'Chất liệu: Da tổng hợp\nBản dây: 3.2 cm\nMàu sắc: Đen';

UPDATE san_pham
SET mo_ta = 'Nón lưỡi trai cotton đen MENS STORE có thiết kế điều chỉnh để bổ sung điểm nhấn cho bộ đồ thường ngày. Phối cùng áo thun, jeans hoặc quần short khi dạo phố. Kiểm tra vòng đầu và khoảng điều chỉnh thực tế trước khi chọn, thay vì mặc định vừa mọi người.',
    thong_so = 'Chất liệu: Cotton.\nThiết kế: Nón lưỡi trai có phần điều chỉnh.\nMàu sắc: Đen.\nPhối đồ: Áo thun basic, áo graphic, jeans hoặc quần short.\nHoàn cảnh: Dạo phố và trang phục thường ngày; chưa có chỉ số bảo vệ UV được công bố.\nChăm sóc tham khảo: Làm sạch theo nhãn, giữ phom vành nón, tránh vặn xoắn.\nGợi ý kích cỡ mẫu: Đo vòng đầu và đối chiếu dải điều chỉnh của nón; dữ liệu mẫu chưa nêu dải số đo cụ thể.'
WHERE BINARY ma_san_pham = BINARY 'SP019'
  AND BINARY ten_san_pham = BINARY 'Nón lưỡi trai MENS STORE'
  AND danh_muc_id = 6
  AND BINARY mo_ta = BINARY 'Nón lưỡi trai phong cách tối giản, dễ phối đồ dạo phố.'
  AND BINARY thong_so = BINARY 'Chất liệu: Cotton\nKiểu dáng: Adjustable\nMàu sắc: Đen';

UPDATE san_pham
SET mo_ta = 'Túi tote canvas màu natural là phụ kiện cho bộ đồ đi học, đi dạo và các việc hằng ngày. Phối với áo thun, sơ mi khoác ngoài hoặc nón đen để giữ tổng thể đơn giản. Trước khi mang đồ, kiểm tra kích thước túi và giới hạn tải của sản phẩm thực tế.',
    thong_so = 'Chất liệu: Canvas.\nThiết kế: Túi tote.\nMàu sắc: Natural.\nPhối đồ: Áo thun basic, sơ mi khoác ngoài và jeans hoặc chino.\nHoàn cảnh: Đi học, đi dạo và mang vật dụng hằng ngày phù hợp kích thước túi.\nChăm sóc tham khảo: Làm sạch theo nhãn, chỉnh phom sau khi giặt và để khô tự nhiên.\nGợi ý kích thước mẫu: Đối chiếu chiều rộng, cao và đáy túi với vật cần mang.'
WHERE BINARY ma_san_pham = BINARY 'SP020'
  AND BINARY ten_san_pham = BINARY 'Túi tote canvas nam'
  AND danh_muc_id = 6
  AND BINARY mo_ta = BINARY 'Túi canvas tiện dụng cho nhu cầu hằng ngày.'
  AND BINARY thong_so = BINARY 'Chất liệu: Canvas\nKiểu dáng: Tote\nMàu sắc: Natural';

COMMIT;
