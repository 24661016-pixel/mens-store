-- MENS STORE v2: nâng cấp database hiện có, giữ nguyên dữ liệu.
-- Dành cho schema trong mens-store-project.zip và các lần nâng cấp lại từ v2.
-- Tương thích MySQL 8+ / MariaDB 10.11+. Chọn đúng database trước khi chạy.
-- Ví dụ từ thư mục dự án:
--   mysql -u mens_store -p mens_store_db < sql/upgrade_v2.sql
-- Sao lưu database trước khi chạy. DDL tự commit; không dùng ROLLBACK để hoàn tác.
-- Script không xóa bảng, không seed lại sản phẩm, không sửa email/mật khẩu cũ,
-- không suy đoán chủ sở hữu đơn cũ từ số điện thoại hoặc thông tin nhận hàng.
-- Những đơn cũ giữ tai_khoan_id = NULL; quản trị vẫn xem và xử lý được.
-- Các tài khoản cũ có dia_chi rỗng, ngay_sinh NULL, mat_khau_version = 0.
-- Email nội bộ cũ cần được chủ tài khoản/quản trị viên xác minh và cập nhật
-- thành email thật trước khi dùng chức năng khôi phục mật khẩu qua email.

SET NAMES utf8mb4;
SET @mens_store_schema = DATABASE();

-- Hỗ trợ cả bản cũ chưa có bảng tài khoản. Không thay thế bảng đang tồn tại.
CREATE TABLE IF NOT EXISTS tai_khoan (
  tai_khoan_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  ho_ten VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL,
  so_dien_thoai VARCHAR(20) NOT NULL,
  dia_chi VARCHAR(255) NOT NULL DEFAULT '',
  ngay_sinh DATE NULL,
  mat_khau_version INT NOT NULL DEFAULT 0,
  mat_khau_hash VARCHAR(100) NOT NULL,
  trang_thai TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_tai_khoan_email(email),
  UNIQUE KEY uq_tai_khoan_phone(so_dien_thoai)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Địa chỉ hồ sơ; giá trị mặc định rỗng giữ nguyên tài khoản lịch sử.
SET @mens_store_ddl = IF(
  NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'tai_khoan' AND COLUMN_NAME = 'dia_chi'),
  'ALTER TABLE tai_khoan ADD COLUMN dia_chi VARCHAR(255) NOT NULL DEFAULT '''' AFTER so_dien_thoai',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Ngày sinh không bắt buộc.
SET @mens_store_ddl = IF(
  NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'tai_khoan' AND COLUMN_NAME = 'ngay_sinh'),
  'ALTER TABLE tai_khoan ADD COLUMN ngay_sinh DATE NULL AFTER dia_chi',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Phiên bản mật khẩu để thu hồi phiên đăng nhập sau khi đổi mật khẩu.
SET @mens_store_ddl = IF(
  NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'tai_khoan' AND COLUMN_NAME = 'mat_khau_version'),
  'ALTER TABLE tai_khoan ADD COLUMN mat_khau_version INT NOT NULL DEFAULT 0 AFTER ngay_sinh',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Chỉ nới chiều dài email nhận hàng; không thu hẹp cột đã lớn hơn 150.
SET @mens_store_ddl = IF(
  EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'khach_hang' AND COLUMN_NAME = 'email'
      AND DATA_TYPE = 'varchar' AND CHARACTER_MAXIMUM_LENGTH < 150),
  'ALTER TABLE khach_hang MODIFY COLUMN email VARCHAR(150) NULL',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Thêm chủ sở hữu cho đơn mới; mọi đơn lịch sử được giữ NULL.
SET @mens_store_ddl = IF(
  NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'don_hang' AND COLUMN_NAME = 'tai_khoan_id'),
  'ALTER TABLE don_hang ADD COLUMN tai_khoan_id BIGINT NULL AFTER ma_don_hang',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Tạo chỉ mục chủ sở hữu nếu chưa có chỉ mục bắt đầu bằng cột này.
SET @mens_store_ddl = IF(
  NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'don_hang'
      AND COLUMN_NAME = 'tai_khoan_id' AND SEQ_IN_INDEX = 1),
  'ALTER TABLE don_hang ADD INDEX idx_dh_tai_khoan(tai_khoan_id)',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Khóa ngoại đơn hàng/tài khoản; NULL lịch sử vẫn hợp lệ.
SET @mens_store_ddl = IF(
  NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'don_hang'
      AND COLUMN_NAME = 'tai_khoan_id' AND REFERENCED_TABLE_SCHEMA = @mens_store_schema
      AND REFERENCED_TABLE_NAME = 'tai_khoan' AND REFERENCED_COLUMN_NAME = 'tai_khoan_id'),
  'ALTER TABLE don_hang ADD CONSTRAINT fk_dh_tk FOREIGN KEY(tai_khoan_id) REFERENCES tai_khoan(tai_khoan_id)',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Bản ZIP gốc đã có ENUM COD/CHUYEN_KHOAN. Trường hợp bản cũ chỉ có
-- COD thì bổ sung CHUYEN_KHOAN; không loại bỏ hay diễn giải lại giá trị khác.

-- Mở rộng ENUM chỉ gồm COD mà không đổi giá trị dữ liệu hiện có.
SET @mens_store_ddl = IF(
  EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'don_hang'
      AND COLUMN_NAME = 'phuong_thuc_thanh_toan' AND COLUMN_TYPE = 'enum(''COD'')'),
  'ALTER TABLE don_hang MODIFY COLUMN phuong_thuc_thanh_toan ENUM(''COD'',''CHUYEN_KHOAN'') NOT NULL DEFAULT ''COD''',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Bổ sung trạng thái thanh toán cho bản cũ chưa có cột này.
SET @mens_store_ddl = IF(
  NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'don_hang' AND COLUMN_NAME = 'trang_thai_thanh_toan'),
  'ALTER TABLE don_hang ADD COLUMN trang_thai_thanh_toan ENUM(''CHUA_THANH_TOAN'',''CHO_KIEM_TRA'',''DA_THANH_TOAN'') NOT NULL DEFAULT ''CHUA_THANH_TOAN''',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Thời điểm quản trị xác nhận đã nhận tiền.
SET @mens_store_ddl = IF(
  NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'don_hang' AND COLUMN_NAME = 'thoi_gian_thanh_toan'),
  'ALTER TABLE don_hang ADD COLUMN thoi_gian_thanh_toan DATETIME NULL',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Tham chiếu giao dịch do quản trị nhập sau đối soát.
SET @mens_store_ddl = IF(
  NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = @mens_store_schema AND TABLE_NAME = 'don_hang' AND COLUMN_NAME = 'ma_giao_dich_ngan_hang'),
  'ALTER TABLE don_hang ADD COLUMN ma_giao_dich_ngan_hang VARCHAR(100) NULL',
  'SELECT 1 AS mens_store_v2_already_applied'
);
PREPARE mens_store_v2_stmt FROM @mens_store_ddl;
EXECUTE mens_store_v2_stmt;
DEALLOCATE PREPARE mens_store_v2_stmt;

-- Các bảng mới. IF NOT EXISTS giữ nguyên mọi dữ liệu nếu chạy lại.
CREATE TABLE IF NOT EXISTS gio_hang (
  tai_khoan_id BIGINT NOT NULL,
  san_pham_id INT NOT NULL,
  so_luong INT NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(tai_khoan_id, san_pham_id),
  FOREIGN KEY(tai_khoan_id) REFERENCES tai_khoan(tai_khoan_id),
  FOREIGN KEY(san_pham_id) REFERENCES san_pham(san_pham_id),
  CHECK(so_luong BETWEEN 1 AND 99)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tai_khoan_id BIGINT NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(tai_khoan_id) REFERENCES tai_khoan(tai_khoan_id),
  INDEX idx_reset_account(tai_khoan_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS binh_luan (
  binh_luan_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tai_khoan_id BIGINT NOT NULL,
  san_pham_id INT NOT NULL,
  noi_dung VARCHAR(1000) NOT NULL,
  trang_thai VARCHAR(20) NOT NULL DEFAULT 'CHO_DUYET',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(tai_khoan_id) REFERENCES tai_khoan(tai_khoan_id),
  FOREIGN KEY(san_pham_id) REFERENCES san_pham(san_pham_id),
  INDEX idx_comment_product(san_pham_id, trang_thai)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS khuyen_mai (
  khuyen_mai_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  ma_khuyen_mai VARCHAR(30) NOT NULL UNIQUE,
  ten_khuyen_mai VARCHAR(120) NOT NULL,
  phan_tram_giam INT NOT NULL,
  bat_dau DATE NOT NULL,
  ket_thuc DATE NOT NULL,
  trang_thai TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK(phan_tram_giam BETWEEN 1 AND 80),
  CHECK(ket_thuc >= bat_dau)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Không gán don_hang.tai_khoan_id cho đơn lịch sử tại đây.
-- Không sửa email nội bộ cũ hoặc tạo mật khẩu thay thế tại đây.
SELECT 'MENS STORE v2: hoàn thành nâng cấp cấu trúc; dữ liệu hiện có được giữ nguyên.' AS migration_status;
SET @mens_store_ddl = NULL;
SET @mens_store_schema = NULL;
