# MENS STORE 2.1.1 — Bản mã nguồn gọn cho GitHub

Java 21, Spring Boot MVC, Thymeleaf, Spring Security và MySQL. Package `com.example.mens_store`. Database `mens_store_db`.

Bản này giữ nguyên toàn bộ mã ứng dụng trong `src/main/`, 28 template, 20 hình sản phẩm, thư viện giao diện cục bộ, Docker, Maven Wrapper và SQL cần thiết của bản 2.1.1. Không thay đổi chức năng hay dữ liệu mẫu. Đã bỏ JAR biên dịch sẵn, 16 tệp kiểm thử, workflow CI chạy bộ kiểm thử, 5 tài liệu rời và 2 script hướng dẫn migration đã được thay thế. Các tệp này vẫn có trong ZIP 2.1.1 gốc; hãy giữ bản gốc để chạy lại kiểm thử và tra cứu.

## Đưa lên GitHub bằng giao diện web

GitHub giới hạn số tệp mỗi lượt upload. Bản mã nguồn gọn vẫn có hơn 100 tệp vì giữ đủ tính năng. Có thể dùng hai ZIP `mens-store-github-phan-1.zip` và `mens-store-github-phan-2.zip` đi kèm: giải nén từng ZIP vào thư mục riêng. Tạo repository mới, chọn Add file > Upload files và kéo **nội dung bên trong** thư mục phần 1 vào gốc repository, rồi Commit changes. Lặp lại với phần 2 tại gốc cùng repository. Hai phần có các đường dẫn bổ sung cho nhau, không trùng tệp. Không kéo nguyên thư mục mang tên phần 1/phần 2. Sau đó kiểm tra `pom.xml`, `compose.yaml`, `.devcontainer/`, `src/main/java/` và `src/main/resources/` đều có đúng vị trí. Không upload `.env` chứa mật khẩu thật.

Hoặc tải **một** file `mens-store-github.zip` lên repository mới, commit, rồi mở Codespaces; trong Terminal chạy:

```bash
unzip -q mens-store-github.zip
cp -a mens-store/. .
# Chi xoa thu muc tam vua giai nen sau khi da sao chep thanh cong.
rm -r mens-store
git rm mens-store-github.zip
git add .
git update-index --chmod=+x mvnw
git commit -m "Add MENS STORE source code"
git push
```

Chỉ dùng cách trên ở repository mới, nơi chưa có thư mục `mens-store/` hoặc mã nguồn cần giữ. Không ghi đè dự án cũ. Nếu cần, mở Command Palette (Ctrl+Shift+P), chọn Codespaces: Rebuild Container để áp dụng cấu hình Java 21 và Docker mới được đưa vào repository.

## Chạy nhanh trên GitHub Codespaces

1. Chọn Code > Codespaces > Create codespace on main. Mở Terminal tại thư mục có `pom.xml` và `compose.yaml`.
2. Chạy `cp .env.example .env`, mở `.env` và thay ba mật khẩu mẫu `MYSQL_ROOT_PASSWORD`, `MYSQL_PASSWORD`, `APP_ADMIN_PASSWORD` bằng mật khẩu riêng.
3. Chạy `docker compose up -d --build`. Kiểm tra bằng `docker compose ps` và `docker compose logs -f web` (Ctrl+C thoát xem log, container vẫn chạy).
4. Mở tab PORTS, chuyển tiếp cổng 8080 nếu chưa có, rồi Open in Browser. Giữ port Private khi kiểm thử. Không dùng `docker compose down -v` vì xóa dữ liệu database.

## Chức năng giữ nguyên

- Trang chủ `home.mens.html`, danh sách/chi tiết, 6 danh mục và 20 sản phẩm mẫu.
- Tài khoản khách đăng ký bằng họ tên, email, điện thoại, địa chỉ, mật khẩu và xác nhận; ngày sinh tùy chọn. Đăng nhập bằng điện thoại/mật khẩu, BCrypt, đăng xuất và quên mật khẩu qua email.
- Giỏ hàng trong database theo tài khoản, checkout kiểm tra giá/tồn kho và chống đặt trùng, COD/QR, lịch sử đơn.
- Quản trị danh mục, sản phẩm, khách hàng, đơn, doanh thu, bình luận, khuyến mãi và AI tùy chọn. Khuyến mãi chưa tự giảm giá tại checkout; dữ liệu lịch sử được quản lý theo nghiệp vụ, không CRUD tùy ý mọi bảng.
- QR cần đúng ngân hàng/BIN/chủ tài khoản; email thật cần SMTP; AI cần key/model. Giá, ảnh SVG và tồn kho là dữ liệu mẫu. Tồn kho theo sản phẩm, chưa tách riêng SKU size/màu.

## Cách 1 — Docker Compose

Cần Docker và Docker Compose. Trong thư mục chứa `compose.yaml`:

```bash
cp .env.example .env
```

Trên Windows PowerShell, dùng `Copy-Item .env.example .env`. Mở `.env`, thay `MYSQL_ROOT_PASSWORD`, `MYSQL_PASSWORD`, `APP_ADMIN_PASSWORD` bằng mật khẩu riêng, rồi chạy:

```bash
docker compose up --build
```

Mở **http://localhost:8080**. MySQL tạo bảng và dữ liệu mẫu khi volume được tạo lần đầu. `.env` được Compose đọc; không đặt mật khẩu thật vào source code.

Nếu đã có volume của bản trước, cần chạy migration như mục **Nâng cấp dữ liệu cũ**. Khởi động lại container không tự chạy lại script khởi tạo trên volume cũ.

## Cách 2 — Java/Maven và MySQL trên máy

Cần **JDK 21 đầy đủ** (có `java` và `javac`), MySQL 8 hoặc MariaDB 10.11. Dự án có Maven Wrapper; lần chạy đầu cần mạng để tải Maven/dependencies. Nếu có Maven 3.9+, có thể thay `./mvnw` bằng `mvn`.

### 1. Tạo database cho bản cài mới

Đăng nhập MySQL bằng tài khoản có quyền tạo database:

```sql
CREATE DATABASE mens_store_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'mens_store'@'localhost' IDENTIFIED BY 'MAT_KHAU_DATABASE_CUA_BAN';
GRANT ALL PRIVILEGES ON mens_store_db.* TO 'mens_store'@'localhost';
```

Nhập SQL (Linux/macOS/CMD):

```bash
mysql -u mens_store -p mens_store_db < sql/mens_store.sql
```

Trong PowerShell, có thể vào `mysql -u mens_store -p mens_store_db`, rồi chạy `SOURCE C:/duong-dan/mens-store/sql/mens_store.sql;` trong MySQL. Không dùng SQL khởi tạo để chuyển một database của dự án khác thành cửa hàng này; hãy tạo database riêng.

### 2. Cấu hình môi trường

Linux/macOS/Codespaces:

```bash
export DB_URL='jdbc:mysql://localhost:3306/mens_store_db?useUnicode=true&characterEncoding=UTF-8&connectionTimeZone=Asia/Ho_Chi_Minh'
export DB_USER='mens_store'
export DB_PASSWORD='MAT_KHAU_DATABASE_CUA_BAN'
export APP_ADMIN_USERNAME='admin'
export APP_ADMIN_PASSWORD='MAT_KHAU_QUAN_TRI_CUA_BAN'
export APP_PUBLIC_BASE_URL='http://localhost:8080'
./mvnw spring-boot:run
```

Windows PowerShell:

```powershell
$env:DB_URL = 'jdbc:mysql://localhost:3306/mens_store_db?useUnicode=true&characterEncoding=UTF-8&connectionTimeZone=Asia/Ho_Chi_Minh'
$env:DB_USER = 'mens_store'
$env:DB_PASSWORD = 'MAT_KHAU_DATABASE_CUA_BAN'
$env:APP_ADMIN_USERNAME = 'admin'
$env:APP_ADMIN_PASSWORD = 'MAT_KHAU_QUAN_TRI_CUA_BAN'
$env:APP_PUBLIC_BASE_URL = 'http://localhost:8080'
.\mvnw.cmd spring-boot:run
```

Mở **http://localhost:8080**. Ứng dụng yêu cầu mật khẩu quản trị từ cấu hình, không có tài khoản quản trị với mật khẩu mặc định dùng chung. Khi chạy bằng Maven/Java, file `.env` **không tự được nạp**; cần export biến hoặc cấu hình Environment trong IDE. Nếu Maven Wrapper mất quyền chạy sau giải nén trên Linux, chạy `chmod +x mvnw`.

### 3. Đường dẫn sử dụng

| Mục | Đường dẫn |
| --- | --- |
| Trang chủ | `/` |
| Danh sách sản phẩm | `/san-pham` |
| Đăng ký / đăng nhập khách | `/tai-khoan/dang-ky` / `/tai-khoan/dang-nhap` |
| Quên mật khẩu | `/tai-khoan/quen-mat-khau` |
| Hồ sơ / lịch sử đơn | `/tai-khoan` / `/tai-khoan/don-hang` |
| Giỏ / đặt hàng | `/gio-hang` / `/dat-hang` |
| Đăng nhập quản trị | `/dang-nhap` |
| Trang quản trị | `/quan-tri` |
| Trợ lý cửa hàng | `/tro-ly` |

## Nâng cấp dữ liệu cũ

Nếu đang dùng bản `mens-store-project` trước đó, hãy sao lưu database rồi chạy **`sql/upgrade_v2.sql`** trên đúng database đang dùng. Migration thêm cột/bảng cần thiết, không xóa tài khoản, đơn hoặc dòng hàng; có thể chạy lại. Không dùng `docker compose down -v` vì thao tác đó xóa volume dữ liệu.

Ví dụ trên Linux/macOS/CMD:

```bash
mysqldump --single-transaction --no-tablespaces -u mens_store -p mens_store_db > mens_store_backup.sql
mysql -u mens_store -p mens_store_db < sql/upgrade_v2.sql
```

Với Compose, chạy các lệnh sau trong Bash (Linux/macOS hoặc Git Bash):

```bash
docker compose exec -T db sh -c 'mysqldump --single-transaction --no-tablespaces -uroot -p"$MYSQL_ROOT_PASSWORD" mens_store_db > /tmp/mens_store_backup.sql'
docker compose cp db:/tmp/mens_store_backup.sql ./mens_store_backup.sql
docker compose cp sql/upgrade_v2.sql db:/tmp/upgrade_v2.sql
docker compose exec -T db sh -c 'mysql -uroot -p"$MYSQL_ROOT_PASSWORD" mens_store_db < /tmp/upgrade_v2.sql'
docker compose up -d --build web
```

Đơn cũ chưa có liên kết tài khoản vẫn giữ nguyên cho quản trị, không tự suy đoán chủ sở hữu bằng số điện thoại. Giỏ cũ lưu chung trong localStorage bị loại bỏ để tránh lộ giỏ giữa người dùng; từ bản này giỏ mới được lưu riêng trong database. Hồ sơ cũ thiếu email thật cần được cập nhật tại quản trị trước khi dùng khôi phục qua email. Nếu thiếu địa chỉ, có thể cập nhật hồ sơ tại quản trị hoặc điền địa chỉ ở bước đặt hàng.

### Cập nhật nội dung mẫu cho database MENS STORE đã có

Nếu đang chạy bản 2.0 và muốn nhận các mô tả thời trang mới, có thể chạy script nội dung sau khi sao lưu:

```bash
mysql -u mens_store -p mens_store_db < sql/update_mens_store_catalog.sql
```

Nếu database còn ở bản trước 2.0, chạy `upgrade_v2.sql` trước. Script nội dung chỉ cập nhật mô tả của 6 danh mục và 20 sản phẩm mẫu khi nội dung cũ còn nguyên. Sản phẩm/danh mục bạn đã tự sửa sẽ được giữ nguyên; giá, tồn kho, ảnh, tài khoản, giỏ và lịch sử đơn không bị thay đổi. Có thể chạy lại script. Cài mới bằng `mens_store.sql` đã có nội dung mới nên không cần bước này.

## Cấu hình chuyển khoản cho 1069811696

Các biến môi trường cần có:

| Biến | Giá trị |
| --- | --- |
| `PAYMENT_BANK_ACCOUNT` | `1069811696` |
| `PAYMENT_BANK_CODE` | BIN ngân hàng đúng, gồm 6 chữ số |
| `PAYMENT_BANK_NAME` | Tên ngân hàng nhận tiền |
| `PAYMENT_BANK_ACCOUNT_NAME` | Tên chủ tài khoản đúng theo ngân hàng |

**Chưa biết ngân hàng hoặc tên chủ tài khoản thì để trống**, phương thức QR sẽ hiển thị chưa sẵn sàng và khách vẫn có thể chọn COD. Không dùng ngân hàng đoán từ số tài khoản.

Sau khi đủ cấu hình, đơn chuyển khoản có mã QR SVG VietQR theo **tổng tiền và mã đơn đã lưu**. Khách có thể mở lại tại lịch sử đơn. QR chỉ là hướng dẫn chuyển tiền; quản trị phải đối chiếu thực nhận và bấm xác nhận. Đơn đã thanh toán hoặc đã hủy không tiếp tục yêu cầu khách chuyển tiền. QR cần kết nối Internet tới dịch vụ VietQR; số tài khoản, số tiền, mã đơn và tên người nhận được dùng trong URL QR, không gửi địa chỉ/điện thoại khách.

Tài liệu gốc: https://www.vietqr.io/qr-dong . Trước khi dùng bán hàng, chủ cửa hàng cần kiểm tra thông tin người nhận hiển thị trong ứng dụng ngân hàng.

## Cấu hình email quên mật khẩu

Đặt `MAIL_HOST`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_FROM`, `MAIL_SMTP_AUTH`, `MAIL_STARTTLS` theo SMTP của bạn. `APP_PUBLIC_BASE_URL` phải là URL thật khách có thể mở (ví dụ URL HTTPS khi triển khai), không phải địa chỉ nội bộ máy chủ. Mặc định SMTP tắt; giao diện nói rõ khi chưa có kết nối gửi mail.

Người dùng nhập email đã đăng ký; phản hồi không tiết lộ email có tồn tại hay không. Liên kết mặc định hết hạn sau 15 phút, dùng một lần. Không xuất token/mật khẩu ra log, không tạo email nhận hàng giả để đăng ký. Mật khẩu được lưu bằng BCrypt; cần xác nhận đúng email đã đăng ký.

## Cấu hình AI tùy chọn

Đặt `AI_ENABLED=true`, `AI_API_KEY`, `AI_MODEL` và `AI_BASE_URL` cho nhà cung cấp hỗ trợ giao thức Chat Completions. Key chỉ dùng phía server. Không đặt key vào HTML/JavaScript. Không có key/model thì các trang giải thích chưa kết nối, không tạo báo cáo giả.

Mặc định `AI_REPORT_CRON=-` tắt lịch báo cáo. Ví dụ cron Spring `0 0 8 * * *` tạo báo cáo mỗi ngày lúc 08:00 theo `Asia/Ho_Chi_Minh`, khi ứng dụng đang chạy và AI đã cấu hình. Trong `.env` dùng `AI_REPORT_CRON="0 0 8 * * *"`. Báo cáo lưu trong thư mục `ai-reports` bên dưới `SHOP_UPLOAD_DIR`: mặc định `./uploads/ai-reports` khi chạy Java/Maven, hoặc `/data/uploads/ai-reports` trong volume `upload_data` khi chạy Compose. Báo cáo được đọc qua trang quản trị, không được phục vụ như ảnh công khai.

Phân tích dùng số liệu tổng hợp và danh mục sản phẩm; không gửi hồ sơ/địa chỉ/điện thoại khách trong báo cáo. Nội dung chat/bình luận được gửi khi người dùng gọi chức năng AI tương ứng. Đánh giá AI là đề xuất; không tự sửa giá, danh mục hay xác nhận thanh toán. Chỉ gắn spam tự động khi kết quả đúng định dạng và độ tin cậy đạt ngưỡng; vẫn giữ bình luận để quản trị xem lại.

## Build lại bằng Maven

Sau khi cấu hình database và môi trường như trên:

```bash
chmod +x mvnw
./mvnw clean package
java -jar target/mens-store.jar
```

Windows dùng `mvnw.cmd clean package`. Bản gọn không kèm JAR dựng sẵn hoặc bộ test; để kiểm thử đầy đủ, dùng `src/test/` và `.github/workflows/java-ci.yml` từ ZIP gốc 2.1.1. Nếu dùng Docker, Dockerfile tự build JAR từ source khi chạy `docker compose up -d --build`.

## Cấu trúc

- `src/main/java/com/example/mens_store/`: 64 file Java (config, controller, model, repository, service và lớp chạy).
- `src/main/resources/`: application.properties, 28 template, CSS/JS, Bootstrap cục bộ và ảnh.
- `sql/mens_store.sql`: schema và dữ liệu mẫu bản cài mới.
- `sql/upgrade_v2.sql`, `sql/update_mens_store_catalog.sql`: nâng cấp database cũ và tùy chọn cập nhật mô tả mẫu; sao lưu trước khi chạy.
- `pom.xml`, `mvnw`, `mvnw.cmd`, `.mvn/`: build Maven.
- `.devcontainer/`, `compose.yaml`, `Dockerfile`, `.env.example`, `.gitignore`, `.dockerignore`: cấu hình Codespaces và Docker.
