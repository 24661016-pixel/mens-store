package com.example.mens_store.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public class PasswordResetRepository {
    private final JdbcTemplate jdbc;
    public PasswordResetRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public void insert(long accountId, String hash, LocalDateTime expiresAt, LocalDateTime now) {
        jdbc.update("INSERT INTO password_reset_tokens(tai_khoan_id,token_hash,expires_at,created_at) " +
            "VALUES(?,?,?,?)", accountId, hash, Timestamp.valueOf(expiresAt), Timestamp.valueOf(now));
    }

    public Optional<Long> accountId(String hash) {
        return jdbc.query("SELECT tai_khoan_id FROM password_reset_tokens WHERE token_hash=?",
            (rs,n) -> rs.getLong(1), hash).stream().findFirst();
    }

    public boolean isUsable(String hash, LocalDateTime now) {
        Integer count = jdbc.queryForObject(
            "SELECT COUNT(*) FROM password_reset_tokens t JOIN tai_khoan a ON a.tai_khoan_id=t.tai_khoan_id " +
            "WHERE t.token_hash=? AND t.used_at IS NULL AND t.expires_at>? AND a.trang_thai=TRUE",
            Integer.class, hash, Timestamp.valueOf(now));
        return count != null && count == 1;
    }

    public int consume(String hash, long accountId, LocalDateTime now) {
        return jdbc.update("UPDATE password_reset_tokens SET used_at=? WHERE token_hash=? AND tai_khoan_id=? " +
            "AND used_at IS NULL AND expires_at>?", Timestamp.valueOf(now), hash, accountId, Timestamp.valueOf(now));
    }

    public void invalidateAll(long accountId, LocalDateTime now) {
        jdbc.update("UPDATE password_reset_tokens SET used_at=? WHERE tai_khoan_id=? AND used_at IS NULL",
            Timestamp.valueOf(now), accountId);
    }

    public void deleteHash(String hash) {
        jdbc.update("DELETE FROM password_reset_tokens WHERE token_hash=?", hash);
    }

    public void prune(LocalDateTime before) {
        jdbc.update("DELETE FROM password_reset_tokens WHERE expires_at<?", Timestamp.valueOf(before));
    }
}
