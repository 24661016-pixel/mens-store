package com.example.mens_store.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public class CommentRepository {
    public record Comment(long id, long accountId, int productId, String author, String productName, String content, String status, LocalDateTime createdAt) {}
    private final JdbcTemplate jdbc;
    public CommentRepository(JdbcTemplate jdbc) { this.jdbc=jdbc; }
    private final org.springframework.jdbc.core.RowMapper<Comment> mapper = (rs,n) -> new Comment(rs.getLong("binh_luan_id"), rs.getLong("tai_khoan_id"), rs.getInt("san_pham_id"), rs.getString("ho_ten"), rs.getString("ten_san_pham"), rs.getString("noi_dung"), rs.getString("trang_thai"), rs.getObject("created_at", LocalDateTime.class));
    private static final String SELECT = "SELECT b.*,t.ho_ten,p.ten_san_pham FROM binh_luan b JOIN tai_khoan t ON t.tai_khoan_id=b.tai_khoan_id JOIN san_pham p ON p.san_pham_id=b.san_pham_id ";
    public List<Comment> publicForProduct(int id) { return jdbc.query(SELECT+"WHERE b.san_pham_id=? AND b.trang_thai='HIEN_THI' ORDER BY b.created_at DESC LIMIT 100",mapper,id); }
    public List<Comment> all() { return jdbc.query(SELECT+"ORDER BY b.binh_luan_id DESC LIMIT 200",mapper); }
    public Optional<Comment> find(long id) { return jdbc.query(SELECT+"WHERE b.binh_luan_id=?",mapper,id).stream().findFirst(); }
    public int recent(long accountId, LocalDateTime since) { return jdbc.queryForObject("SELECT COUNT(*) FROM binh_luan WHERE tai_khoan_id=? AND created_at>=?",Integer.class,accountId,since); }
    public void create(long accountId,int productId,String content) { jdbc.update("INSERT INTO binh_luan(tai_khoan_id,san_pham_id,noi_dung) VALUES(?,?,?)",accountId,productId,content); }
    public void edit(long id,String content,String status) { if(jdbc.update("UPDATE binh_luan SET noi_dung=?,trang_thai=? WHERE binh_luan_id=?",content,status,id)!=1) throw new IllegalArgumentException("Không tìm thấy bình luận"); }
    public void status(long id,String status) { if(jdbc.update("UPDATE binh_luan SET trang_thai=? WHERE binh_luan_id=?",status,id)!=1) throw new IllegalArgumentException("Không tìm thấy bình luận"); }
}
