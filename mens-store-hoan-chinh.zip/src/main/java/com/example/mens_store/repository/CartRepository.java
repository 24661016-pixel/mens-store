package com.example.mens_store.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.LinkedHashMap;
import java.util.Map;

@Repository
public class CartRepository {
    private final JdbcTemplate jdbc;
    public CartRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }
    public void lockOwner(long accountId) {
        var owners = jdbc.query("SELECT tai_khoan_id FROM tai_khoan WHERE tai_khoan_id=? AND trang_thai=1 FOR UPDATE",
                (rs, row) -> rs.getLong(1), accountId);
        if (owners.isEmpty()) throw new IllegalArgumentException("Tài khoản không còn hoạt động");
    }
    public Map<Integer, Integer> values(long accountId) {
        Map<Integer, Integer> result = new LinkedHashMap<>();
        jdbc.query("SELECT san_pham_id, so_luong FROM gio_hang WHERE tai_khoan_id=? ORDER BY san_pham_id",
                (org.springframework.jdbc.core.RowCallbackHandler) rs -> result.put(rs.getInt(1), rs.getInt(2)), accountId);
        return result;
    }
    /** Current read after lockOwner: never reuse a snapshot from before waiting for that lock. */
    public Map<Integer, Integer> valuesForUpdate(long accountId) {
        Map<Integer, Integer> result = new LinkedHashMap<>();
        jdbc.query("SELECT san_pham_id, so_luong FROM gio_hang WHERE tai_khoan_id=? ORDER BY san_pham_id FOR UPDATE",
                (org.springframework.jdbc.core.RowCallbackHandler) rs -> result.put(rs.getInt(1), rs.getInt(2)), accountId);
        return result;
    }
    // Called while the account row is locked, avoiding lost updates from simultaneous requests.
    public void set(long accountId, int productId, int quantity) {
        if (quantity == 0) {
            jdbc.update("DELETE FROM gio_hang WHERE tai_khoan_id=? AND san_pham_id=?", accountId, productId);
            return;
        }
        int updated = jdbc.update("UPDATE gio_hang SET so_luong=?, updated_at=CURRENT_TIMESTAMP WHERE tai_khoan_id=? AND san_pham_id=?",
                quantity, accountId, productId);
        if (updated == 0) jdbc.update("INSERT INTO gio_hang(tai_khoan_id,san_pham_id,so_luong) VALUES(?,?,?)", accountId, productId, quantity);
    }
    public void clear(long accountId) { jdbc.update("DELETE FROM gio_hang WHERE tai_khoan_id=?", accountId); }
}
