package com.example.mens_store.repository;

import com.example.mens_store.model.AdminPromotionForm;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;
@Repository
public class AdminPromotionRepository {
    private final JdbcTemplate jdbc;
    public AdminPromotionRepository(JdbcTemplate jdbc){this.jdbc=jdbc;}
    public record Row(long id,String code,String name,int percentage,LocalDate starts,LocalDate ends,boolean active){
        public String status(){LocalDate now=LocalDate.now(ZoneId.of("Asia/Ho_Chi_Minh"));return !active?"Tạm ngừng":now.isBefore(starts)?"Sắp diễn ra":now.isAfter(ends)?"Đã kết thúc":"Trong thời gian kế hoạch";}
    }
    private static final org.springframework.jdbc.core.RowMapper<Row> ROW=(rs,n)->new Row(rs.getLong("khuyen_mai_id"),rs.getString("ma_khuyen_mai"),rs.getString("ten_khuyen_mai"),rs.getInt("phan_tram_giam"),rs.getDate("bat_dau").toLocalDate(),rs.getDate("ket_thuc").toLocalDate(),rs.getBoolean("trang_thai"));
    public List<Row> all(){return jdbc.query("SELECT * FROM khuyen_mai ORDER BY bat_dau DESC,khuyen_mai_id DESC",ROW);}
    public Optional<Row> find(long id){return jdbc.query("SELECT * FROM khuyen_mai WHERE khuyen_mai_id=?",ROW,id).stream().findFirst();}
    public void create(AdminPromotionForm f){jdbc.update("INSERT INTO khuyen_mai(ma_khuyen_mai,ten_khuyen_mai,phan_tram_giam,bat_dau,ket_thuc,trang_thai) VALUES(?,?,?,?,?,?)",f.getCode(),f.getName(),f.getPercentage(),f.getStarts(),f.getEnds(),f.isActive());}
    public boolean update(long id,AdminPromotionForm f){return jdbc.update("UPDATE khuyen_mai SET ma_khuyen_mai=?,ten_khuyen_mai=?,phan_tram_giam=?,bat_dau=?,ket_thuc=?,trang_thai=? WHERE khuyen_mai_id=?",f.getCode(),f.getName(),f.getPercentage(),f.getStarts(),f.getEnds(),f.isActive(),id)==1;}
    public boolean delete(long id){return jdbc.update("DELETE FROM khuyen_mai WHERE khuyen_mai_id=?",id)==1;}
}
