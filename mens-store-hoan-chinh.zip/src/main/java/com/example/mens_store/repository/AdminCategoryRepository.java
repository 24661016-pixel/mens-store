package com.example.mens_store.repository;

import com.example.mens_store.model.AdminCategoryForm;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class AdminCategoryRepository {
    private final JdbcTemplate jdbc;
    public AdminCategoryRepository(JdbcTemplate jdbc){this.jdbc=jdbc;}
    public record Row(int id,String code,String name,String description,int sort,boolean active,long products) {}
    private final org.springframework.jdbc.core.RowMapper<Row> mapper=(rs,n)->new Row(rs.getInt("danh_muc_id"),rs.getString("ma_danh_muc"),rs.getString("ten_danh_muc"),rs.getString("mo_ta"),rs.getInt("thu_tu"),rs.getBoolean("trang_thai"),rs.getLong("products"));
    private static final String SELECT="SELECT d.*, (SELECT COUNT(*) FROM san_pham p WHERE p.danh_muc_id=d.danh_muc_id) products FROM danh_muc d";
    public List<Row> all(){return jdbc.query(SELECT+" ORDER BY d.thu_tu,d.danh_muc_id",mapper);}
    public Optional<Row> find(int id){return jdbc.query(SELECT+" WHERE d.danh_muc_id=?",mapper,id).stream().findFirst();}
    public void create(AdminCategoryForm f){jdbc.update("INSERT INTO danh_muc(ma_danh_muc,ten_danh_muc,mo_ta,thu_tu,trang_thai) VALUES(?,?,?,?,?)",f.getCode(),f.getName(),f.getDescription(),f.getSort(),f.isActive());}
    public boolean update(int id,AdminCategoryForm f){return jdbc.update("UPDATE danh_muc SET ma_danh_muc=?,ten_danh_muc=?,mo_ta=?,thu_tu=?,trang_thai=? WHERE danh_muc_id=?",f.getCode(),f.getName(),f.getDescription(),f.getSort(),f.isActive(),id)==1;}
    public boolean setActive(int id,boolean active){return jdbc.update("UPDATE danh_muc SET trang_thai=? WHERE danh_muc_id=?",active,id)==1;}
    public boolean deleteEmpty(int id){return jdbc.update("DELETE FROM danh_muc WHERE danh_muc_id=? AND NOT EXISTS(SELECT 1 FROM san_pham p WHERE p.danh_muc_id=?)",id,id)==1;}
}
