package com.example.mens_store.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.example.mens_store.model.CustomerAccount;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public class CustomerAccountRepository {
    private final JdbcTemplate jdbc;
    private static final String COLUMNS =
        "SELECT tai_khoan_id, ho_ten, email, so_dien_thoai, mat_khau_hash, trang_thai, created_at, " +
        "dia_chi, ngay_sinh, mat_khau_version FROM tai_khoan ";

    public CustomerAccountRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private CustomerAccount map(ResultSet rs) throws SQLException {
        Date birthday = rs.getDate("ngay_sinh");
        return new CustomerAccount(rs.getLong("tai_khoan_id"), rs.getString("ho_ten"),
            rs.getString("email"), rs.getString("so_dien_thoai"), rs.getString("mat_khau_hash"),
            rs.getBoolean("trang_thai"), rs.getObject("created_at", LocalDateTime.class),
            rs.getString("dia_chi"), birthday == null ? null : birthday.toLocalDate(),
            rs.getInt("mat_khau_version"));
    }

    public Optional<CustomerAccount> findByPhone(String phone) {
        return jdbc.query(COLUMNS + "WHERE so_dien_thoai=? LIMIT 1", (rs, row) -> map(rs), phone)
            .stream().findFirst();
    }

    public Optional<CustomerAccount> findByEmail(String email) {
        return jdbc.query(COLUMNS + "WHERE email=? LIMIT 1", (rs, row) -> map(rs), email)
            .stream().findFirst();
    }

    public Optional<CustomerAccount> findById(long id) {
        return jdbc.query(COLUMNS + "WHERE tai_khoan_id=?", (rs, row) -> map(rs), id)
            .stream().findFirst();
    }

    public Optional<CustomerAccount> lockById(long id) {
        return jdbc.query(COLUMNS + "WHERE tai_khoan_id=? FOR UPDATE", (rs, row) -> map(rs), id)
            .stream().findFirst();
    }

    public void insert(String fullName, String email, String phone, String address,
                       LocalDate birthday, String passwordHash) {
        jdbc.update("INSERT INTO tai_khoan(ho_ten,email,so_dien_thoai,dia_chi,ngay_sinh,mat_khau_hash) " +
            "VALUES(?,?,?,?,?,?)", fullName, email, phone, address,
            birthday == null ? null : Date.valueOf(birthday), passwordHash);
    }

    public boolean updatePassword(long accountId, String hash) {
        return jdbc.update("UPDATE tai_khoan SET mat_khau_hash=?,mat_khau_version=mat_khau_version+1 " +
            "WHERE tai_khoan_id=? AND trang_thai=TRUE", hash, accountId) == 1;
    }

    public record AuthState(boolean active, int passwordVersion, String phone) {}
    public Optional<AuthState> authState(long id) {
        return jdbc.query("SELECT trang_thai,mat_khau_version,so_dien_thoai FROM tai_khoan WHERE tai_khoan_id=?",
            (rs, n) -> new AuthState(rs.getBoolean(1),rs.getInt(2),rs.getString(3)), id)
            .stream().findFirst();
    }
}
