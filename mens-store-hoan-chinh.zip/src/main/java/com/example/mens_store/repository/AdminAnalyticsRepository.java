package com.example.mens_store.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/** Read-only reporting; revenue means completed orders, grouped by order date. */
@Repository
public class AdminAnalyticsRepository {
    private final JdbcTemplate jdbc;
    public AdminAnalyticsRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public record Overview(long totalOrders, long pending, long confirmed, long shipping,
                           long completed, long cancelled, long revenue) {}
    public record StockTotals(long active, long selling, long low, long out) {}
    public record CustomerStats(long total, long newInPeriod, long birthdaysInMonth) {}
    public record DailyRevenue(LocalDate date, long amount, long orders) {}
    public record Birthday(long id, String name, String phone, LocalDate birthDate) {}
    public record TopBuyer(long id, String name, long orders, long quantity, long spent) {}
    public record BestSeller(int id, String name, String category, long quantity, long revenue) {}
    public record OrderRow(long id, String code, String name, String phone, long total,
                           String status, LocalDateTime createdAt) {}

    private String where(LocalDate from, LocalDate to, Integer category, List<Object> args) {
        args.add(from.atStartOfDay()); args.add(to.plusDays(1).atStartOfDay());
        String sql = " WHERE d.thoi_gian_dat>=? AND d.thoi_gian_dat<? ";
        if (category != null) {
            sql += " AND EXISTS (SELECT 1 FROM chi_tiet_don_hang x JOIN san_pham p ON p.san_pham_id=x.san_pham_id WHERE x.don_hang_id=d.don_hang_id AND p.danh_muc_id=?) ";
            args.add(category);
        }
        return sql;
    }
    private String amount(Integer category, List<Object> args) {
        if (category == null) return "d.tong_tien";
        args.add(category);
        return "COALESCE((SELECT SUM(x.thanh_tien) FROM chi_tiet_don_hang x JOIN san_pham p ON p.san_pham_id=x.san_pham_id WHERE x.don_hang_id=d.don_hang_id AND p.danh_muc_id=?),0)";
    }
    public Overview overview(LocalDate from, LocalDate to, Integer category) {
        List<Object> args = new ArrayList<>();
        String amount = amount(category, args);
        String sql = "SELECT COUNT(*) total, "
            + "COALESCE(SUM(CASE WHEN d.trang_thai='CHO_XAC_NHAN' THEN 1 ELSE 0 END),0) pending, "
            + "COALESCE(SUM(CASE WHEN d.trang_thai='DA_XAC_NHAN' THEN 1 ELSE 0 END),0) confirmed, "
            + "COALESCE(SUM(CASE WHEN d.trang_thai='DANG_GIAO' THEN 1 ELSE 0 END),0) shipping, "
            + "COALESCE(SUM(CASE WHEN d.trang_thai='HOAN_TAT' THEN 1 ELSE 0 END),0) completed, "
            + "COALESCE(SUM(CASE WHEN d.trang_thai='DA_HUY' THEN 1 ELSE 0 END),0) cancelled, "
            + "COALESCE(SUM(CASE WHEN d.trang_thai='HOAN_TAT' THEN " + amount + " ELSE 0 END),0) revenue FROM don_hang d"
            + where(from,to,category,args);
        return jdbc.queryForObject(sql, (rs,n) -> new Overview(rs.getLong("total"),rs.getLong("pending"),
            rs.getLong("confirmed"),rs.getLong("shipping"),rs.getLong("completed"),rs.getLong("cancelled"),rs.getLong("revenue")), args.toArray());
    }
    public List<DailyRevenue> daily(LocalDate from, LocalDate to, Integer category) {
        List<Object> args = new ArrayList<>(); String amount = amount(category,args);
        String sql = "SELECT CAST(d.thoi_gian_dat AS DATE) report_date, SUM("+amount+") revenue, COUNT(*) orders FROM don_hang d"
            + where(from,to,category,args) + " AND d.trang_thai='HOAN_TAT' GROUP BY CAST(d.thoi_gian_dat AS DATE) ORDER BY report_date";
        return jdbc.query(sql,(rs,n)->new DailyRevenue(rs.getDate("report_date").toLocalDate(),rs.getLong("revenue"),rs.getLong("orders")),args.toArray());
    }
    public StockTotals stock(Integer category) {
        String sql = "SELECT COUNT(*) active, "
            + "COALESCE(SUM(CASE WHEN p.so_luong_ton>0 THEN 1 ELSE 0 END),0) selling, "
            + "COALESCE(SUM(CASE WHEN p.so_luong_ton BETWEEN 1 AND 5 THEN 1 ELSE 0 END),0) low_stock, "
            + "COALESCE(SUM(CASE WHEN p.so_luong_ton=0 THEN 1 ELSE 0 END),0) out_stock "
            + "FROM san_pham p JOIN danh_muc c ON c.danh_muc_id=p.danh_muc_id WHERE p.trang_thai=1 AND c.trang_thai=1";
        List<Object> args = new ArrayList<>();
        if (category != null) { sql += " AND p.danh_muc_id=?"; args.add(category); }
        return jdbc.queryForObject(sql,(rs,n)->new StockTotals(rs.getLong("active"),rs.getLong("selling"),rs.getLong("low_stock"),rs.getLong("out_stock")),args.toArray());
    }
    public CustomerStats customers(LocalDate from, LocalDate to, int birthdayMonth) {
        return jdbc.queryForObject("SELECT COUNT(*) total, "
            + "COALESCE(SUM(CASE WHEN created_at>=? AND created_at<? THEN 1 ELSE 0 END),0) fresh, "
            + "COALESCE(SUM(CASE WHEN MONTH(ngay_sinh)=? THEN 1 ELSE 0 END),0) birthdays FROM tai_khoan",
            (rs,n)->new CustomerStats(rs.getLong("total"),rs.getLong("fresh"),rs.getLong("birthdays")),
            from.atStartOfDay(),to.plusDays(1).atStartOfDay(),birthdayMonth);
    }
    public List<Birthday> birthdays(int month) {
        return jdbc.query("SELECT tai_khoan_id,ho_ten,so_dien_thoai,ngay_sinh FROM tai_khoan WHERE MONTH(ngay_sinh)=? ORDER BY DAY(ngay_sinh),ho_ten LIMIT 200",
            (rs,n)->new Birthday(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getDate(4).toLocalDate()),month);
    }
    public List<TopBuyer> topBuyers(LocalDate from, LocalDate to, Integer category) {
        List<Object> args = new ArrayList<>();
        args.add(from.atStartOfDay()); args.add(to.plusDays(1).atStartOfDay());
        String sql = "SELECT a.tai_khoan_id,a.ho_ten,COUNT(DISTINCT d.don_hang_id) orders,SUM(l.so_luong) quantity,SUM(l.thanh_tien) spent "
            + "FROM don_hang d JOIN tai_khoan a ON a.tai_khoan_id=d.tai_khoan_id "
            + "JOIN chi_tiet_don_hang l ON l.don_hang_id=d.don_hang_id JOIN san_pham p ON p.san_pham_id=l.san_pham_id "
            + "WHERE d.trang_thai='HOAN_TAT' AND d.thoi_gian_dat>=? AND d.thoi_gian_dat<?";
        if (category != null) { sql += " AND p.danh_muc_id=?"; args.add(category); }
        sql += " GROUP BY a.tai_khoan_id,a.ho_ten ORDER BY spent DESC,quantity DESC,a.tai_khoan_id LIMIT 10";
        return jdbc.query(sql,(rs,n)->new TopBuyer(rs.getLong(1),rs.getString(2),rs.getLong(3),rs.getLong(4),rs.getLong(5)),args.toArray());
    }
    public List<BestSeller> bestsellers(LocalDate from, LocalDate to, Integer category) {
        List<Object> args = new ArrayList<>();
        args.add(from.atStartOfDay()); args.add(to.plusDays(1).atStartOfDay());
        String sql = "SELECT p.san_pham_id,p.ten_san_pham,c.ten_danh_muc,SUM(l.so_luong) quantity,SUM(l.thanh_tien) revenue "
            + "FROM chi_tiet_don_hang l JOIN don_hang d ON d.don_hang_id=l.don_hang_id JOIN san_pham p ON p.san_pham_id=l.san_pham_id "
            + "JOIN danh_muc c ON c.danh_muc_id=p.danh_muc_id WHERE d.trang_thai='HOAN_TAT' AND d.thoi_gian_dat>=? AND d.thoi_gian_dat<?";
        if (category != null) { sql += " AND p.danh_muc_id=?"; args.add(category); }
        sql += " GROUP BY p.san_pham_id,p.ten_san_pham,c.ten_danh_muc ORDER BY quantity DESC,revenue DESC,p.san_pham_id LIMIT 10";
        return jdbc.query(sql,(rs,n)->new BestSeller(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getLong(4),rs.getLong(5)),args.toArray());
    }
    public List<OrderRow> orders(LocalDate from, LocalDate to, Integer category) {
        List<Object> args = new ArrayList<>();
        String sql = "SELECT d.don_hang_id,d.ma_don_hang,d.ten_nguoi_nhan,d.sdt_nguoi_nhan,d.tong_tien,d.trang_thai,d.thoi_gian_dat FROM don_hang d"
            + where(from,to,category,args) + " ORDER BY d.thoi_gian_dat DESC,d.don_hang_id DESC LIMIT 200";
        return jdbc.query(sql,(rs,n)->new OrderRow(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getLong(5),rs.getString(6),rs.getObject(7, LocalDateTime.class)),args.toArray());
    }
}
