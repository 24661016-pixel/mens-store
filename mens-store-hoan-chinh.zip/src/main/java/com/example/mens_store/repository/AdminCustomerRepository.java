package com.example.mens_store.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.example.mens_store.model.AdminCustomerRow;
import com.example.mens_store.model.AdminCustomerForm;
import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

@Repository
public class AdminCustomerRepository {
    private final JdbcTemplate jdbc;
    public AdminCustomerRepository(JdbcTemplate jdbc) { this.jdbc=jdbc; }
    private static final String SELECT="SELECT tai_khoan_id,ho_ten,email,so_dien_thoai,dia_chi,ngay_sinh,trang_thai,created_at FROM tai_khoan ";
    private static final RowMapper<AdminCustomerRow> ROW=(rs,n)->new AdminCustomerRow(rs.getLong("tai_khoan_id"),rs.getString("ho_ten"),rs.getString("email"),rs.getString("so_dien_thoai"),rs.getString("dia_chi"),rs.getDate("ngay_sinh")==null?null:rs.getDate("ngay_sinh").toLocalDate(),rs.getBoolean("trang_thai"),rs.getObject("created_at", LocalDateTime.class));
    public List<AdminCustomerRow> search(String query) {
        if(query==null || query.isBlank()) return jdbc.query(SELECT+"ORDER BY tai_khoan_id DESC LIMIT 200",ROW);
        String keyword="%"+query.trim().replace("\\","\\\\").replace("%","\\%").replace("_","\\_")+"%";
        return jdbc.query(SELECT+"WHERE ho_ten LIKE ? OR email LIKE ? OR so_dien_thoai LIKE ? ORDER BY tai_khoan_id DESC LIMIT 200",ROW,keyword,keyword,keyword);
    }
    public Optional<AdminCustomerRow> find(long id){return jdbc.query(SELECT+"WHERE tai_khoan_id=?",ROW,id).stream().findFirst();}
    public void create(AdminCustomerForm f,String hash){jdbc.update("INSERT INTO tai_khoan(ho_ten,email,so_dien_thoai,dia_chi,ngay_sinh,mat_khau_hash,trang_thai) VALUES(?,?,?,?,?,?,?)",f.getFullName(),f.getEmail(),f.getPhone(),f.getAddress(),f.getBirthDate(),hash,f.isActive());}
    @Transactional
    public boolean update(long id,AdminCustomerForm f){
        var existing=findForUpdate(id);
        if(existing.isEmpty())return false;
        var before=existing.get();
        boolean changedIdentity=!before.email().equals(f.getEmail()) || !before.phone().equals(f.getPhone()) || before.active()!=f.isActive();
        int updated=jdbc.update("UPDATE tai_khoan SET ho_ten=?,email=?,so_dien_thoai=?,dia_chi=?,ngay_sinh=?,trang_thai=?,mat_khau_version=mat_khau_version+? WHERE tai_khoan_id=?",f.getFullName(),f.getEmail(),f.getPhone(),f.getAddress(),f.getBirthDate(),f.isActive(),changedIdentity?1:0,id);
        if(changedIdentity)revokeResetLinks(id);
        return updated==1;
    }
    public int countAll(){Integer n=jdbc.queryForObject("SELECT COUNT(*) FROM tai_khoan",Integer.class);return n==null?0:n;}
    public int countActive(){Integer n=jdbc.queryForObject("SELECT COUNT(*) FROM tai_khoan WHERE trang_thai=1",Integer.class);return n==null?0:n;}
    /** Account deactivation preserves historical orders and the saved cart. */
    @Transactional
    public boolean setActive(long id,boolean active){
        var existing=findForUpdate(id);
        if(existing.isEmpty())return false;
        if(existing.get().active()==active)return true;
        int updated=jdbc.update("UPDATE tai_khoan SET trang_thai=?,mat_khau_version=mat_khau_version+1 WHERE tai_khoan_id=?",active,id);
        revokeResetLinks(id);
        return updated==1;
    }
    private Optional<AdminCustomerRow> findForUpdate(long id){return jdbc.query(SELECT+"WHERE tai_khoan_id=? FOR UPDATE",ROW,id).stream().findFirst();}
    private void revokeResetLinks(long id){jdbc.update("UPDATE password_reset_tokens SET used_at=COALESCE(used_at,?) WHERE tai_khoan_id=?",LocalDateTime.now(ZoneOffset.UTC),id);}
}
