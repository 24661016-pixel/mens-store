package com.example.mens_store.service;

import org.springframework.stereotype.Component;
import java.time.Clock;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/** Bounded in-memory limits for one application instance; never stores raw email addresses. */
@Component
public class PasswordResetRateLimiter {
    private final Clock clock;
    private final Map<String, Window> windows = new HashMap<>();
    private static final long WINDOW_MS = Duration.ofMinutes(15).toMillis();
    private static final int MAX_KEYS = 5000;
    private record Window(long startsAt, int requests) {}
    public PasswordResetRateLimiter() { this(Clock.systemUTC()); }
    PasswordResetRateLimiter(Clock clock) { this.clock = clock; }

    public synchronized boolean allow(String clientIp, String emailHash) {
        long now = clock.millis();
        windows.entrySet().removeIf(entry -> now - entry.getValue().startsAt() >= WINDOW_MS);
        String ipKey = "ip:" + clientIp;
        String emailKey = "email:" + emailHash;
        if (windows.size() >= MAX_KEYS && (!windows.containsKey(ipKey) || !windows.containsKey(emailKey)))
            return false;
        boolean ipAllowed = increment(ipKey, 8, now);
        boolean emailAllowed = increment(emailKey, 3, now);
        return ipAllowed && emailAllowed;
    }

    private boolean increment(String key, int limit, long now) {
        Window old = windows.get(key);
        int count = old == null ? 1 : old.requests() + 1;
        windows.put(key, new Window(old == null ? now : old.startsAt(), Math.min(count, limit + 1)));
        return count <= limit;
    }
}
