package com.example.mens_store.service;

import jakarta.validation.Validator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.example.mens_store.model.AccountValidationException;
import com.example.mens_store.model.CustomerAccount;
import com.example.mens_store.model.RegistrationForm;
import com.example.mens_store.repository.CustomerAccountRepository;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;

@Service
public class CustomerAccountService {
    private final CustomerAccountRepository accounts;
    private final PasswordEncoder encoder;
    private final Validator validator;
    private final String adminUsername;

    public CustomerAccountService(CustomerAccountRepository accounts, PasswordEncoder encoder,
                                  Validator validator,
                                  @Value("${shop.admin.username:admin}") String adminUsername) {
        this.accounts = accounts;
        this.encoder = encoder;
        this.validator = validator;
        this.adminUsername = adminUsername;
    }

    public static String normalizeEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
    }

    public Optional<CustomerAccount> findByPhone(String phone) {
        return accounts.findByPhone(phone == null ? "" : phone.trim());
    }

    public Optional<CustomerAccount> findByEmail(String email) {
        return accounts.findByEmail(normalizeEmail(email));
    }

    public void register(RegistrationForm form) {
        if (form == null) throw new AccountValidationException("fullName", "Thông tin đăng ký không hợp lệ");
        validator.validate(form).stream().findFirst().ifPresent(error -> {
            throw new AccountValidationException(error.getPropertyPath().toString(), error.getMessage());
        });
        if (!Objects.equals(form.getPassword(), form.getConfirmPassword()))
            throw new AccountValidationException("confirmPassword", "Mật khẩu xác nhận không khớp");

        String phone = form.getPhone();
        String email = normalizeEmail(form.getEmail());
        if (adminUsername.equals(phone))
            throw new AccountValidationException("phone", "Số điện thoại này không thể sử dụng");
        if (email.endsWith("@mensstore.local"))
            throw new AccountValidationException("email", "Vui lòng dùng email thật để có thể khôi phục mật khẩu");
        if (accounts.findByPhone(phone).isPresent())
            throw new AccountValidationException("phone", "Số điện thoại đã được đăng ký");
        if (accounts.findByEmail(email).isPresent())
            throw new AccountValidationException("email", "Email đã được đăng ký");
        try {
            accounts.insert(form.getFullName(), email, phone, form.getAddress(), form.getBirthday(),
                encoder.encode(form.getPassword()));
        } catch (DuplicateKeyException ex) {
            if (accounts.findByPhone(phone).isPresent())
                throw new AccountValidationException("phone", "Số điện thoại đã được đăng ký");
            throw new AccountValidationException("email", "Email đã được đăng ký");
        }
    }
}
