package com.example.mens_store.service;

import com.example.mens_store.repository.AdminAnalyticsRepository;
import com.example.mens_store.repository.AdminAnalyticsRepository.*;
import org.springframework.stereotype.Service;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

@Service
public class AdminAnalyticsService {
    private final AdminAnalyticsRepository repository;
    public static final ZoneId ZONE = ZoneId.of("Asia/Ho_Chi_Minh");
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public AdminAnalyticsService(AdminAnalyticsRepository repository) { this.repository=repository; }
    public record Filter(LocalDate from, LocalDate to, LocalDate anchor, String range, String group, Integer category) {}
    public record PeriodRevenue(String label, long revenue, long orders) {}
    public record Report(Filter filter, Overview overview, StockTotals stock, CustomerStats customers,
        List<PeriodRevenue> periods, List<Birthday> birthdays, List<TopBuyer> buyers,
        List<BestSeller> bestsellers, List<OrderRow> orders, String chartPoints, long chartMaximum) {}

    public static Filter filter(String range, String anchor, String from, String to, String group, Integer category) {
        String r=range==null?"month":range;
        if (!Set.of("day","week","month","year","custom").contains(r)) throw new IllegalArgumentException("Kỳ thống kê không hợp lệ.");
        String g=group==null?"day":group;
        if (!Set.of("day","week","month","year").contains(g)) throw new IllegalArgumentException("Cách nhóm biểu đồ không hợp lệ.");
        LocalDate a=parse(anchor, LocalDate.now(ZONE));
        LocalDate start, end;
        switch(r) {
            case "day" -> { start=a; end=a; }
            case "week" -> { start=a.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)); end=start.plusDays(6); }
            case "year" -> { start=a.withDayOfYear(1); end=start.plusYears(1).minusDays(1); }
            case "custom" -> { start=parse(from,a.withDayOfMonth(1)); end=parse(to,a); }
            default -> { start=a.withDayOfMonth(1); end=start.plusMonths(1).minusDays(1); }
        }
        if (end.isBefore(start)) throw new IllegalArgumentException("Ngày kết thúc phải từ ngày bắt đầu trở đi.");
        if (start.isBefore(LocalDate.of(2000,1,1)) || end.isAfter(LocalDate.of(2100,12,31)) || ChronoUnit.DAYS.between(start,end)>3660)
            throw new IllegalArgumentException("Chọn ngày từ năm 2000 đến 2100, tối đa 10 năm cho một báo cáo.");
        if (category!=null && category<1) throw new IllegalArgumentException("Danh mục không hợp lệ.");
        return new Filter(start,end,a,r,g,category);
    }
    private static LocalDate parse(String value, LocalDate fallback) {
        if (value==null || value.isBlank()) return fallback;
        try { return LocalDate.parse(value); } catch (RuntimeException ex) { throw new IllegalArgumentException("Ngày phải theo định dạng yyyy-MM-dd."); }
    }
    public Report report(Filter f) {
        List<PeriodRevenue> periods=group(repository.daily(f.from(),f.to(),f.category()),f);
        long max=periods.stream().mapToLong(PeriodRevenue::revenue).max().orElse(0);
        StringJoiner points=new StringJoiner(" ");
        for (int i=0;i<periods.size();i++) {
            double x=periods.size()==1?500:40+920.0*i/(periods.size()-1);
            double y=max==0?220:220-190.0*periods.get(i).revenue()/max;
            points.add(String.format(Locale.ROOT,"%.2f,%.2f",x,y));
        }
        return new Report(f,repository.overview(f.from(),f.to(),f.category()),repository.stock(f.category()),
            repository.customers(f.from(),f.to(),f.anchor().getMonthValue()),periods,
            repository.birthdays(f.anchor().getMonthValue()),repository.topBuyers(f.from(),f.to(),f.category()),
            repository.bestsellers(f.from(),f.to(),f.category()),repository.orders(f.from(),f.to(),f.category()),points.toString(),max);
    }
    static LocalDate bucket(LocalDate date,String group) {
        return switch(group) {
            case "week" -> date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
            case "month" -> date.withDayOfMonth(1);
            case "year" -> date.withDayOfYear(1);
            default -> date;
        };
    }
    public static List<PeriodRevenue> group(List<DailyRevenue> daily, Filter f) {
        Map<LocalDate,long[]> values=new LinkedHashMap<>();
        for(LocalDate day=f.from();!day.isAfter(f.to());day=day.plusDays(1)) values.computeIfAbsent(bucket(day,f.group()),k->new long[2]);
        for(DailyRevenue row:daily) {
            if(row.date().isBefore(f.from()) || row.date().isAfter(f.to())) continue;
            long[] v=values.get(bucket(row.date(),f.group())); v[0]=Math.addExact(v[0],row.amount());v[1]=Math.addExact(v[1],row.orders());
        }
        List<PeriodRevenue> result=new ArrayList<>();
        values.forEach((day,v)-> {
            String label=switch(f.group()) {
                case "week" -> "Tuần từ "+day.format(DATE);
                case "month" -> day.format(DateTimeFormatter.ofPattern("MM/yyyy"));
                case "year" -> String.valueOf(day.getYear());
                default -> day.format(DATE);
            };
            result.add(new PeriodRevenue(label,v[0],v[1]));
        });
        return result;
    }
    public String csv(Report report) {
        StringBuilder out=new StringBuilder("\ufeff");
        row(out,"MENS STORE - Báo cáo doanh thu");
        row(out,"Từ ngày",report.filter().from().toString(),"Đến ngày",report.filter().to().toString());
        row(out,"Danh mục",report.filter().category()==null?"Tất cả":String.valueOf(report.filter().category()));
        row(out,"Doanh thu chỉ tính đơn hoàn tất; ngày ghi nhận là ngày đặt hàng.");
        row(out,"Tổng đơn",String.valueOf(report.overview().totalOrders()),"Doanh thu",String.valueOf(report.overview().revenue()));
        row(out,"Kỳ","Doanh thu (VND)","Đơn hoàn tất");
        report.periods().forEach(p->row(out,p.label(),String.valueOf(p.revenue()),String.valueOf(p.orders())));
        row(out,"");row(out,"Sản phẩm bán chạy","Số lượng","Doanh thu (VND)");
        report.bestsellers().forEach(p->row(out,p.name(),String.valueOf(p.quantity()),String.valueOf(p.revenue())));
        return out.toString();
    }
    static void row(StringBuilder out,String... values) {
        StringJoiner cells=new StringJoiner(",");
        for(String value:values) cells.add(csvCell(value));
        out.append(cells).append("\r\n");
    }
    public static String csvCell(String value) {
        String text=value==null?"":value;
        String stripped=text.stripLeading();
        if(!stripped.isEmpty() && "=+-@".indexOf(stripped.charAt(0))>=0) text="'"+text;
        return "\""+text.replace("\"","\"\"")+"\"";
    }
}
