package com.example.mens_store.service;

import com.example.mens_store.model.AccountValidationException;
import com.example.mens_store.model.ResetPasswordForm;
import com.example.mens_store.repository.CustomerAccountRepository;
import com.example.mens_store.repository.PasswordResetRepository;
import jakarta.validation.Validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HexFormat;
import java.util.Objects;

@Service
public class PasswordResetService {
    private static final Logger LOG = LoggerFactory.getLogger(PasswordResetService.class);
    private final CustomerAccountRepository accounts;
    private final PasswordResetRepository resets;
    private final PasswordResetMailer mailer;
    private final PasswordEncoder encoder;
    private final Validator validator;
    private final PasswordResetRateLimiter limiter;
    private final TransactionTemplate tx;
    private final String publicBaseUrl;
    private final int ttlMinutes;
    private final SecureRandom random = new SecureRandom();
    private final Clock clock = Clock.systemUTC();
    private record Delivery(String email, String rawToken, String tokenHash) {}

    public PasswordResetService(CustomerAccountRepository accounts, PasswordResetRepository resets,
                                PasswordResetMailer mailer, PasswordEncoder encoder, Validator validator,
                                PasswordResetRateLimiter limiter, PlatformTransactionManager transactions,
                                @Value("${shop.public-base-url:http://localhost:8080}") String publicBaseUrl,
                                @Value("${shop.password-reset.ttl-minutes:15}") int ttlMinutes) {
        this.accounts = accounts;
        this.resets = resets;
        this.mailer = mailer;
        this.encoder = encoder;
        this.validator = validator;
        this.limiter = limiter;
        this.tx = new TransactionTemplate(transactions);
        URI base = URI.create(publicBaseUrl);
        if ((!Objects.equals(base.getScheme(),"https") && !Objects.equals(base.getScheme(),"http"))
                || base.getHost() == null || base.getUserInfo() != null
                || base.getQuery() != null || base.getFragment() != null)
            throw new IllegalArgumentException("shop.public-base-url không hợp lệ");
        this.publicBaseUrl = publicBaseUrl.replaceAll("/+$", "");
        this.ttlMinutes = Math.clamp(ttlMinutes, 5, 60);
    }

    public boolean isMailConfigured() { return mailer.isConfigured(); }

    /** Always gives the caller the same outcome for missing, disabled and registered accounts. */
    public void request(String email, String clientIp) {
        String normalized = CustomerAccountService.normalizeEmail(email);
        if (!mailer.isConfigured() || !limiter.allow(clientIp, hash(normalized))) return;
        var account = accounts.findByEmail(normalized).filter(a -> a.active()
            && !a.email().endsWith("@mensstore.local"));
        if (account.isEmpty()) return;
        Delivery delivery = tx.execute(status -> {
            var current = accounts.lockById(account.get().id()).filter(a -> a.active()
                && normalized.equals(a.email()));
            if (current.isEmpty()) return null;
            LocalDateTime now = LocalDateTime.now(clock);
            byte[] bytes = new byte[32];
            random.nextBytes(bytes);
            String raw = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
            String digest = hash(raw);
            resets.invalidateAll(current.get().id(), now);
            resets.prune(now.minusDays(2));
            resets.insert(current.get().id(), digest, now.plusMinutes(ttlMinutes), now);
            return new Delivery(current.get().email(), raw, digest);
        });
        if (delivery == null) return;
        try {
            // Base URL is configured, never taken from Host or forwarded request headers.
            mailer.send(delivery.email(), publicBaseUrl + "/tai-khoan/dat-lai-mat-khau?token=" +
                delivery.rawToken(), ttlMinutes);
        } catch (MailException | IllegalStateException ex) {
            resets.deleteHash(delivery.tokenHash());
            LOG.warn("Không gửi được email khôi phục mật khẩu MENS STORE. Kiểm tra cấu hình SMTP.");
        }
    }

    public boolean isValid(String rawToken) {
        return rawToken != null && rawToken.matches("^[A-Za-z0-9_-]{43}$")
            && resets.isUsable(hash(rawToken), LocalDateTime.now(clock));
    }

    public void reset(ResetPasswordForm form) {
        validator.validate(form).stream().findFirst().ifPresent(error -> {
            throw new AccountValidationException(error.getPropertyPath().toString(), error.getMessage());
        });
        if (!Objects.equals(form.getPassword(), form.getConfirmPassword()))
            throw new AccountValidationException("confirmPassword", "Mật khẩu xác nhận không khớp");
        String digest = hash(form.getToken());
        Long id = resets.accountId(digest).orElseThrow(PasswordResetService::invalidLink);
        tx.executeWithoutResult(status -> {
            // Serialize all resets for one account, then atomically consume a still-valid token.
            var account = accounts.lockById(id).filter(a -> a.active())
                .orElseThrow(PasswordResetService::invalidLink);
            LocalDateTime now = LocalDateTime.now(clock);
            if (resets.consume(digest, account.id(), now) != 1) throw invalidLink();
            if (!accounts.updatePassword(account.id(), encoder.encode(form.getPassword()))) throw invalidLink();
            resets.invalidateAll(account.id(), now);
        });
    }

    private static AccountValidationException invalidLink() {
        return new AccountValidationException("token", "Liên kết đã hết hạn, đã được sử dụng hoặc không hợp lệ");
    }

    static String hash(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                .digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException ex) { throw new IllegalStateException("SHA-256 unavailable", ex); }
    }
}
