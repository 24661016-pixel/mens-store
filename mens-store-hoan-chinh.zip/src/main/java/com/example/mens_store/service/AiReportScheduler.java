package com.example.mens_store.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class AiReportScheduler {
    private static final Logger LOG = LoggerFactory.getLogger(AiReportScheduler.class);
    private final AiAnalysisService analysis;
    public AiReportScheduler(AiAnalysisService analysis) { this.analysis = analysis; }

    // Disabled by default ('-'). An owner may configure a six-field Spring cron expression.
    @Scheduled(cron="${ai.report-cron:-}", zone="Asia/Ho_Chi_Minh")
    public void generate() {
        if (!analysis.isConfigured()) return;
        try { analysis.analyze("report"); }
        catch (RuntimeException ex) { LOG.warn("MENS STORE: không tạo được báo cáo AI định kỳ; kiểm tra cấu hình dịch vụ."); }
    }
}
