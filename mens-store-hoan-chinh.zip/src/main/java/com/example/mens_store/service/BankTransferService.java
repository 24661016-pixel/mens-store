package com.example.mens_store.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

/** Creates a transfer instruction only; receiving payment is reconciled separately. */
@Service
public class BankTransferService {
    private final String bankCode;
    private final String bankName;
    private final String bankAccount;
    private final String bankAccountName;

    public BankTransferService(
            @Value("${payment.bank-code:${PAYMENT_BANK_CODE:}}") String bankCode,
            @Value("${payment.bank-name:${PAYMENT_BANK_NAME:}}") String bankName,
            @Value("${payment.bank-account:${PAYMENT_BANK_ACCOUNT:1069811696}}") String bankAccount,
            @Value("${payment.bank-account-name:${PAYMENT_BANK_ACCOUNT_NAME:}}") String bankAccountName) {
        this.bankCode = clean(bankCode); this.bankName = clean(bankName);
        this.bankAccount = clean(bankAccount); this.bankAccountName = clean(bankAccountName);
    }

    private static String clean(String value) { return value == null ? "" : value.trim(); }

    public boolean isConfigured() {
        return bankCode.matches("[0-9]{6}") && !bankName.isBlank() && bankName.length() <= 100
            && bankAccount.matches("[0-9]{6,19}")
            && !bankAccountName.isBlank() && bankAccountName.length() <= 100;
    }

    public String createQrUrl(long amount, String orderCode) {
        if (!isConfigured()) throw new IllegalStateException("Cửa hàng chưa xác nhận đầy đủ ngân hàng nhận tiền.");
        if (amount <= 0 || amount > 9_999_999_999_999L || orderCode == null
                || !orderCode.matches("[A-Za-z0-9 -]{1,50}")) {
            throw new IllegalArgumentException("Số tiền hoặc mã đơn hàng không hợp lệ.");
        }
        // Official Quick Link: https://www.vietqr.io/qr-dong (checked 2026-11-27).
        return UriComponentsBuilder.fromUriString("https://img.vietqr.io/image/"
                + bankCode + "-" + bankAccount + "-compact2.svg")
            .queryParam("amount", amount).queryParam("addInfo", orderCode)
            .queryParam("accountName", bankAccountName).build().encode().toUriString();
    }

    public String getBankCode() { return bankCode; }
    public String getBankName() { return bankName; }
    public String getBankAccount() { return bankAccount; }
    public String getBankAccountName() { return bankAccountName; }
}
