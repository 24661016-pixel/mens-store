package com.example.mens_store.service;

import jakarta.servlet.http.HttpSession;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Isolation;
import com.example.mens_store.model.CartItem;
import com.example.mens_store.repository.CartRepository;
import com.example.mens_store.repository.ShopRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class CartService {
    public static final int MAX_QUANTITY = 99;
    public static final int MAX_LINES = 100;
    private final CartRepository carts;
    private final ShopRepository products;
    private final CustomerAccountService customers;
    public CartService(CartRepository carts, ShopRepository products, CustomerAccountService customers) {
        this.carts = carts; this.products = products; this.customers = customers;
    }
    public Long currentAccountId() {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getAuthorities().stream().noneMatch(a -> "ROLE_CUSTOMER".equals(a.getAuthority()))) return null;
        return customers.findByPhone(auth.getName()).filter(a -> a.active()).map(a -> a.id()).orElse(null);
    }
    public long requireAccountId() {
        Long id = currentAccountId();
        if (id == null) throw new AccessDeniedException("Vui lòng đăng nhập tài khoản khách hàng");
        return id;
    }
    public Map<Integer, Integer> values(HttpSession ignored) { return carts.values(requireAccountId()); }
    // Auth lookup can precede the owner lock; refresh product reads after any lock wait.
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void add(HttpSession ignored, int id, int amount) {
        if (id <= 0 || amount < 1 || amount > MAX_QUANTITY) throw new IllegalArgumentException("Số lượng phải từ 1 đến 99");
        long owner = requireAccountId();
        carts.lockOwner(owner);
        Map<Integer, Integer> values = carts.valuesForUpdate(owner);
        int next = Math.addExact(values.getOrDefault(id, 0), amount);
        validate(id, next, values);
        carts.set(owner, id, next);
    }
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void change(HttpSession ignored, int id, int quantity) {
        if (id <= 0 || quantity < 0 || quantity > MAX_QUANTITY) throw new IllegalArgumentException("Số lượng phải từ 0 đến 99");
        long owner = requireAccountId();
        carts.lockOwner(owner);
        if (quantity > 0) validate(id, quantity, carts.valuesForUpdate(owner));
        carts.set(owner, id, quantity);
    }
    private void validate(int id, int quantity, Map<Integer, Integer> values) {
        if (quantity > MAX_QUANTITY) throw new IllegalArgumentException("Tối đa 99 sản phẩm cho mỗi mẫu");
        if (!values.containsKey(id) && values.size() >= MAX_LINES) throw new IllegalArgumentException("Giỏ hàng tối đa 100 mẫu sản phẩm");
        var product = products.activeById(id).orElseThrow(() -> new IllegalArgumentException("Sản phẩm đã ngừng bán"));
        if (quantity > product.stock()) throw new IllegalArgumentException("Số lượng vượt quá tồn kho của " + product.name());
    }
    public List<CartItem> items(HttpSession ignored) {
        List<CartItem> result = new ArrayList<>();
        values(ignored).forEach((id, quantity) -> products.findById(id).ifPresent(p -> result.add(new CartItem(p, quantity))));
        return result;
    }
    public long total(HttpSession ignored) { return items(ignored).stream().mapToLong(CartItem::subtotal).reduce(0, Math::addExact); }
    public int count(HttpSession ignored) {
        Long owner = currentAccountId();
        return owner == null ? 0 : carts.values(owner).values().stream().mapToInt(Integer::intValue).sum();
    }
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void clear(HttpSession ignored) {
        long owner = requireAccountId(); carts.lockOwner(owner); carts.clear(owner);
    }
}
