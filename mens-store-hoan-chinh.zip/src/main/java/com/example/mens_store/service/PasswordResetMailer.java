package com.example.mens_store.service;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class PasswordResetMailer {
    private final ObjectProvider<JavaMailSender> sender;
    private final String host;
    private final String from;

    public PasswordResetMailer(ObjectProvider<JavaMailSender> sender,
                               @Value("${spring.mail.host:}") String host,
                               @Value("${shop.mail.from:}") String from) {
        this.sender = sender;
        this.host = host == null ? "" : host.trim();
        this.from = from == null ? "" : from.trim();
    }

    public boolean isConfigured() {
        return !host.isBlank() && from.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")
            && sender.getIfAvailable() != null;
    }

    public void send(String email, String link, int minutes) {
        if (!isConfigured()) throw new IllegalStateException("MENS STORE chưa bật dịch vụ email khôi phục tài khoản");
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(from);
        message.setTo(email);
        message.setSubject("MENS STORE - Đặt lại mật khẩu tài khoản");
        message.setText("Xin chào,\n\nBạn vừa yêu cầu đặt lại mật khẩu tài khoản MENS STORE.\n" +
            "Mở liên kết dưới đây để tạo mật khẩu mới và tiếp tục xem giỏ hàng, đơn mua của bạn:\n\n" + link +
            "\n\nLiên kết chỉ dùng một lần và hết hạn sau " + minutes + " phút." +
            "\nNếu bạn không gửi yêu cầu, hãy bỏ qua email này." +
            "\nKhông chia sẻ liên kết đặt lại mật khẩu cho người khác.\n\nMENS STORE\nTrang phục và phụ kiện nam");
        sender.getObject().send(message);
    }
}
