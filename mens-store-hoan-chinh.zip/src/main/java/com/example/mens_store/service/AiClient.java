package com.example.mens_store.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.net.URI;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Semaphore;

/** Optional server-side provider. Disabled until enabled + API key + model are configured. */
@Service
public class AiClient {
    private final boolean enabled;
    private final String apiKey;
    private final String model;
    private final String baseUrl;
    private final Semaphore requests = new Semaphore(2);

    public AiClient(@Value("${ai.enabled:false}") boolean enabled,
                    @Value("${ai.api-key:}") String apiKey,
                    @Value("${ai.model:}") String model,
                    @Value("${ai.base-url:https://api.openai.com/v1}") String baseUrl) {
        this.enabled = enabled; this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.model = model == null ? "" : model.trim();
        this.baseUrl = baseUrl == null ? "" : baseUrl.replaceAll("/+$", "");
    }

    public boolean isConfigured() {
        if (!enabled || apiKey.isBlank() || model.isBlank()) return false;
        try {
            URI uri = URI.create(baseUrl);
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null
                && uri.getUserInfo() == null && uri.getQuery() == null && uri.getFragment() == null;
        } catch (IllegalArgumentException ex) { return false; }
    }

    public String complete(String instruction, String data, int maxTokens) {
        if (!isConfigured()) throw new IllegalStateException("AI chưa được kết nối. Cần bật AI và cấu hình API key, model trên máy chủ.");
        if (instruction == null || data == null || data.length() > 60000 || instruction.length() > 5000)
            throw new IllegalArgumentException("Nội dung gửi AI quá dài.");
        if (!requests.tryAcquire()) throw new IllegalStateException("AI đang xử lý yêu cầu khác. Vui lòng thử lại sau.");
        try {
            SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
            factory.setConnectTimeout(Duration.ofSeconds(5));
            factory.setReadTimeout(Duration.ofSeconds(35));
            RestClient client = RestClient.builder().baseUrl(baseUrl).requestFactory(factory)
                .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey).build();
            JsonNode result = client.post().uri("/chat/completions").contentType(MediaType.APPLICATION_JSON)
                .body(Map.of("model", model, "store", false,
                    "max_completion_tokens", Math.min(Math.max(maxTokens, 100), 2400),
                    "messages", List.of(Map.of("role", "system", "content", instruction),
                        Map.of("role", "user", "content", data))))
                .retrieve().body(JsonNode.class);
            String text = result == null ? "" : result.path("choices").path(0).path("message").path("content").asText("").trim();
            if (text.isBlank() || text.length() > 24000) throw new IllegalStateException("AI chưa trả lời đầy đủ. Vui lòng thử lại.");
            return text;
        } catch (org.springframework.web.client.RestClientException ex) {
            // Never expose provider responses, prompts or API key in the browser/log.
            throw new IllegalStateException("Không kết nối được dịch vụ AI. Kiểm tra cấu hình và hạn mức dịch vụ trên máy chủ.");
        } finally { requests.release(); }
    }
}
