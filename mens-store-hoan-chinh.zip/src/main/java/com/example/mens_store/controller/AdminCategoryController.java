package com.example.mens_store.controller;

import com.example.mens_store.model.AdminCategoryForm;
import com.example.mens_store.repository.AdminCategoryRepository;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/quan-tri/danh-muc")
public class AdminCategoryController {
    private final AdminCategoryRepository categories;
    public AdminCategoryController(AdminCategoryRepository categories){this.categories=categories;}
    @GetMapping public String all(Model m){m.addAttribute("categoryRows",categories.all());return "admin/categories";}
    @GetMapping("/them") public String create(Model m){m.addAttribute("categoryForm",new AdminCategoryForm());return "admin/category-form";}
    @GetMapping("/{id}/sua") public String edit(@PathVariable int id,Model m){
        var row=categories.find(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
        var f=new AdminCategoryForm();f.setCode(row.code());f.setName(row.name());f.setDescription(row.description());f.setSort(row.sort());f.setActive(row.active());
        m.addAttribute("categoryForm",f);m.addAttribute("editId",id);return "admin/category-form";
    }
    @PostMapping("/luu") public String save(@RequestParam(required=false) Integer id,@Valid @ModelAttribute("categoryForm") AdminCategoryForm f,BindingResult errors,Model m,RedirectAttributes flash){
        m.addAttribute("editId",id);
        if(errors.hasErrors())return "admin/category-form";
        try {
            if(id==null)categories.create(f);
            else if(!categories.update(id,f))throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }catch(DataIntegrityViolationException ex){errors.rejectValue("code","duplicate","Mã danh mục đã tồn tại hoặc dữ liệu chưa hợp lệ.");return "admin/category-form";}
        flash.addFlashAttribute("message","Đã lưu danh mục.");return "redirect:/quan-tri/danh-muc";
    }
    @PostMapping("/{id}/trang-thai") public String status(@PathVariable int id,@RequestParam boolean active,RedirectAttributes flash){
        boolean updated=categories.setActive(id,active);
        flash.addFlashAttribute(updated?"message":"error",updated?(active?"Đã hiển thị danh mục.":"Đã ẩn danh mục và các sản phẩm thuộc danh mục khỏi cửa hàng."):"Không tìm thấy danh mục.");
        return "redirect:/quan-tri/danh-muc";
    }
    @PostMapping("/{id}/xoa") public String delete(@PathVariable int id,RedirectAttributes flash){
        boolean deleted=false;
        try{deleted=categories.deleteEmpty(id);}catch(DataIntegrityViolationException ex){ /* A product may have been added concurrently. */ }
        flash.addFlashAttribute(deleted?"message":"error",deleted?"Đã xóa danh mục trống.":"Danh mục đang có sản phẩm hoặc không tồn tại. Hãy dùng Ẩn để giữ dữ liệu liên quan.");
        return "redirect:/quan-tri/danh-muc";
    }
}
