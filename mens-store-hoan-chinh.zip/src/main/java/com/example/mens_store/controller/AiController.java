package com.example.mens_store.controller;

import com.example.mens_store.service.AiAnalysisService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;
import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;

@Controller
public class AiController {
    private record Window(long start, int count) {}
    private final AiAnalysisService ai;
    private final ConcurrentHashMap<String, Window> limits = new ConcurrentHashMap<>();

    public AiController(AiAnalysisService ai) { this.ai = ai; }

    private void limit(Authentication auth) {
        if (auth == null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        long now = Instant.now().getEpochSecond();
        limits.entrySet().removeIf(e -> now - e.getValue().start() > 600);
        limits.compute(auth.getName(), (key, old) -> {
            Window next = old == null || now - old.start() >= 60 ? new Window(now, 1) : new Window(old.start(), old.count() + 1);
            if (next.count() > 10) throw new IllegalStateException("Tối đa 10 yêu cầu AI mỗi phút. Vui lòng chờ một chút.");
            return next;
        });
    }

    private void adminModel(Model model) {
        model.addAttribute("aiConfigured", ai.isConfigured());
        model.addAttribute("reports", ai.reports());
    }

    @GetMapping("/tro-ly")
    public String chat(Model model) {
        model.addAttribute("aiConfigured", ai.isConfigured());
        return "customer/assistant";
    }

    @PostMapping("/tro-ly")
    public String chat(@RequestParam(defaultValue="") String message, Authentication auth, Model model) {
        model.addAttribute("aiConfigured", ai.isConfigured());
        model.addAttribute("message", message.length() > 1000 ? message.substring(0, 1000) : message);
        if (!ai.isConfigured()) {
            model.addAttribute("error", "Trợ lý phối đồ hiện chưa sẵn sàng. Bạn có thể xem chất liệu, phom và gợi ý phối trong danh mục MENS STORE.");
            return "customer/assistant";
        }
        try { limit(auth); model.addAttribute("answer", ai.chat(message)); }
        catch (IllegalArgumentException | IllegalStateException ex) {
            model.addAttribute("error", "Chưa trả lời được câu hỏi phối đồ. Bạn có thể nêu dịp mặc, màu hoặc phom mong muốn trong tối đa 1000 ký tự và thử lại sau.");
        }
        return "customer/assistant";
    }

    @GetMapping("/quan-tri/ai")
    public String admin(Model model) { adminModel(model); return "admin/ai"; }

    @PostMapping("/quan-tri/ai/phan-tich")
    public String analyze(@RequestParam String kind, Authentication auth, Model model) {
        try { limit(auth); model.addAttribute("analysis", ai.analyze(kind)); }
        catch (IllegalArgumentException | IllegalStateException ex) { model.addAttribute("error", ex.getMessage()); }
        adminModel(model); return "admin/ai";
    }

    @PostMapping("/quan-tri/ai/danh-muc")
    public String category(@RequestParam(defaultValue="") String productName,
            @RequestParam(defaultValue="") String description, Authentication auth, Model model) {
        try { limit(auth); model.addAttribute("analysis", ai.suggestCategory(productName, description)); }
        catch (IllegalArgumentException | IllegalStateException ex) { model.addAttribute("error", ex.getMessage()); }
        adminModel(model); return "admin/ai";
    }

    @PostMapping("/quan-tri/ai/binh-luan")
    public String comment(@RequestParam(defaultValue="") String content, Authentication auth, Model model) {
        try {
            limit(auth);
            AiAnalysisService.SpamDecision decision = ai.classifyComment(content);
            model.addAttribute("analysis", "Đánh giá bình luận về trang phục: " + (decision.spam() ? "Có dấu hiệu quảng cáo hoặc nội dung spam" : "Chưa xác định là spam; cần đọc như phản hồi của người mua")
                + "\nĐộ tin cậy do mô hình báo: " + Math.round(decision.confidence() * 100) + "%"
                + "\nLý do: " + decision.reason()
                + "\nGóp ý về size, chất liệu hoặc giao hàng có thể hợp lệ. Đây là nhận xét văn bản; chưa thay đổi bình luận nào.");
        } catch (IllegalArgumentException | IllegalStateException ex) { model.addAttribute("error", ex.getMessage()); }
        adminModel(model); return "admin/ai";
    }

    @GetMapping("/quan-tri/ai/bao-cao/{id:.+}")
    public String report(@PathVariable String id, Model model) {
        try { model.addAttribute("analysis", ai.readReport(id)); }
        catch (IllegalArgumentException ex) { throw new ResponseStatusException(HttpStatus.NOT_FOUND); }
        adminModel(model); return "admin/ai";
    }
}
