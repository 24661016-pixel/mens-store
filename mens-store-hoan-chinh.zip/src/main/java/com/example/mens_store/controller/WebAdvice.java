package com.example.mens_store.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.example.mens_store.repository.ShopRepository;
import com.example.mens_store.service.CartService;

/** Nội dung dùng chung của cửa hàng thời trang nam MENS STORE. */
@ControllerAdvice
public class WebAdvice {
    private final ShopRepository shop;
    private final CartService cart;
    public WebAdvice(ShopRepository shop, CartService cart) {
        this.shop = shop;
        this.cart = cart;
    }

    @ModelAttribute
    public void global(Model model, HttpSession session) {
        model.addAttribute("todayInVietnam", java.time.LocalDate.now(java.time.ZoneId.of("Asia/Ho_Chi_Minh")));
        model.addAttribute("orderStatusLabels", java.util.Map.of(
            "CHO_XAC_NHAN", "Chờ cửa hàng xác nhận", "DA_XAC_NHAN", "Đang chuẩn bị hàng",
            "DANG_GIAO", "Đang giao hàng", "HOAN_TAT", "Đã hoàn tất", "DA_HUY", "Đã hủy"));
        model.addAttribute("paymentStatusLabels", java.util.Map.of(
            "CHUA_THANH_TOAN", "Chưa thanh toán", "CHO_KIEM_TRA", "Chờ đối soát chuyển khoản",
            "DA_THANH_TOAN", "Đã thanh toán"));
        model.addAttribute("paymentMethodLabels", java.util.Map.of(
            "COD", "Thanh toán khi nhận hàng (COD)", "CHUYEN_KHOAN", "Chuyển khoản ngân hàng"));
        model.addAttribute("commentStatusLabels", java.util.Map.of(
            "CHO_DUYET", "Chờ duyệt", "HIEN_THI", "Đang hiển thị", "SPAM", "Nội dung rác", "AN", "Đã ẩn"));
        model.addAttribute("categories", shop.categories());
        model.addAttribute("cartCount", cart.count(session));
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        model.addAttribute("customerLoggedIn", auth != null && auth.isAuthenticated() &&
            auth.getAuthorities().stream().anyMatch(a -> "ROLE_CUSTOMER".equals(a.getAuthority())));
        model.addAttribute("adminLoggedIn", auth != null && auth.isAuthenticated() &&
            auth.getAuthorities().stream().anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority())));
    }
}
