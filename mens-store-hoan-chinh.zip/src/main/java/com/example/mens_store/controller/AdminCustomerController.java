package com.example.mens_store.controller;

import com.example.mens_store.model.AdminCustomerForm;
import com.example.mens_store.model.StrongPasswordValidator;
import com.example.mens_store.repository.AdminCustomerRepository;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;
import java.util.Objects;

@Controller
@RequestMapping("/quan-tri/tai-khoan")
public class AdminCustomerController {
    private final AdminCustomerRepository customers;
    private final PasswordEncoder encoder;
    public AdminCustomerController(AdminCustomerRepository customers,PasswordEncoder encoder){this.customers=customers;this.encoder=encoder;}
    @GetMapping public String list(@RequestParam(name="q",defaultValue="") String query,Model m){
        String q=query.trim();if(q.length()>100)q=q.substring(0,100);
        m.addAttribute("q",q);m.addAttribute("accounts",customers.search(q));m.addAttribute("totalAccounts",customers.countAll());m.addAttribute("activeAccounts",customers.countActive());return "admin/customers";
    }
    @GetMapping("/them") public String create(Model m){m.addAttribute("customerForm",new AdminCustomerForm());return "admin/customer-form";}
    @GetMapping("/{id}/sua") public String edit(@PathVariable long id,Model m){
        var row=customers.find(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
        var f=new AdminCustomerForm();f.setFullName(row.fullName());f.setEmail(row.email());f.setPhone(row.phone());f.setAddress(row.address());f.setBirthDate(row.birthDate());f.setActive(row.active());
        m.addAttribute("customerForm",f);m.addAttribute("editId",id);return "admin/customer-form";
    }
    @PostMapping("/luu") public String save(@RequestParam(required=false) Long id,@Valid @ModelAttribute("customerForm") AdminCustomerForm f,BindingResult errors,Model m,RedirectAttributes flash){
        m.addAttribute("editId",id);
        if(f.getBirthDate()!=null && f.getBirthDate().isBefore(LocalDate.of(1900,1,1)))errors.rejectValue("birthDate","range","Ngày sinh phải từ năm 1900.");
        if(id==null){
            String p=f.getPassword();
            if(!StrongPasswordValidator.isStrong(p))
                errors.rejectValue("password","strength","Mật khẩu cần ít nhất 8 ký tự, có chữ hoa, chữ thường, số, ký tự đặc biệt; không có khoảng trắng, tối đa 72 byte UTF-8.");
            if(!Objects.equals(p,f.getConfirmPassword()))errors.rejectValue("confirmPassword","mismatch","Mật khẩu xác nhận không khớp.");
        }
        if(errors.hasErrors())return "admin/customer-form";
        try{
            if(id==null)customers.create(f,encoder.encode(f.getPassword()));
            else if(!customers.update(id,f))throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }catch(DataIntegrityViolationException ex){errors.reject("duplicate","Email hoặc số điện thoại đã tồn tại, hoặc dữ liệu không hợp lệ.");return "admin/customer-form";}
        flash.addFlashAttribute("message",id==null?"Đã tạo tài khoản khách hàng.":"Đã cập nhật hồ sơ. Khi thay số điện thoại, khách hàng cần đăng nhập lại bằng số mới.");return "redirect:/quan-tri/tai-khoan";
    }
    @PostMapping("/{id}/trang-thai") public String status(@PathVariable long id,@RequestParam boolean active,RedirectAttributes flash){
        if(id<=0 || !customers.setActive(id,active))flash.addFlashAttribute("error","Không tìm thấy tài khoản khách hàng.");
        else flash.addFlashAttribute("message",active?"Đã mở khóa tài khoản.":"Đã vô hiệu hóa tài khoản; giữ nguyên đơn hàng và dữ liệu giỏ đã lưu.");
        return "redirect:/quan-tri/tai-khoan";
    }
}
