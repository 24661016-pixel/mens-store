package com.example.mens_store.controller;

import com.example.mens_store.model.CustomerAccount;
import com.example.mens_store.model.ShopOrder;
import com.example.mens_store.repository.OrderRepository;
import com.example.mens_store.service.BankTransferService;
import com.example.mens_store.service.CustomerAccountService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.server.ResponseStatusException;

@Controller
public class CustomerOrderController {
    private final CustomerAccountService customers;
    private final OrderRepository orders;
    private final BankTransferService transfers;

    public CustomerOrderController(CustomerAccountService customers, OrderRepository orders, BankTransferService transfers) {
        this.customers = customers; this.orders = orders; this.transfers = transfers;
    }

    private long accountId(Authentication auth) {
        if (auth == null || auth.getAuthorities().stream().noneMatch(a -> "ROLE_CUSTOMER".equals(a.getAuthority())))
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        return customers.findByPhone(auth.getName()).filter(CustomerAccount::active)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED)).id();
    }

    @GetMapping("/tai-khoan/don-hang")
    public String list(Authentication auth, Model model) {
        model.addAttribute("orders", orders.forAccount(accountId(auth)));
        return "customer/orders";
    }

    @GetMapping("/tai-khoan/don-hang/{code}")
    public String detail(@PathVariable String code, Authentication auth, Model model) {
        ShopOrder order = orders.findOwnedByCode(code, accountId(auth))
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        model.addAttribute("order", order); model.addAttribute("lines", orders.lines(order.id()));
        model.addAttribute("transferConfigured", transfers.isConfigured());
        model.addAttribute("bankName", transfers.getBankName());
        model.addAttribute("bankAccount", transfers.getBankAccount());
        model.addAttribute("bankAccountName", transfers.getBankAccountName());
        boolean waiting = "CHUYEN_KHOAN".equals(order.paymentMethod())
            && !"DA_THANH_TOAN".equals(order.paymentStatus()) && !"DA_HUY".equals(order.status());
        model.addAttribute("waitingForTransfer", waiting);
        if (waiting && transfers.isConfigured()) {
            model.addAttribute("qrUrl", transfers.createQrUrl(order.total(), order.code()));
        }
        return "success";
    }
}
