package com.example.mens_store.controller;

import com.example.mens_store.service.AdminAnalyticsService;
import com.example.mens_store.repository.AdminCategoryRepository;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.nio.charset.StandardCharsets;

@Controller
public class AdminAnalyticsController {
    private final AdminAnalyticsService analytics;
    private final AdminCategoryRepository shop;
    public AdminAnalyticsController(AdminAnalyticsService analytics,AdminCategoryRepository shop) { this.analytics=analytics;this.shop=shop; }
    private AdminAnalyticsService.Filter filter(String range,String anchor,String from,String to,String group,Integer category) {
        if (category!=null && shop.all().stream().noneMatch(c->c.id()==category)) throw new IllegalArgumentException("Không tìm thấy danh mục.");
        return AdminAnalyticsService.filter(range,anchor,from,to,group,category);
    }
    @GetMapping({"/quan-tri","/quan-tri/"})
    public String dashboard(@RequestParam(defaultValue="month") String range,
        @RequestParam(required=false) String anchor,@RequestParam(required=false) String from,@RequestParam(required=false) String to,
        @RequestParam(defaultValue="day") String group,@RequestParam(required=false) Integer category,Model model) {
        AdminAnalyticsService.Filter f;
        try { f=filter(range,anchor,from,to,group,category); }
        catch(IllegalArgumentException ex) { model.addAttribute("error",ex.getMessage());f=AdminAnalyticsService.filter("month",null,null,null,"day",null); }
        model.addAttribute("report",analytics.report(f));
        model.addAttribute("filter",f);
        model.addAttribute("reportCategories",shop.all());
        return "admin/dashboard";
    }
    @GetMapping("/quan-tri/bao-cao.csv")
    public ResponseEntity<byte[]> csv(@RequestParam(defaultValue="month") String range,
        @RequestParam(required=false) String anchor,@RequestParam(required=false) String from,@RequestParam(required=false) String to,
        @RequestParam(defaultValue="day") String group,@RequestParam(required=false) Integer category) {
        try {
            var f=filter(range,anchor,from,to,group,category);
            return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename=mens-store-doanh-thu.csv")
                .contentType(new MediaType("text","csv",StandardCharsets.UTF_8))
                .body(analytics.csv(analytics.report(f)).getBytes(StandardCharsets.UTF_8));
        } catch(IllegalArgumentException ex) {
            return ResponseEntity.badRequest().contentType(new MediaType("text","plain",StandardCharsets.UTF_8)).body(ex.getMessage().getBytes(StandardCharsets.UTF_8));
        }
    }
}
