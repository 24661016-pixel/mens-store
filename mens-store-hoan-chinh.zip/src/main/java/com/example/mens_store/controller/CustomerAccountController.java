package com.example.mens_store.controller;

import com.example.mens_store.model.AccountValidationException;
import com.example.mens_store.model.CustomerAccount;
import com.example.mens_store.model.RegistrationForm;
import com.example.mens_store.service.CustomerAccountService;
import jakarta.validation.Valid;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import java.util.Objects;

@Controller
public class CustomerAccountController {
    private final CustomerAccountService customers;
    public CustomerAccountController(CustomerAccountService customers) { this.customers = customers; }

    @InitBinder("registrationForm")
    public void registrationBinder(WebDataBinder binder) {
        binder.setAllowedFields("fullName","email","phone","address","birthday","password","confirmPassword");
    }

    @GetMapping({"/tai-khoan/dang-ky", "/dang-ky"})
    public String registerForm(Model model) {
        model.addAttribute("registrationForm", new RegistrationForm());
        return "customer/register";
    }

    @PostMapping({"/tai-khoan/dang-ky", "/dang-ky"})
    public String register(@Valid @ModelAttribute("registrationForm") RegistrationForm form,
                           BindingResult errors) {
        if (!Objects.equals(form.getPassword(), form.getConfirmPassword()))
            errors.rejectValue("confirmPassword", "mismatch", "Mật khẩu xác nhận không khớp");
        if (!errors.hasErrors()) {
            try { customers.register(form); }
            catch (AccountValidationException ex) { errors.rejectValue(ex.field(), "invalid", ex.getMessage()); }
        }
        if (errors.hasErrors()) {
            form.setPassword(null);
            form.setConfirmPassword(null);
            return "customer/register";
        }
        return "redirect:/?registered";
    }

    @GetMapping("/tai-khoan/dang-nhap")
    public String login(Authentication authentication) {
        return isCustomer(authentication) ? "redirect:/tai-khoan" : "customer/login";
    }

    @GetMapping({"/tai-khoan", "/tai-khoan/"})
    public String profile(Authentication authentication, Model model) {
        if (!isCustomer(authentication)) return "redirect:/tai-khoan/dang-nhap";
        CustomerAccount account = customers.findByPhone(authentication.getName())
            .orElseThrow(() -> new IllegalStateException("Tài khoản không tồn tại"));
        model.addAttribute("fullName", account.fullName());
        model.addAttribute("email", account.email());
        model.addAttribute("phone", account.phone());
        model.addAttribute("address", account.address());
        model.addAttribute("birthday", account.birthday());
        model.addAttribute("createdAt", account.createdAt());
        return "customer/profile";
    }

    private boolean isCustomer(Authentication authentication) {
        return authentication != null && authentication.isAuthenticated()
            && !(authentication instanceof AnonymousAuthenticationToken)
            && authentication.getAuthorities().stream()
                .anyMatch(a -> "ROLE_CUSTOMER".equals(a.getAuthority()));
    }
}
