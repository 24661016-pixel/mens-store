
package com.example.mens_store.controller;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.mens_store.model.ProductForm;
import com.example.mens_store.repository.OrderRepository;
import com.example.mens_store.repository.ShopRepository;
import com.example.mens_store.service.ImageService;
import com.example.mens_store.service.OrderService;

import java.io.IOException;

@Controller
@RequestMapping("/quan-tri")
public class AdminController {

    private final OrderRepository orders;
    private final OrderService orderService;
    private final ShopRepository products;
    private final ImageService images;
    private final JdbcTemplate jdbc;

    public AdminController(
            OrderRepository orders,
            OrderService orderService,
            ShopRepository products,
            ImageService images, JdbcTemplate jdbc) {

        this.orders = orders;
        this.orderService = orderService;
        this.products = products;
        this.images = images;
        this.jdbc = jdbc;
    }

    // Xem chi tiết đơn hàng
    @GetMapping("/don-hang/{id}")
    public String detail(@PathVariable long id, Model m) {
        try { m.addAttribute("order", orders.get(id)); }
        catch (IllegalArgumentException ex) { throw new ResponseStatusException(HttpStatus.NOT_FOUND); }
        m.addAttribute("lines", orders.lines(id));

        return "admin/order";
    }

    // Cập nhật trạng thái xử lý đơn hàng
    @PostMapping("/don-hang/{id}/trang-thai")
    public String status(
            @PathVariable long id,
            @RequestParam String status,
            RedirectAttributes flash) {

        try {
            orderService.changeStatus(id, status);

            flash.addFlashAttribute(
                "message",
                "Đã cập nhật trạng thái đơn hàng"
            );

        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }

        return "redirect:/quan-tri/don-hang/" + id;
    }

    // Admin xác nhận khách hàng đã chuyển khoản
    @PostMapping("/don-hang/{id}/xac-nhan-thanh-toan")
    public String confirmTransferPayment(
            @PathVariable long id,
            @RequestParam(
                name = "transactionCode",
                required = false
            ) String transactionCode,
            RedirectAttributes flash) {

        try {
            orderService.confirmTransferPayment(
                id,
                transactionCode
            );

            flash.addFlashAttribute(
                "message",
                "Đã xác nhận thanh toán chuyển khoản thành công"
            );

        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute(
                "error",
                ex.getMessage()
            );
        }

        return "redirect:/quan-tri/don-hang/" + id;
    }

    // Danh sách sản phẩm
    @GetMapping("/san-pham")
    public String products(Model m) {
        m.addAttribute("products", products.allAdmin());

        return "admin/products";
    }

    // Mở form thêm sản phẩm
    @GetMapping("/san-pham/them")
    public String create(Model m) {
        m.addAttribute("productForm", new ProductForm());
        m.addAttribute("editId", null);

        return "admin/product-form";
    }

    // Mở form sửa sản phẩm
    @GetMapping("/san-pham/{id}/sua")
    public String edit(@PathVariable int id, Model m) {

        var p = products.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        m.addAttribute("productForm", ProductForm.from(p));
        m.addAttribute("editId", id);
        m.addAttribute("currentImage", p.image());

        return "admin/product-form";
    }

    // Lưu sản phẩm
    @PostMapping("/san-pham/luu")
    public String save(
            @RequestParam(required = false) Integer id,
            @ModelAttribute("productForm") ProductForm productForm,
            BindingResult binding,
            @RequestParam(
                name = "file",
                required = false
            ) MultipartFile file,
            Model model,
            RedirectAttributes flash) {

        if (binding.hasErrors()) return invalid(model, id, productForm, "Giá, tồn kho và danh mục phải là số hợp lệ.");
        String warning = validate(productForm);

        if (warning != null) {
            return invalid(
                model,
                id,
                productForm,
                warning
            );
        }

        try {
            String oldImage = id == null
                ? "/images/products/default.svg"
                : products.findById(id)
                    .orElseThrow(() ->
                        new IllegalArgumentException(
                            "Không tìm thấy sản phẩm"
                        )
                    ).image();

            String uploaded = images.save(file);

            String image = uploaded == null
                ? oldImage
                : uploaded;

            if (id == null) {
                products.create(productForm, image);
            } else {
                products.update(id, productForm, image);
            }

            flash.addFlashAttribute(
                "message",
                "Đã lưu sản phẩm"
            );

            return "redirect:/quan-tri/san-pham";

        } catch (
            IOException
            | IllegalArgumentException
            | DataIntegrityViolationException ex
        ) {
            return invalid(
                model,
                id,
                productForm,
                "Không thể lưu sản phẩm. Kiểm tra mã trùng, dữ liệu bắt buộc và ảnh JPEG/PNG tối đa 4 MB."
            );
        }
    }

    // Hiển thị lỗi khi lưu sản phẩm
    private String invalid(
            Model m,
            Integer id,
            ProductForm f,
            String message) {

        m.addAttribute("productForm", f);
        m.addAttribute("editId", id);
        m.addAttribute("error", message);

        if (id != null) {
            products.findById(id)
                .ifPresent(p ->
                    m.addAttribute("currentImage", p.image())
                );
        }

        return "admin/product-form";
    }

    // Kiểm tra dữ liệu sản phẩm
    private String validate(ProductForm f) {

        if (f.getSku()!=null) f.setSku(f.getSku().trim());
        if (f.getName()!=null) f.setName(f.getName().trim());
        if (f.getSku() == null
                || !f.getSku().matches("[A-Za-z0-9_-]{2,30}")) {
            return "Mã sản phẩm 2–30 ký tự chữ/số";
        }

        if (f.getName() == null
                || f.getName().isBlank()
                || f.getName().length() > 150) {
            return "Tên sản phẩm không hợp lệ";
        }

        if (f.getCategoryId() < 1
                || products.categories().stream()
                    .noneMatch(c -> c.id() == f.getCategoryId())) {
            return "Danh mục không hợp lệ";
        }

        if (f.getPrice() < 0
                || f.getPrice() > 999_999_999_999L) {
            return "Giá sản phẩm không hợp lệ";
        }

        if (f.getStock() < 0
                || f.getStock() > 1_000_000) {
            return "Số lượng tồn không hợp lệ";
        }

        if (f.getDescription() != null
                && f.getDescription().length() > 10000) {
            return "Mô tả quá dài";
        }

        if (f.getSpecifications() != null && f.getSpecifications().length() > 10000) return "Thông tin chất liệu/kiểu dáng quá dài";
        return null;
    }
    @PostMapping("/san-pham/{id}/trang-thai")
    public String productStatus(@PathVariable int id, @RequestParam boolean active, RedirectAttributes flash) {
        int updated=jdbc.update("UPDATE san_pham SET trang_thai=? WHERE san_pham_id=?",active,id);
        flash.addFlashAttribute(updated==1?"message":"error",updated==1?(active?"Đã hiển thị sản phẩm.":"Đã ngừng kinh doanh sản phẩm; giữ nguyên lịch sử đơn hàng."):"Không tìm thấy sản phẩm.");
        return "redirect:/quan-tri/san-pham";
    }
}
