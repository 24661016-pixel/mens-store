package com.example.mens_store.controller;

import com.example.mens_store.model.AdminPromotionForm;
import com.example.mens_store.repository.AdminPromotionRepository;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;

@Controller
@RequestMapping("/quan-tri/khuyen-mai")
public class AdminPromotionController {
    private final AdminPromotionRepository campaigns;
    public AdminPromotionController(AdminPromotionRepository campaigns){this.campaigns=campaigns;}
    @GetMapping public String all(Model m){m.addAttribute("campaigns",campaigns.all());return "admin/promotions";}
    @GetMapping("/them") public String create(Model m){m.addAttribute("promotionForm",new AdminPromotionForm());return "admin/promotion-form";}
    @GetMapping("/{id}/sua") public String edit(@PathVariable long id,Model m){
        var row=campaigns.find(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
        var f=new AdminPromotionForm();f.setCode(row.code());f.setName(row.name());f.setPercentage(row.percentage());f.setStarts(row.starts());f.setEnds(row.ends());f.setActive(row.active());
        m.addAttribute("promotionForm",f);m.addAttribute("editId",id);return "admin/promotion-form";
    }
    @PostMapping("/luu") public String save(@RequestParam(required=false) Long id,@Valid @ModelAttribute("promotionForm") AdminPromotionForm f,BindingResult errors,Model m,RedirectAttributes flash){
        m.addAttribute("editId",id);
        if(f.getStarts()!=null && f.getEnds()!=null && f.getEnds().isBefore(f.getStarts()))errors.rejectValue("ends","dateOrder","Ngày kết thúc phải từ ngày bắt đầu trở đi.");
        if(f.getStarts()!=null && (f.getStarts().isBefore(LocalDate.of(2000,1,1)) || f.getStarts().isAfter(LocalDate.of(2100,12,31))))errors.rejectValue("starts","range","Ngày bắt đầu phải trong năm 2000–2100.");
        if(f.getEnds()!=null && (f.getEnds().isBefore(LocalDate.of(2000,1,1)) || f.getEnds().isAfter(LocalDate.of(2100,12,31))))errors.rejectValue("ends","range","Ngày kết thúc phải trong năm 2000–2100.");
        if(errors.hasErrors())return "admin/promotion-form";
        try{if(id==null)campaigns.create(f);else if(!campaigns.update(id,f))throw new ResponseStatusException(HttpStatus.NOT_FOUND);}
        catch(DataIntegrityViolationException ex){errors.rejectValue("code","duplicate","Mã chiến dịch đã tồn tại hoặc dữ liệu chưa hợp lệ.");return "admin/promotion-form";}
        flash.addFlashAttribute("message","Đã lưu kế hoạch khuyến mãi. Giá đặt hàng không tự thay đổi theo kế hoạch này.");return "redirect:/quan-tri/khuyen-mai";
    }
    @PostMapping("/{id}/xoa") public String delete(@PathVariable long id,RedirectAttributes flash){boolean ok=campaigns.delete(id);flash.addFlashAttribute(ok?"message":"error",ok?"Đã xóa kế hoạch khuyến mãi.":"Không tìm thấy kế hoạch.");return "redirect:/quan-tri/khuyen-mai";}
}
