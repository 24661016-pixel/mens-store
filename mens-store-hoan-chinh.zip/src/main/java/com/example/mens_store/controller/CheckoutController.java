package com.example.mens_store.controller;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;
import com.example.mens_store.model.CheckoutForm;
import com.example.mens_store.model.CustomerAccount;
import com.example.mens_store.model.OrderReceipt;
import com.example.mens_store.service.BankTransferService;
import com.example.mens_store.service.CartService;
import com.example.mens_store.service.CustomerAccountService;
import com.example.mens_store.service.OrderService;
import java.util.UUID;

@Controller
public class CheckoutController {
    private static final String TOKEN_KEY = "CHECKOUT_TOKEN";
    private final CartService cart;
    private final OrderService orders;
    private final CustomerAccountService customers;
    private final BankTransferService transfers;

    public CheckoutController(CartService cart, OrderService orders,
            CustomerAccountService customers, BankTransferService transfers) {
        this.cart = cart; this.orders = orders; this.customers = customers; this.transfers = transfers;
    }

    private CustomerAccount account(Authentication auth) {
        if (auth == null || auth.getAuthorities().stream().noneMatch(a -> "ROLE_CUSTOMER".equals(a.getAuthority())))
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        return customers.findByPhone(auth.getName()).filter(CustomerAccount::active)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
    }

    @GetMapping("/dat-hang")
    public String form(HttpSession session, Model model, Authentication authentication) {
        CustomerAccount account = account(authentication);
        if (cart.items(session).isEmpty()) return "redirect:/gio-hang";
        CheckoutForm checkout = new CheckoutForm();
        checkout.setFullName(account.fullName()); checkout.setPhone(account.phone());
        checkout.setEmail(account.email()); checkout.setAddress(account.address());
        model.addAttribute("checkoutForm", checkout);
        populate(model, session);
        return "checkout";
    }

    private void populate(Model model, HttpSession session) {
        synchronized (session) {
            if (session.getAttribute(TOKEN_KEY) == null) session.setAttribute(TOKEN_KEY, UUID.randomUUID().toString());
            model.addAttribute("checkoutToken", session.getAttribute(TOKEN_KEY));
        }
        model.addAttribute("items", cart.items(session)); model.addAttribute("total", cart.total(session));
        model.addAttribute("transferConfigured", transfers.isConfigured());
        model.addAttribute("bankAccount", transfers.getBankAccount());
        model.addAttribute("bankName", transfers.getBankName());
    }

    @PostMapping("/dat-hang")
    public String place(@Valid @ModelAttribute("checkoutForm") CheckoutForm form, BindingResult errors,
            @RequestParam(required=false) String checkoutToken,
            HttpSession session, Model model, Authentication authentication) {
        CustomerAccount account = account(authentication);
        synchronized (session) {
            Object expectedToken = session.getAttribute(TOKEN_KEY);
            if (expectedToken == null || !expectedToken.equals(checkoutToken)) return "redirect:/tai-khoan/don-hang";
            if (cart.items(session).isEmpty()) return "redirect:/gio-hang";
            if (errors.hasErrors()) { populate(model, session); return "checkout"; }
            if ("CHUYEN_KHOAN".equals(form.getPaymentMethod()) && !transfers.isConfigured()) {
                model.addAttribute("checkoutError", "Chuyển khoản hiện chưa sẵn sàng. Vui lòng chọn thanh toán khi nhận hàng.");
                populate(model, session); return "checkout";
            }
            try {
                OrderReceipt receipt = orders.place(form, cart.values(session), account.id());
                session.removeAttribute(TOKEN_KEY);
                // Stored-order destination verifies ownership and survives refresh/re-login.
                return "redirect:/tai-khoan/don-hang/" + receipt.code();
            } catch (IllegalArgumentException | ArithmeticException ex) {
                model.addAttribute("checkoutError", ex.getMessage());
                populate(model, session); return "checkout";
            }
        }
    }

    @GetMapping("/dat-hang/thanh-cong")
    public String success() { return "redirect:/tai-khoan/don-hang"; }
}
