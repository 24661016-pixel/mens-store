package com.example.mens_store.controller;

import com.example.mens_store.model.AccountValidationException;
import com.example.mens_store.model.ForgotPasswordForm;
import com.example.mens_store.model.ResetPasswordForm;
import com.example.mens_store.service.PasswordResetService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

@Controller
public class PasswordResetController {
    private final PasswordResetService resets;
    public PasswordResetController(PasswordResetService resets) { this.resets = resets; }

    @InitBinder("forgotPasswordForm")
    public void forgotBinder(WebDataBinder binder) { binder.setAllowedFields("email"); }
    @InitBinder("resetPasswordForm")
    public void resetBinder(WebDataBinder binder) { binder.setAllowedFields("token","password","confirmPassword"); }

    @ModelAttribute("mailConfigured")
    public boolean mailConfigured() { return resets.isMailConfigured(); }

    @GetMapping("/tai-khoan/quen-mat-khau")
    public String forgot(Model model, HttpServletResponse response) {
        privatePage(response);
        model.addAttribute("forgotPasswordForm",new ForgotPasswordForm());
        return "customer/forgot-password";
    }

    @PostMapping("/tai-khoan/quen-mat-khau")
    public String send(@Valid @ModelAttribute("forgotPasswordForm") ForgotPasswordForm form, BindingResult errors,
                       HttpServletRequest request, HttpServletResponse response) {
        privatePage(response);
        if (errors.hasErrors() || !resets.isMailConfigured()) return "customer/forgot-password";
        resets.request(form.getEmail(), request.getRemoteAddr());
        return "redirect:/tai-khoan/quen-mat-khau?sent";
    }

    @GetMapping("/tai-khoan/dat-lai-mat-khau")
    public String form(@RequestParam(required=false) String token, Model model, HttpServletResponse response) {
        privatePage(response);
        ResetPasswordForm form = new ResetPasswordForm();
        form.setToken(token);
        model.addAttribute("resetPasswordForm", form);
        model.addAttribute("validLink", resets.isValid(token));
        return "customer/reset-password";
    }

    @PostMapping("/tai-khoan/dat-lai-mat-khau")
    public String reset(@Valid @ModelAttribute("resetPasswordForm") ResetPasswordForm form, BindingResult errors,
                        Model model, HttpServletResponse response) {
        privatePage(response);
        if (!errors.hasErrors()) {
            try { resets.reset(form); }
            catch (AccountValidationException ex) { errors.rejectValue(ex.field(),"invalid",ex.getMessage()); }
        }
        if (errors.hasErrors()) {
            model.addAttribute("validLink", resets.isValid(form.getToken()));
            form.setPassword(null);
            form.setConfirmPassword(null);
            return "customer/reset-password";
        }
        return "redirect:/tai-khoan/dang-nhap?reset";
    }

    private static void privatePage(HttpServletResponse response) {
        response.setHeader("Referrer-Policy", "no-referrer");
        response.setHeader("Cache-Control", "no-store, private, max-age=0");
    }
}
