package com.example.mens_store.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.mens_store.service.CartService;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/gio-hang")
public class CartApiController {
    private final CartService cart;
    public CartApiController(CartService cart) { this.cart = cart; }
    @GetMapping
    public Map<String, Object> get(HttpSession session) { return snapshot(session, null); }
    @PostMapping("/them")
    public ResponseEntity<Map<String, Object>> add(@RequestParam int id, @RequestParam(defaultValue="1") int quantity, HttpSession session) {
        try { cart.add(session, id, quantity); return ResponseEntity.ok(snapshot(session, "Đã thêm vào giỏ hàng")); }
        catch (IllegalArgumentException | ArithmeticException ex) { return ResponseEntity.badRequest().body(snapshot(session, ex.getMessage())); }
    }
    @PostMapping("/cap-nhat")
    public ResponseEntity<Map<String, Object>> update(@RequestParam int id, @RequestParam int quantity, HttpSession session) {
        try { cart.change(session, id, quantity); return ResponseEntity.ok(snapshot(session, "Đã cập nhật giỏ hàng")); }
        catch (IllegalArgumentException | ArithmeticException ex) { return ResponseEntity.badRequest().body(snapshot(session, ex.getMessage())); }
    }
    private Map<String, Object> snapshot(HttpSession session, String message) {
        var lines = cart.items(session);
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("items", lines.stream().map(item -> Map.of("id", item.product().id(), "name", item.product().name(), "price", item.product().price(), "qty", item.quantity(), "stock", item.product().stock(), "subtotal", item.subtotal())).toList());
        response.put("count", lines.stream().mapToInt(item -> item.quantity()).sum());
        response.put("total", lines.stream().mapToLong(item -> item.subtotal()).reduce(0, Math::addExact));
        if (message != null) response.put("message", message);
        return response;
    }
}
