package com.example.mens_store.controller;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;
import com.example.mens_store.repository.ShopRepository;

@Controller
public class ShopController {
    private final ShopRepository shop;
    private final com.example.mens_store.repository.CommentRepository comments;

    public ShopController(ShopRepository shop, com.example.mens_store.repository.CommentRepository comments) {
        this.shop = shop;
        this.comments = comments;
    }

    @GetMapping("/")
    public String home(Model model, Authentication authentication) {
        model.addAttribute("sanPhams", shop.allActive());
        model.addAttribute("danhMucs", shop.categories());
        model.addAttribute("loggedIn", authentication != null && authentication.isAuthenticated()
            && authentication.getAuthorities().stream().anyMatch(a -> "ROLE_CUSTOMER".equals(a.getAuthority())));
        return "home.mens";
    }

    @GetMapping("/san-pham")
    public String products(@RequestParam(required = false, name = "danh_muc") Integer category,
                           @RequestParam(required = false, name = "q") String q,
                           @RequestParam(required = false, name = "sap_xep") String sort,
                           Model model) {
        if (q != null && q.length() > 100) q = q.substring(0, 100);
        model.addAttribute("products", shop.search(category, q, sort));
        model.addAttribute("selectedCategory", category);
        model.addAttribute("query", q == null ? "" : q);
        model.addAttribute("sort", sort == null ? "" : sort);
        return "products";
    }

    @GetMapping("/san-pham/{id}")
    public String detail(@PathVariable int id, Model model) {
        model.addAttribute("product", shop.activeById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND)));
        model.addAttribute("comments", comments.publicForProduct(id));
        return "detail";
    }

    @GetMapping("/dang-nhap")
    public String login() {
        return "login";
    }
}
