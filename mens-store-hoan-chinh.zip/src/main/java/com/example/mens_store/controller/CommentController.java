package com.example.mens_store.controller;

import com.example.mens_store.repository.CommentRepository;
import com.example.mens_store.repository.ShopRepository;
import com.example.mens_store.service.CartService;
import com.example.mens_store.service.AiAnalysisService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Set;

@Controller
public class CommentController {
    private final CommentRepository comments;
    private final ShopRepository products;
    private final CartService accounts;
    private final AiAnalysisService ai;
    private static final Set<String> STATES=Set.of("CHO_DUYET","HIEN_THI","SPAM","AN");
    public CommentController(CommentRepository comments,ShopRepository products,CartService accounts,AiAnalysisService ai) { this.comments=comments;this.products=products;this.accounts=accounts;this.ai=ai; }
    @PostMapping("/san-pham/{id}/binh-luan")
    public String add(@PathVariable int id,@RequestParam String content,RedirectAttributes flash) {
        try {
            long owner=accounts.requireAccountId();
            if(products.activeById(id).isEmpty()) throw new IllegalArgumentException("Sản phẩm không tồn tại");
            content=validContent(content);
            if(comments.recent(owner,LocalDateTime.now(ZoneId.of("Asia/Ho_Chi_Minh")).minusMinutes(1))>=3) throw new IllegalArgumentException("Bạn vui lòng đợi một phút trước khi gửi thêm bình luận");
            comments.create(owner,id,content);
            flash.addFlashAttribute("message","Đã gửi bình luận. Cửa hàng sẽ kiểm duyệt trước khi hiển thị.");
        } catch(IllegalArgumentException ex) { flash.addFlashAttribute("error",ex.getMessage()); }
        return "redirect:/san-pham/"+id+"#binh-luan";
    }
    @GetMapping("/quan-tri/binh-luan")
    public String admin(Model m) { m.addAttribute("comments",comments.all());m.addAttribute("aiConfigured",ai.isConfigured());return "admin/comments"; }
    @PostMapping("/quan-tri/binh-luan/{id}/luu")
    public String edit(@PathVariable long id,@RequestParam String content,@RequestParam String status,RedirectAttributes flash) {
        try {
            if(!STATES.contains(status)) throw new IllegalArgumentException("Trạng thái không hợp lệ");
            comments.edit(id,validContent(content),status);
            flash.addFlashAttribute("message","Đã lưu bình luận");
        } catch(IllegalArgumentException ex) { flash.addFlashAttribute("error",ex.getMessage()); }
        return "redirect:/quan-tri/binh-luan";
    }
    @PostMapping("/quan-tri/binh-luan/{id}/xoa")
    public String hide(@PathVariable long id,RedirectAttributes flash) {
        try {
            comments.status(id,"AN");flash.addFlashAttribute("message","Đã ẩn bình luận");
        } catch(IllegalArgumentException ex) { flash.addFlashAttribute("error",ex.getMessage()); }
        return "redirect:/quan-tri/binh-luan";
    }
    @PostMapping("/quan-tri/binh-luan/{id}/ai")
    public String ai(@PathVariable long id,RedirectAttributes flash) {
        try {
            var comment=comments.find(id).orElseThrow(()->new IllegalArgumentException("Không tìm thấy bình luận"));
            var decision=ai.classifyComment(comment.content());
            boolean hidden=decision.spam() && decision.confidence()>=0.9;
            if(hidden) comments.status(id,"SPAM");
            flash.addFlashAttribute("message",(hidden?"Đã ẩn dưới trạng thái SPAM. ":"Giữ nguyên để bạn xem xét. ")+decision.reason());
        } catch(IllegalArgumentException|IllegalStateException ex) { flash.addFlashAttribute("error",ex.getMessage()); }
        return "redirect:/quan-tri/binh-luan";
    }
    private String validContent(String content) {
        if(content==null || content.isBlank() || content.length()>1000) throw new IllegalArgumentException("Bình luận cần có từ 1 đến 1000 ký tự");
        return content.trim();
    }
}
