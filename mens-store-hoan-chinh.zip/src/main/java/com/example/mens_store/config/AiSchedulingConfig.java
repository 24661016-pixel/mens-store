package com.example.mens_store.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Kích hoạt bộ lập lịch báo cáo kinh doanh MENS STORE; lịch cụ thể mặc định tắt. */
@Configuration
@EnableScheduling
public class AiSchedulingConfig {}
