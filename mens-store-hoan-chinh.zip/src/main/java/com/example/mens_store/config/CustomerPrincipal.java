package com.example.mens_store.config;

import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import com.example.mens_store.model.CustomerAccount;

/** Phiên đăng nhập của khách MENS STORE, liên kết giỏ hàng và đơn mua với tài khoản. */
public final class CustomerPrincipal extends User {
    private static final long serialVersionUID = 1L;
    private final long accountId;
    private final int passwordVersion;

    public CustomerPrincipal(CustomerAccount account) {
        super(account.phone(), account.passwordHash(), account.active(), true, true, true,
            AuthorityUtils.createAuthorityList("ROLE_CUSTOMER"));
        this.accountId = account.id();
        this.passwordVersion = account.passwordVersion();
    }

    public long accountId() { return accountId; }
    public int passwordVersion() { return passwordVersion; }
}
