package com.example.mens_store.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.AuthorizationFilter;
import com.example.mens_store.repository.CustomerAccountRepository;
import com.example.mens_store.service.CustomerAccountService;

/** Cấu hình đăng nhập và phân quyền cho khách mua quần áo và quản trị MENS STORE. */
@Configuration
public class SecurityConfig {
    @Bean
    PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(); }

    @Bean
    UserDetailsService userDetailsService(
            @Value("${shop.admin.username}") String adminUsername,
            @Value("${shop.admin.password}") String adminPassword,
            PasswordEncoder encoder, CustomerAccountService customers) {
        if (adminUsername.isBlank() || adminPassword.isBlank())
            throw new IllegalStateException("Hãy cấu hình APP_ADMIN_USERNAME và APP_ADMIN_PASSWORD trước khi khởi động MENS STORE");
        String adminHash = encoder.encode(adminPassword);
        return username -> {
            if (adminUsername.equals(username))
                return User.withUsername(adminUsername).password(adminHash).roles("ADMIN").build();
            return customers.findByPhone(username).map(CustomerPrincipal::new)
                .orElseThrow(() -> new UsernameNotFoundException("Không tìm thấy tài khoản"));
        };
    }

    @Bean
    SecurityFilterChain filterChain(HttpSecurity http, CustomerAccountRepository accounts) throws Exception {
        return http.authorizeHttpRequests(auth -> auth
                    .requestMatchers("/quan-tri", "/quan-tri/**").hasRole("ADMIN")
                    .requestMatchers("/tai-khoan/dang-nhap", "/tai-khoan/dang-ky", "/dang-ky",
                        "/tai-khoan/quen-mat-khau", "/tai-khoan/dat-lai-mat-khau").permitAll()
                    .requestMatchers("/tai-khoan", "/tai-khoan/**", "/gio-hang", "/gio-hang/**",
                        "/api/gio-hang", "/api/gio-hang/**", "/dat-hang", "/dat-hang/**",
                        "/tro-ly", "/tro-ly/**").hasRole("CUSTOMER")
                    .requestMatchers(org.springframework.http.HttpMethod.POST, "/san-pham/*/binh-luan").hasRole("CUSTOMER")
                    .anyRequest().permitAll())
                .exceptionHandling(exceptions -> exceptions
                    .authenticationEntryPoint((request, response, exception) -> {
                        String path = request.getRequestURI().substring(request.getContextPath().length());
                        if (path.startsWith("/api/")) {
                            response.setStatus(401);
                            response.setContentType("application/json;charset=UTF-8");
                            response.getWriter().write("{\"error\":\"Vui lòng đăng nhập để sử dụng giỏ hàng.\"}");
                        } else response.sendRedirect(request.getContextPath() +
                            (path.startsWith("/quan-tri") ? "/dang-nhap" : "/tai-khoan/dang-nhap"));
                    }))
                .formLogin(login -> login.loginPage("/dang-nhap")
                    .loginProcessingUrl("/dang-nhap")
                    .usernameParameter("soDienThoai").passwordParameter("matKhau")
                    .successHandler((request, response, authentication) -> {
                        var session = request.getSession(false);
                        if (session != null) session.removeAttribute("CART");
                        boolean admin = authentication.getAuthorities().stream()
                            .anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
                        response.sendRedirect(request.getContextPath() + (admin ? "/quan-tri" : "/tai-khoan"));
                    })
                    .failureHandler((request, response, exception) -> {
                        boolean customer = "customer".equals(request.getParameter("loginType"));
                        response.sendRedirect(request.getContextPath() +
                            (customer ? "/?error" : "/dang-nhap?error"));
                    }).permitAll())
                .logout(logout -> logout.logoutUrl("/dang-xuat")
                    .invalidateHttpSession(true).clearAuthentication(true).deleteCookies("JSESSIONID")
                    .logoutSuccessUrl("/?logout").permitAll())
                .addFilterBefore(new CustomerSessionFilter(accounts), AuthorizationFilter.class)
                .build();
    }
}
