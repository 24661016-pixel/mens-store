package com.example.mens_store.config;

import com.example.mens_store.repository.CustomerAccountRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;

/** Bảo vệ hồ sơ, giỏ và đơn MENS STORE khi mật khẩu, trạng thái hoặc số đăng nhập thay đổi. */
public final class CustomerSessionFilter extends OncePerRequestFilter {
    private final CustomerAccountRepository accounts;
    public CustomerSessionFilter(CustomerAccountRepository accounts) { this.accounts = accounts; }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI().substring(request.getContextPath().length());
        return path.startsWith("/assets/") || path.startsWith("/images/") || path.startsWith("/uploads/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        var authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof CustomerPrincipal principal) {
            boolean valid = accounts.authState(principal.accountId()).map(state ->
                state.active() && state.passwordVersion() == principal.passwordVersion()
                    && state.phone().equals(principal.getUsername())).orElse(false);
            if (!valid) {
                SecurityContextHolder.clearContext();
                var session = request.getSession(false);
                if (session != null) session.invalidate();
                if (request.getRequestURI().substring(request.getContextPath().length()).startsWith("/api/")) {
                    response.setStatus(401);
                    response.setContentType("application/json;charset=UTF-8");
                    response.getWriter().write("{\"error\":\"Phiên đăng nhập đã hết hiệu lực. Vui lòng đăng nhập lại.\"}");
                } else response.sendRedirect(request.getContextPath() + "/tai-khoan/dang-nhap?expired");
                return;
            }
        }
        chain.doFilter(request, response);
    }
}
