package com.example.mens_store.model;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ValidBirthdayValidator.class)
public @interface ValidBirthday {
    String message() default "Ngày sinh phải từ 01/01/1900 đến hôm nay";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
