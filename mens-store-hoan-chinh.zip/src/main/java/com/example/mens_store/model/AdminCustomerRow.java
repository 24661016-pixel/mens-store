package com.example.mens_store.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
/** Customer profile data shown to administrators; never includes password hashes. */
public record AdminCustomerRow(long id, String fullName, String email, String phone,
                               String address, LocalDate birthDate, boolean active, LocalDateTime createdAt) {}
