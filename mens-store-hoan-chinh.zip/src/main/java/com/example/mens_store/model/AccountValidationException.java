package com.example.mens_store.model;

public class AccountValidationException extends IllegalArgumentException {
    private final String field;
    public AccountValidationException(String field, String message) {
        super(message);
        this.field = field;
    }
    public String field() { return field; }
}
