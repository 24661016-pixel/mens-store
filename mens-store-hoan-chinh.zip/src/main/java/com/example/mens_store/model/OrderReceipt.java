package com.example.mens_store.model;

public record OrderReceipt(
    String code,
    long total,
    String paymentMethod
) {}