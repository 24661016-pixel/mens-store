package com.example.mens_store.model;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.time.LocalDate;
import java.time.ZoneId;

/** Optional birth dates must be representable in the database and plausible. */
public class ValidBirthdayValidator implements ConstraintValidator<ValidBirthday, LocalDate> {
    private static final LocalDate EARLIEST = LocalDate.of(1900, 1, 1);
    private static final ZoneId STORE_ZONE = ZoneId.of("Asia/Ho_Chi_Minh");

    @Override
    public boolean isValid(LocalDate value, ConstraintValidatorContext context) {
        if (value == null) return true;
        LocalDate today = LocalDate.now(context.getClockProvider().getClock().withZone(STORE_ZONE));
        return !value.isBefore(EARLIEST) && !value.isAfter(today);
    }
}
