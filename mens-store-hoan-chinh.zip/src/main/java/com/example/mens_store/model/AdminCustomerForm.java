package com.example.mens_store.model;

import jakarta.validation.constraints.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;
import java.util.Locale;
public class AdminCustomerForm {
    @NotBlank(message="Vui lòng nhập họ tên") @Size(min=2,max=100,message="Họ tên từ 2 đến 100 ký tự") private String fullName;
    @NotBlank(message="Vui lòng nhập email") @Email(message="Email không hợp lệ") @Size(max=150,message="Email tối đa 150 ký tự") private String email;
    @NotBlank(message="Vui lòng nhập số điện thoại") @Pattern(regexp="0[0-9]{9}",message="Số điện thoại gồm 10 chữ số, bắt đầu bằng 0") private String phone;
    @NotBlank(message="Vui lòng nhập địa chỉ") @Size(min=5,max=255,message="Địa chỉ từ 5 đến 255 ký tự") private String address;
    @ValidBirthday @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) private LocalDate birthDate;
    private boolean active=true;
    @Size(max=72,message="Mật khẩu tối đa 72 ký tự") private String password="";
    @Size(max=72,message="Xác nhận mật khẩu tối đa 72 ký tự") private String confirmPassword="";
    public String getFullName(){return fullName;}public void setFullName(String v){fullName=v==null?null:v.trim();}
    public String getEmail(){return email;}public void setEmail(String v){email=v==null?null:v.trim().toLowerCase(Locale.ROOT);}
    public String getPhone(){return phone;}public void setPhone(String v){phone=v==null?null:v.trim();}
    public String getAddress(){return address;}public void setAddress(String v){address=v==null?null:v.trim();}
    public LocalDate getBirthDate(){return birthDate;}public void setBirthDate(LocalDate v){birthDate=v;}
    public boolean isActive(){return active;}public void setActive(boolean v){active=v;}
    public String getPassword(){return password;}public void setPassword(String v){password=v;}
    public String getConfirmPassword(){return confirmPassword;}public void setConfirmPassword(String v){confirmPassword=v;}
}
