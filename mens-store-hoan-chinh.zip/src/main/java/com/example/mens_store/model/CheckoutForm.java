package com.example.mens_store.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class CheckoutForm {

    @NotBlank(message="Hãy nhập họ tên")
    @Size(min=2,max=100, message="Họ tên từ 2 đến 100 ký tự")
    @Pattern(regexp="^[\\p{L}\\p{M} .'-]+$", message="Họ tên chỉ gồm chữ và dấu phân cách tên hợp lệ")
    private String fullName;

    @NotBlank(message="Hãy nhập số điện thoại")
    @Pattern(regexp="^0[0-9]{9}$", message="Số điện thoại gồm 10 chữ số bắt đầu bằng 0")
    private String phone;

    @Email(message="Email không hợp lệ")
    @Size(max=150, message="Email tối đa 150 ký tự")
    private String email;

    @NotBlank(message="Hãy nhập địa chỉ giao hàng")
    @Size(min=5,max=255, message="Địa chỉ từ 5 đến 255 ký tự")
    private String address;

    @Size(max=500, message="Ghi chú tối đa 500 ký tự")
    private String note;

    // COD hoặc CHUYEN_KHOAN
    @NotBlank(message="Chọn phương thức thanh toán")
    @Pattern(regexp="COD|CHUYEN_KHOAN", message="Phương thức thanh toán không hợp lệ")
    private String paymentMethod = "COD";

    public String getFullName(){return fullName;}
    public void setFullName(String v){fullName=trim(v);}

    public String getPhone(){return phone;}
    public void setPhone(String v){phone=trim(v);}

    public String getEmail(){return email;}
    public void setEmail(String v){email=trim(v);}

    public String getAddress(){return address;}
    public void setAddress(String v){address=trim(v);}

    public String getNote(){return note;}
    public void setNote(String v){note=trim(v);}

    public String getPaymentMethod(){return paymentMethod;}
    public void setPaymentMethod(String v){paymentMethod=v;}
    private static String trim(String v) { return v == null ? null : v.trim(); }
}