package com.example.mens_store.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;

public class RegistrationForm {
    @NotBlank(message = "Vui lòng nhập họ tên")
    @Size(min = 2, max = 100, message = "Họ tên từ 2 đến 100 ký tự")
    @Pattern(regexp = "^[\\p{L}\\p{M} .'-]+$", message = "Họ tên chỉ gồm chữ, dấu cách, dấu chấm, dấu nháy hoặc gạch nối")
    private String fullName;

    @NotBlank(message = "Vui lòng nhập email")
    @Email(message = "Email không đúng định dạng")
    @Size(max = 150, message = "Email tối đa 150 ký tự")
    private String email;

    @NotBlank(message = "Vui lòng nhập số điện thoại")
    @Pattern(regexp = "^0[0-9]{9}$", message = "Số điện thoại gồm 10 chữ số và bắt đầu bằng 0")
    private String phone;

    @NotBlank(message = "Vui lòng nhập địa chỉ")
    @Size(min = 5, max = 255, message = "Địa chỉ từ 5 đến 255 ký tự")
    private String address;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @ValidBirthday
    private LocalDate birthday;

    @StrongPassword
    private String password;

    @NotBlank(message = "Vui lòng xác nhận mật khẩu")
    @Size(max = 72, message = "Mật khẩu xác nhận tối đa 72 ký tự")
    private String confirmPassword;

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = trim(fullName); }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = trim(email); }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = trim(phone); }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = trim(address); }
    public LocalDate getBirthday() { return birthday; }
    public void setBirthday(LocalDate birthday) { this.birthday = birthday; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getConfirmPassword() { return confirmPassword; }
    public void setConfirmPassword(String confirmPassword) { this.confirmPassword = confirmPassword; }
    private static String trim(String value) { return value == null ? null : value.trim(); }
}
