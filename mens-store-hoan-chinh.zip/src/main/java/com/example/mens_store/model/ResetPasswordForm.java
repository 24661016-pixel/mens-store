package com.example.mens_store.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class ResetPasswordForm {
    @NotBlank(message = "Liên kết không hợp lệ")
    @Pattern(regexp = "^[A-Za-z0-9_-]{43}$", message = "Liên kết không hợp lệ")
    private String token;
    @StrongPassword
    private String password;
    @NotBlank(message = "Vui lòng xác nhận mật khẩu")
    @Size(max = 72, message = "Mật khẩu xác nhận tối đa 72 ký tự")
    private String confirmPassword;
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getConfirmPassword() { return confirmPassword; }
    public void setConfirmPassword(String confirmPassword) { this.confirmPassword = confirmPassword; }
}
