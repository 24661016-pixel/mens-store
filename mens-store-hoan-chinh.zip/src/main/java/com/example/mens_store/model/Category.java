package com.example.mens_store.model;

public record Category(int id, String code, String name, String description) {}
