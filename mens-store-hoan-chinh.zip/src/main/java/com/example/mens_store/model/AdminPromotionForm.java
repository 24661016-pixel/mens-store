package com.example.mens_store.model;

import jakarta.validation.constraints.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;
import java.util.Locale;
public class AdminPromotionForm {
    @NotBlank(message="Vui lòng nhập mã chiến dịch") @Pattern(regexp="[A-Z0-9_-]{2,30}",message="Mã gồm 2–30 chữ, số, gạch ngang hoặc gạch dưới") private String code;
    @NotBlank(message="Vui lòng nhập tên chiến dịch") @Size(max=120,message="Tên tối đa 120 ký tự") private String name;
    @Min(value=1,message="Mức giảm tối thiểu 1%") @Max(value=80,message="Mức giảm tối đa 80%") private int percentage=10;
    @NotNull(message="Chọn ngày bắt đầu") @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) private LocalDate starts;
    @NotNull(message="Chọn ngày kết thúc") @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) private LocalDate ends;
    private boolean active=true;
    public String getCode(){return code;}public void setCode(String v){code=v==null?null:v.trim().toUpperCase(Locale.ROOT);}
    public String getName(){return name;}public void setName(String v){name=v==null?null:v.trim();}
    public int getPercentage(){return percentage;}public void setPercentage(int v){percentage=v;}
    public LocalDate getStarts(){return starts;}public void setStarts(LocalDate v){starts=v;}
    public LocalDate getEnds(){return ends;}public void setEnds(LocalDate v){ends=v;}
    public boolean isActive(){return active;}public void setActive(boolean v){active=v;}
}
