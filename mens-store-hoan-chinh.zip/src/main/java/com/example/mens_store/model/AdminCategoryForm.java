package com.example.mens_store.model;

import jakarta.validation.constraints.*;
public class AdminCategoryForm {
    @NotBlank(message="Vui lòng nhập mã danh mục")
    @Pattern(regexp="[A-Za-z0-9_-]{2,30}",message="Mã gồm 2–30 chữ, số, dấu gạch ngang hoặc gạch dưới")
    private String code;
    @NotBlank(message="Vui lòng nhập tên danh mục")
    @Size(max=100,message="Tên tối đa 100 ký tự") private String name;
    @Size(max=255,message="Mô tả tối đa 255 ký tự") private String description;
    @Min(value=0,message="Thứ tự phải từ 0") @Max(value=10000,message="Thứ tự tối đa 10000") private int sort;
    private boolean active=true;
    public String getCode(){return code;} public void setCode(String v){code=v==null?null:v.trim();}
    public String getName(){return name;} public void setName(String v){name=v==null?null:v.trim();}
    public String getDescription(){return description;} public void setDescription(String v){description=v==null?null:v.trim();}
    public int getSort(){return sort;} public void setSort(int v){sort=v;}
    public boolean isActive(){return active;} public void setActive(boolean v){active=v;}
}
