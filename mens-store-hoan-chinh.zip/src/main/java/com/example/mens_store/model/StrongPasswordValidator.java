package com.example.mens_store.model;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.nio.charset.StandardCharsets;

public class StrongPasswordValidator implements ConstraintValidator<StrongPassword, String> {
    @Override
    public boolean isValid(String password, ConstraintValidatorContext context) {
        return isStrong(password);
    }

    public static boolean isStrong(String password) {
        if (password == null || password.codePointCount(0, password.length()) < 8
                || password.getBytes(StandardCharsets.UTF_8).length > 72) return false;
        boolean upper = false, lower = false, digit = false, special = false;
        for (int cp : password.codePoints().toArray()) {
            if (Character.isWhitespace(cp) || Character.isISOControl(cp)) return false;
            upper |= Character.isUpperCase(cp);
            lower |= Character.isLowerCase(cp);
            digit |= Character.isDigit(cp);
            special |= !Character.isLetterOrDigit(cp);
        }
        return upper && lower && digit && special;
    }
}
