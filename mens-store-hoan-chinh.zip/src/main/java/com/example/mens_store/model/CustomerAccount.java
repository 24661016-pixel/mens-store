package com.example.mens_store.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record CustomerAccount(
        long id,
        String fullName,
        String email,
        String phone,
        String passwordHash,
        boolean active,
        LocalDateTime createdAt,
        String address,
        LocalDate birthday,
        int passwordVersion) {
}
