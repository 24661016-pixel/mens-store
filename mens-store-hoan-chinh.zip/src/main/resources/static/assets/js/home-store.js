
document.addEventListener('DOMContentLoaded', function () {
    let loggedIn = document.body.dataset.customer === 'true';
    // Remove the old shared cart; account carts now come only from the server.
    try { localStorage.removeItem('mensStoreCartV2'); } catch (_) {}
    const WISHLIST_KEY = 'mensStoreWishlistV2';

    const cartBadge = document.getElementById('cartCountBadge');
    const cartItemsList = document.getElementById('cartItemsList');
    const totalNode = document.getElementById('cartTotalPrice');
    const money = new Intl.NumberFormat('vi-VN');

    let cart = [];
    let wishlist = [];
    let favoritesOnly = false;
    let selectedCategory = '';
    let toastTimer = null;
    let cartQueue = Promise.resolve();

    try {
        const savedWishlist = JSON.parse(localStorage.getItem(WISHLIST_KEY) || '[]');
        if (Array.isArray(savedWishlist)) wishlist = savedWishlist.map(String);
    } catch (error) {
        wishlist = [];
    }

    function safe(value) {
        return String(value).replace(/[&<>"']/g, char => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[char]));
    }

    function notify(message) {
        const toast = document.getElementById('cartToast');
        const messageNode = document.getElementById('toastMessage');

        if (messageNode) messageNode.textContent = message;

        if (window.bootstrap && window.bootstrap.Toast && toast) {
            window.bootstrap.Toast.getOrCreateInstance(toast, {delay: 2200}).show();
            return;
        }

        if (toast) {
            toast.classList.add('show');
            toast.style.display = 'block';
            window.clearTimeout(toastTimer);
            toastTimer = window.setTimeout(() => {
                toast.classList.remove('show');
                toast.style.display = '';
            }, 2200);
        }
    }

    function applyCart(data) {
        cart = Array.isArray(data.items) ? data.items : [];
        updateCart();
    }
    function requestLogin() {
        cart = [];
        updateCart();
        document.getElementById('openAccountModal')?.click();
        notify('Vui lòng đăng nhập để sử dụng giỏ hàng của bạn.');
    }
    async function refreshCart() {
        if (!loggedIn) { updateCart(); return; }
        try {
            const response = await fetch('/api/gio-hang', {credentials: 'same-origin', cache: 'no-store'});
            if (response.status === 401 || response.status === 403) { loggedIn = false; requestLogin(); return; }
            if (!response.ok) throw new Error();
            applyCart(await response.json());
        } catch (_) { notify('Không tải được giỏ hàng. Vui lòng tải lại trang.'); }
    }
    function mutateCart(path, id, quantity) {
        if (!loggedIn) { requestLogin(); return; }
        cartQueue = cartQueue.then(async () => {
            try {
                const token = document.querySelector('meta[name="_csrf"]')?.content;
                const header = document.querySelector('meta[name="_csrf_header"]')?.content || 'X-CSRF-TOKEN';
                const response = await fetch('/api/gio-hang/' + path, {
                    method: 'POST', credentials: 'same-origin',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', [header]: token},
                    body: new URLSearchParams({id: String(id), quantity: String(quantity)})
                });
                if (response.status === 401 || response.status === 403) { loggedIn = false; requestLogin(); return; }
                const data = await response.json();
                applyCart(data);
                notify(data.message || (response.ok ? 'Đã cập nhật giỏ hàng.' : 'Không thể cập nhật giỏ hàng.'));
            } catch (_) { notify('Không thể cập nhật giỏ hàng. Vui lòng thử lại.'); }
        });
    }

    function updateCart() {
        const quantity = cart.reduce((sum, item) => sum + Number(item.qty), 0);
        const total = cart.reduce((sum, item) =>
            sum + Number(item.price) * Number(item.qty), 0);

        if (cartBadge) cartBadge.textContent = quantity;
        if (totalNode) totalNode.textContent = money.format(total) + ' đ';

        if (!cartItemsList) {
            return;
        }

        if (!cart.length) {
            cartItemsList.innerHTML =
                loggedIn ? '<p class="text-center text-secondary py-5">Giỏ hàng MENS STORE đang trống. Chọn một chiếc áo hoặc món đồ bạn yêu thích để bắt đầu.</p>' : '<p class="text-center text-secondary py-5">Đăng nhập MENS STORE để tiếp tục chọn trang phục trong giỏ riêng của bạn.</p><a class="btn btn-dark w-100" href="/tai-khoan/dang-nhap">Đăng nhập</a>';
        } else {
            cartItemsList.innerHTML = cart.map((item, index) => `
                <div class="d-flex justify-content-between align-items-start gap-3 border-bottom py-3">
                    <div class="flex-grow-1">
                        <div class="fw-semibold mb-1">${safe(item.name)}</div>
                        <div class="small text-secondary">${money.format(Number(item.price))} đ / sản phẩm</div>
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <button class="btn btn-sm btn-outline-secondary"
                                    data-cart-action="minus" data-index="${index}" type="button">−</button>
                            <span class="small fw-bold">${Number(item.qty)}</span>
                            <button class="btn btn-sm btn-outline-secondary"
                                    data-cart-action="plus" data-index="${index}" type="button">+</button>
                        </div>
                    </div>
                    <div class="text-end">
                        <strong class="small">${money.format(Number(item.price) * Number(item.qty))} đ</strong>
                        <button class="btn btn-sm text-danger d-block ms-auto mt-2"
                                data-cart-action="remove" data-index="${index}" type="button">Xóa</button>
                    </div>
                </div>
            `).join('');
        }


    }

    document.querySelectorAll('.btn-add-cart').forEach(button => {
        button.addEventListener('click', () => mutateCart('them', button.dataset.id, 1));
    });
    cartItemsList?.addEventListener('click', event => {
        const button = event.target.closest('[data-cart-action]');
        if (!button) return;
        const item = cart[Number(button.dataset.index)];
        if (!item) return;
        const quantity = button.dataset.cartAction === 'remove' ? 0 : Number(item.qty) + (button.dataset.cartAction === 'plus' ? 1 : -1);
        mutateCart('cap-nhat', item.id, quantity);
    });

    function updateWishlist() {
        document.querySelectorAll('.wishlist-toggle').forEach(button => {
            const active = wishlist.includes(String(button.dataset.wishlistId));

            button.classList.toggle('active', active);
            button.setAttribute('aria-pressed', String(active));
            button.innerHTML = active
                ? '<i class="bi bi-heart-fill"></i>'
                : '<i class="bi bi-heart"></i>';
        });

        const count = document.getElementById('wishlistCount');
        const filterButton = document.getElementById('favoritesFilter');

        if (count) count.textContent = wishlist.length;
        if (filterButton) {
            filterButton.classList.toggle('active', favoritesOnly);
            filterButton.setAttribute('aria-pressed', String(favoritesOnly));
        }
    }

    document.querySelectorAll('.wishlist-toggle').forEach(button => {
        button.addEventListener('click', () => {
            const id = String(button.dataset.wishlistId);
            const name = button.dataset.wishlistName || 'Sản phẩm';

            wishlist = wishlist.includes(id)
                ? wishlist.filter(value => value !== id)
                : [...wishlist, id];

            try {
                localStorage.setItem(WISHLIST_KEY, JSON.stringify(wishlist));
            } catch (error) {}

            updateWishlist();
            filterProducts();

            notify(wishlist.includes(id)
                ? 'Đã lưu ' + name + ' vào yêu thích.'
                : 'Đã bỏ ' + name + ' khỏi yêu thích.');
        });
    });

    document.querySelectorAll('#productGrid .product-card').forEach((card,index) => card.dataset.originalIndex = String(index));

    function searchable(value) {
        return String(value).toLocaleLowerCase('vi').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd');
    }

    function filterProducts() {
        const grid = document.getElementById('productGrid');
        if (!grid) return;

        const query = searchable((document.getElementById('productSearch')?.value || '').trim());

        const cards = [...grid.querySelectorAll('.product-card')];

        cards.forEach(card => {
            const name = searchable(card.dataset.name || '');
            const id = String(card.dataset.productId || '');

            const textMatch = !query || name.includes(query);
            const categoryMatch = !selectedCategory ||
                String(card.dataset.categoryId || '') === selectedCategory;
            const favoriteMatch = !favoritesOnly || wishlist.includes(id);

            card.hidden = !(textMatch && categoryMatch && favoriteMatch);
        });

        const visible = cards.filter(card => !card.hidden);
        const resultCount = document.getElementById('productResultCount');
        if (resultCount) resultCount.textContent = visible.length + ' sản phẩm';
        const mode = document.getElementById('sortProducts')?.value || 'default';

        visible.sort((a, b) => {
            if (mode === 'price-asc') {
                return Number(a.dataset.price || 0) - Number(b.dataset.price || 0);
            }
            if (mode === 'price-desc') {
                return Number(b.dataset.price || 0) - Number(a.dataset.price || 0);
            }
            if (mode === 'name') {
                return (a.dataset.name || '').localeCompare(b.dataset.name || '', 'vi');
            }
            return Number(a.dataset.originalIndex) - Number(b.dataset.originalIndex);
        }).forEach(card => grid.appendChild(card));

        const empty = document.getElementById('searchEmpty');
        if (empty) empty.hidden = visible.length > 0;
    }

    document.getElementById('productSearch')?.addEventListener('input', filterProducts);
    document.getElementById('sortProducts')?.addEventListener('change', filterProducts);

    document.querySelectorAll('[data-search-category]').forEach(link => {
        link.addEventListener('click', () => {
            selectedCategory = link.dataset.searchCategory || '';

            const search = document.getElementById('productSearch');
            if (search) search.value = '';

            favoritesOnly = false;
            updateWishlist();
            filterProducts();
        });
    });

    document.getElementById('favoritesFilter')?.addEventListener('click', () => {
        favoritesOnly = !favoritesOnly;
        updateWishlist();
        filterProducts();
        document.getElementById('product-list')?.scrollIntoView({behavior: 'smooth'});
    });

    document.getElementById('checkoutButton')?.addEventListener('click', async () => {
        if (!loggedIn) { requestLogin(); return; }
        await cartQueue;
        if (!cart.length) { notify('Vui lòng thêm sản phẩm trước khi đặt hàng.'); return; }
        window.location.href = '/dat-hang';
    });

    // Fallback giỏ hàng nếu Bootstrap JS không hoạt động.
    const cartPanel = document.getElementById('cartOffcanvas');
    const cartOpenButton = document.getElementById('openCartButton');
    let cartBackdrop = null;

    function closeCartFallback() {
        if (!cartPanel) return;

        cartPanel.classList.remove('fallback-open');
        cartPanel.classList.add('fallback-closed');
        cartPanel.removeAttribute('aria-modal');
        cartPanel.setAttribute('aria-hidden', 'true');

        cartBackdrop?.remove();
        cartBackdrop = null;

        if (!document.querySelector('#accountModal.show')) {
            document.body.classList.remove('modal-open');
        }
    }

    function openCartFallback() {
        if (!cartPanel) return;

        cartPanel.classList.add('fallback-open');
        cartPanel.classList.remove('fallback-closed');
        cartPanel.setAttribute('aria-modal', 'true');
        cartPanel.removeAttribute('aria-hidden');
        document.body.classList.add('modal-open');

        cartBackdrop = document.createElement('div');
        cartBackdrop.className = 'cart-fallback-backdrop';
        cartBackdrop.addEventListener('click', closeCartFallback);
        document.body.appendChild(cartBackdrop);
    }

    if (!window.bootstrap || !window.bootstrap.Offcanvas) {
        cartPanel?.classList.add('fallback-closed');
        cartPanel?.setAttribute('aria-hidden', 'true');

        cartOpenButton?.addEventListener('click', openCartFallback);

        cartPanel?.querySelectorAll('[data-bs-dismiss="offcanvas"]').forEach(button => {
            button.addEventListener('click', closeCartFallback);
        });
    }

    updateCart();
    refreshCart();
    updateWishlist();
    filterProducts();
    // Reload after back/forward navigation so a logged-out page cannot show another account's cart.
    window.addEventListener('pageshow', event => { if (event.persisted) window.location.reload(); });

    // Fallback menu responsive khi Bootstrap không tải được.
    if (!window.bootstrap || !window.bootstrap.Collapse) {
        const toggle = document.querySelector('[data-bs-target="#mainNavbar"]');
        const menu = document.getElementById('mainNavbar');

        toggle?.addEventListener('click', () => {
            const expanded = menu.classList.toggle('show');
            toggle.setAttribute('aria-expanded', String(expanded));
        });
    }
});
