# MENS STORE — Giao diện mới và bộ ảnh sản phẩm

Bản cập nhật dành cho phiên bản đăng nhập bằng email/Gmail đã cung cấp trước đó.

## Cài vào dự án đang chạy trong Codespaces

1. Tải ZIP `mens-store-cap-nhat-giao-dien.zip` vào thư mục chứa `pom.xml`.
2. Trong Terminal chạy:

```bash
cd /workspaces/mens-store/mens-store
cp -a src/main/resources /tmp/mens-store-resources-backup-$(date +%Y%m%d-%H%M%S)
unzip -o mens-store-cap-nhat-giao-dien.zip
docker compose up -d --build web
docker compose logs -f web
```

3. Khi có dòng `Started MensStoreApplication`, tải lại website bằng Ctrl + F5.

Không chạy `docker compose down -v`, không xóa cơ sở dữ liệu, không nhập lại SQL.

## Nội dung cập nhật

- Banner, menu, danh mục bằng ảnh, thẻ sản phẩm và bố cục điện thoại.
- 20 ảnh minh họa AI được tạo theo tên, màu sắc, kiểu dáng của 20 sản phẩm mẫu SP001–SP020.
- Ảnh JPEG nhúng trong các SVG cũ (sp1.svg đến sp20.svg), giữ đúng đường dẫn SQL hiện tại, không tải ảnh từ internet. Ảnh mang tính minh họa, không phải ảnh chụp hàng thực tế.
- Cập nhật CSS danh sách và trang chi tiết; không sửa Java, cấu hình Docker, SQL hoặc JavaScript hiện tại. Đăng nhập Gmail được giữ nguyên.
- Đã kiểm tra preview tĩnh trên Chromium 1440px và 390px, 20/20 ảnh tải được; tìm kiếm, sắp xếp, yêu thích, mở form email hoạt động trên preview. Chưa chạy ứng dụng Spring Boot/MySQL trong Codespaces của bạn.

Nếu bạn có thay đổi riêng trong home.mens.html hoặc style.css, sao lưu trước khi giải nén ghi đè. Nếu bạn đã đổi tên ảnh sản phẩm trong MySQL, ảnh mới chỉ áp dụng tự động cho các đường dẫn mẫu tương ứng.
