#!/usr/bin/env python3
"""Upgrade stock display and quantity selection without resetting the database."""
from pathlib import Path
import sys, re, shutil, tempfile, os

root = Path(sys.argv[1] if len(sys.argv) > 1 else '/workspaces/mens-store/mens-store').resolve()
if not (root/'pom.xml').is_file() or not (root/'compose.yaml').is_file():
    raise SystemExit('Khong tim thay du an: ' + str(root))
T = 'src/main/resources/templates/'
A = 'src/main/resources/static/assets/'
J = 'src/main/java/com/example/mens_store/'
pending = {}

def read(path):
    return pending[path] if path in pending else (root/path).read_text(encoding='utf-8')

def replace(path, old, new):
    s = read(path)
    if new in s:
        return
    if s.count(old) != 1:
        raise SystemExit('Khong khop phien ban: ' + path + '. Chua ghi file nao.')
    pending[path] = s.replace(old, new, 1)

def add(path, content):
    if (root/path).exists():
        if read(path) != content:
            raise SystemExit('File da ton tai voi noi dung khac: ' + path)
    else:
        pending[path] = content

def stock_badge(tag, stock, extra_class='', condition=''):
    return ('<' + tag + ' class="ms-stock' + (' '+extra_class if extra_class else '') + '"'
            + (' th:if="${'+condition+'}"' if condition else '')
            + ' th:classappend="${'+stock+" <= 0 ? 'ms-stock-out' : ("+stock+" <= 10 ? 'ms-stock-low' : 'ms-stock-ok')}\""
            + ' th:text="${'+stock+" <= 0 ? 'Hết hàng' : ("+stock+" <= 10 ? 'Sắp hết – chỉ còn ' + "+stock+" + ' sản phẩm' : 'Còn ' + "+stock+" + ' sản phẩm trong kho')}\">Tồn kho</"+tag+'>')

p = T+'detail.html'
replace(p, '''    <p th:class="${product.stock() > 0 ? 'stock-ok' : 'stock-no'}"
       th:text="${product.stock() > 0 ? 'Còn ' + product.stock() + ' sản phẩm' : 'Mẫu này hiện đã hết hàng'}"></p>''', '    '+stock_badge('p','product.stock()','ms-stock-detail'))
s = read(p)
if 'id="msPurchaseQuantity"' not in s:
    pattern = r'<label>Số lượng\s*<input\b[^>]*\bname="quantity"[^>]*>\s*</label>'
    matches = list(re.finditer(pattern,s))
    if len(matches) != 1:
        raise SystemExit('Khong tim thay dung mot o so luong trong '+p+'. Chua ghi file nao.')
    # Both add-to-cart and direct-buy submit buttons continue using the same form and field.
    new = '''<div class="ms-quantity" th:attr="data-unit-price=${product.price()}">
          <label for="msPurchaseQuantity">Số lượng mua</label>
          <div class="ms-quantity-control">
            <button type="button" class="ms-step" data-step="-1" aria-label="Giảm số lượng" disabled>−</button>
            <input id="msPurchaseQuantity" type="number" name="quantity" class="input" min="1" step="1"
                   th:max="${T(java.lang.Math).min(99, product.stock())}" th:value="${product.stock() > 0 ? 1 : 0}"
                   required th:disabled="${product.stock() <= 0}">
            <button type="button" class="ms-step" data-step="1" aria-label="Tăng số lượng" th:disabled="${product.stock() <= 1}">+</button>
          </div>
          <small class="ms-quantity-help" th:text="${product.stock() <= 0 ? 'Hiện không thể mua sản phẩm này.' : 'Tối đa ' + T(java.lang.Math).min(99, product.stock()) + ' sản phẩm mỗi lần mua.'}">Giới hạn số lượng</small>
          <div class="ms-subtotal"><span>Tạm tính</span><strong id="msPurchaseSubtotal" aria-live="polite" th:text="${#numbers.formatInteger(product.stock() > 0 ? product.price() : 0,1,'POINT') + ' ₫'}">0 ₫</strong></div>
          <p class="ms-quantity-error" id="msQuantityError" role="status" hidden></p>
        </div>'''
    pending[p] = s[:matches[0].start()]+new+s[matches[0].end():]
replace(p,'</body>','<script th:src="@{/assets/js/stock-quantity.js}" defer></script>\n</body>')

p = T+'home.mens.html'
badge = stock_badge('span','sp.stock()','stock-label')
if badge not in read(p):
    if 'class="stock-label"' in read(p):
        replace(p,'''<span class="stock-label" th:classappend="${sp.stock() == 0 ? 'out-of-stock' : ''}" th:text="${sp.stock() > 0 ? 'Còn hàng' : 'Hết hàng'}">Còn hàng</span>''',badge)
    else:
        anchor = "th:text=\"${#numbers.formatInteger(sp.price(), 1, 'POINT')} + ' ₫'\">0 đ</span>"
        replace(p,anchor,anchor+'\n                        '+badge)
replace(p,'</head>','    <link rel="stylesheet" th:href="@{/assets/css/stock-display.css}">\n</head>')

p = T+'fragments.html'
replace(p,'''<small th:text="${p.stock() > 0 ? 'Còn ' + p.stock() + ' sản phẩm' : 'Tạm hết hàng'}">Tình trạng hàng</small>''',stock_badge('small','p.stock()'))
replace(p,'</head>','    <link rel="stylesheet" th:href="@{/assets/css/stock-display.css}">\n</head>')

p = T+'cart.html'
# Preserve the previously installed saved-cart visibility guard.
condition='visibleCartProductIds.contains(item.product().id())' if 'visibleCartProductIds' in read(p) else 'item.product().active()'
anchor='''<small th:text="${'Đơn giá: ' + #numbers.formatInteger(item.product().price(),3,'POINT') + '₫'}">Đơn giá</small>'''
replace(p,anchor,anchor+'\n          '+stock_badge('small','item.product().stock()','ms-stock-cart',condition))

p = T+'admin/products.html'
replace(p,'<td th:text="${p.stock()}">0</td>', '<td class="ms-admin-stock"><strong th:text="${p.stock()}">0</strong><br>'+stock_badge('small','p.stock()')+'</td>')
# Keep the existing dashboard query, category filtering and order state machine;
# only align the low-stock threshold with what customers see.
replace(J+'repository/AdminAnalyticsRepository.java','p.so_luong_ton BETWEEN 1 AND 5 THEN 1','p.so_luong_ton BETWEEN 1 AND 10 THEN 1')
replace(J+'service/AiAnalysisService.java','so_luong_ton BETWEEN 1 AND 5"','so_luong_ton BETWEEN 1 AND 10"')
p=T+'admin/dashboard.html'
replace(p,'Mẫu sắp hết — còn 1–5 sản phẩm','Mẫu sắp hết — còn 1–10 sản phẩm')
replace(p,'<article><span>Mẫu sắp hết — còn 1–10 sản phẩm</span>','<article th:classappend="${report.stock().low() > 0 ? \'ms-alert-low\' : \'\'}"><span>Mẫu sắp hết — còn 1–10 sản phẩm</span>')
replace(p,'<article><span>Mẫu đã hết hàng</span>','<article th:classappend="${report.stock().out() > 0 ? \'ms-alert-out\' : \'\'}"><span>Mẫu đã hết hàng</span>')
replace(p,'</head>','    <link rel="stylesheet" th:href="@{/assets/css/stock-display.css}">\n</head>')

add(A+'css/stock-display.css','''/* Stock labels: text and color convey the same status. */
.ms-stock{display:inline-flex;align-items:center;gap:5px;max-width:100%;padding:5px 9px;border-radius:7px;font-size:12px;font-weight:700;line-height:1.35;white-space:normal}
.ms-stock::before{content:"";width:7px;height:7px;border-radius:50%;background:currentColor;flex:none}
.ms-stock.ms-stock-ok{background:#e9f4ec;color:#286044}
.ms-stock.ms-stock-low{background:#fff2d8;color:#86500d}
.ms-stock.ms-stock-out{background:#fbe8e5;color:#9f2c27}
.ms-stock-detail{font-size:14px;margin:12px 0;padding:9px 12px;width:fit-content}
.product-content .stock-label.ms-stock{display:flex;width:fit-content;margin:7px 0 0;font-size:11px}
.product-bottom{flex-wrap:wrap;gap:8px}
.ms-stock-cart{display:flex;width:fit-content;margin:5px 0}
.ms-admin-stock{min-width:150px}.ms-admin-stock>strong{font-size:18px}.ms-admin-stock .ms-stock{margin-top:6px;font-size:11px}
.report-kpis article.ms-alert-low{background:#fff2d8;border-color:#e8bc6c}.report-kpis article.ms-alert-out{background:#fbe8e5;border-color:#e4a8a2}
.report-kpis article.ms-alert-low strong,.report-kpis article.ms-alert-low span{color:#86500d}.report-kpis article.ms-alert-out strong,.report-kpis article.ms-alert-out span{color:#9f2c27}
.ms-quantity{display:grid;gap:8px;min-width:0;flex:1}.ms-quantity>label{font-weight:700;font-size:13px;width:auto;max-width:none}
.ms-quantity-control{display:grid;grid-template-columns:42px minmax(48px,72px) 42px;align-items:center;gap:5px;width:max-content;max-width:100%}
.ms-step{width:42px;height:42px;border:1px solid #ded7cd;border-radius:8px;background:#f7f3ed;color:#282d2c;font:700 20px/1 sans-serif;cursor:pointer}
.ms-step:disabled{opacity:.4;cursor:not-allowed}.ms-step:focus-visible{outline:2px solid #b96c43;outline-offset:2px}
.ms-quantity-control .input{width:100%;height:42px;text-align:center;padding:5px;appearance:textfield;margin:0}
.ms-quantity-control input::-webkit-inner-spin-button,.ms-quantity-control input::-webkit-outer-spin-button{appearance:none;margin:0}
.ms-quantity-help{font-size:12px;color:#666d66}.ms-subtotal{display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:14px}.ms-subtotal strong{color:#a65330;font-size:19px;font-variant-numeric:tabular-nums}
.ms-quantity-error{color:#a52626;font-size:12px;margin:0}.ms-quantity-error[hidden]{display:none}
.purchase-add-box .buy-form,.purchase-detail .buy-form,.detail-info .buy-form{flex-wrap:wrap}.detail-info .buy-form .ms-quantity{flex-basis:100%}
''')
add(A+'js/stock-quantity.js','''(() => {
    "use strict";
    const input = document.getElementById("msPurchaseQuantity");
    if (!input) return;
    const wrapper = input.closest(".ms-quantity");
    const subtotal = document.getElementById("msPurchaseSubtotal");
    const error = document.getElementById("msQuantityError");
    const minus = wrapper.querySelector('[data-step="-1"]');
    const plus = wrapper.querySelector('[data-step="1"]');
    const max = Number(input.max);
    const price = Number(wrapper.dataset.unitPrice);
    const format = new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 0 });
    function sync() {
        const n = input.valueAsNumber;
        const unavailable = input.disabled || max < 1;
        const valid = !unavailable && Number.isInteger(n) && n >= 1 && n <= max;
        minus.disabled = unavailable || !valid || n <= 1;
        plus.disabled = unavailable || !valid || n >= max;
        subtotal.textContent = unavailable ? "0 ₫" : valid ? format.format(price * n) + " ₫" : "—";
        error.hidden = unavailable || valid;
        error.textContent = unavailable || valid ? "" : "Vui lòng nhập số nguyên từ 1 đến " + max + ".";
    }
    function step(delta) {
        if (input.disabled || max < 1) return;
        const n = input.valueAsNumber;
        if (!Number.isInteger(n) || n < 1 || n > max) return;
        input.value = String(Math.min(max, Math.max(1, n + delta)));
        sync();
    }
    minus.addEventListener("click", () => step(-1));
    plus.addEventListener("click", () => step(1));
    input.addEventListener("input", sync);
    input.addEventListener("change", sync);
    sync();
})();
''')

if not pending:
    print('Da cap nhat ton kho. Khong can ghi lai.')
    raise SystemExit(0)
backup = Path(tempfile.mkdtemp(prefix='mens-store-stock-backup-',dir=Path.home()))
for path in pending:
    if (root/path).is_file():
        dest = backup/path
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(root/path,dest)
print('Sao luu:',backup)
written=[]
try:
    for path,content in pending.items():
        p=root/path
        p.parent.mkdir(parents=True,exist_ok=True)
        tmp=p.with_name(p.name+'.stock-update.tmp')
        tmp.write_text(content,encoding='utf-8')
        if p.exists(): shutil.copymode(p,tmp)
        os.replace(tmp,p)
        written.append(path)
        print('OK:',path)
except Exception:
    for path in reversed(written):
        if (backup/path).is_file(): shutil.copy2(backup/path,root/path)
        else: (root/path).unlink(missing_ok=True)
    raise
print('Hoan tat. Khong thay doi SQL, .env, gio hang, don hang hay so luong ton hien co.')
