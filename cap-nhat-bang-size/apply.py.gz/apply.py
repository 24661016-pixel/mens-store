#!/usr/bin/env python3
"""Add product-specific reference size guides without changing order or stock data."""
from pathlib import Path
import os, shutil, sys, tempfile

root = Path(sys.argv[1] if len(sys.argv) > 1 else '/workspaces/mens-store/mens-store').resolve()
if not (root/'pom.xml').is_file() or not (root/'compose.yaml').is_file():
    raise SystemExit('Khong tim thay du an: ' + str(root))
J='src/main/java/com/example/mens_store/'
T='src/main/resources/templates/'
A='src/main/resources/static/assets/'
pending={}

def replace(path, old, new):
    s=pending.get(path)
    if s is None: s=(root/path).read_text(encoding='utf-8')
    if new in s: return
    if s.count(old)!=1:
        raise SystemExit('Khong khop phien ban: '+path+'. Chua ghi file nao.')
    pending[path]=s.replace(old,new,1)

def add(path, data):
    if (root/path).is_file():
        if (root/path).read_text(encoding='utf-8')!=data:
            raise SystemExit('File da co noi dung khac: '+path+'. Chua ghi file nao.')
    else: pending[path]=data

add(J+'model/SizeGuide.java', '''package com.example.mens_store.model;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;

/** Reference body measurements only; not a declaration of stocked sizes. */
public record SizeGuide(String title, String introduction, List<String> columns,
                        List<List<String>> rows, String tip, boolean reference) {
    private static final List<String> TOP_COLUMNS = List.of("Size tham khảo", "Vòng ngực (cm)", "Vòng eo (cm)");
    private static final List<List<String>> TOP_ROWS = List.of(
        List.of("S", "84–90", "70–76"), List.of("M", "91–96", "77–82"),
        List.of("L", "97–102", "83–88"), List.of("XL", "103–108", "89–94"),
        List.of("XXL", "109–114", "95–100"));
    private static final List<String> PANTS_COLUMNS = List.of("Size tham khảo", "Vòng eo (cm)", "Vòng mông (cm)");
    private static final List<List<String>> PANTS_ROWS = List.of(
        List.of("28", "70–73", "86–90"), List.of("29", "74–75", "91–93"),
        List.of("30", "76–78", "94–96"), List.of("31", "79–80", "97–99"),
        List.of("32", "81–83", "100–102"), List.of("33", "84–85", "103–105"),
        List.of("34", "86–88", "106–108"), List.of("36", "89–93", "109–113"));
    private static final List<List<String>> SHORT_ROWS = List.of(
        List.of("S", "70–76", "86–93"), List.of("M", "77–82", "94–101"),
        List.of("L", "83–88", "102–107"), List.of("XL", "89–94", "108–113"),
        List.of("XXL", "95–100", "114–119"));

    private static String key(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value, Normalizer.Form.NFD).replaceAll("\\\\p{M}+", "")
            .toLowerCase(Locale.ROOT).replace('đ', 'd');
    }

    private static String fit(Product p) {
        String specifications = p.specifications() == null ? "" : p.specifications();
        for (String line : specifications.split("\\\\R")) {
            if (key(line).startsWith("phom dang:")) return key(line);
        }
        return "";
    }

    private static SizeGuide top(String title, String tip) {
        return new SizeGuide(title, "Đối chiếu vòng ngực và vòng eo cơ thể, đo bằng thước dây, không siết chặt.",
            TOP_COLUMNS, TOP_ROWS, tip, true);
    }
    private static SizeGuide pants(String title, boolean shorts, String tip) {
        return new SizeGuide(title, "Đo vòng eo tại vị trí mặc quần và vòng mông ở phần rộng nhất. Đây là số đo cơ thể, không phải số đo quần.",
            PANTS_COLUMNS, shorts ? SHORT_ROWS : PANTS_ROWS, tip, true);
    }
    private static SizeGuide accessory(String title, List<List<String>> rows, String tip) {
        return new SizeGuide(title, "Chọn theo kích thước sử dụng thay vì size quần áo S–XXL.",
            List.of("Thông số", "Cách kiểm tra"), rows, tip, false);
    }

    public static SizeGuide forProduct(Product p) {
        String n = key(p.name()), c = key(p.categoryName()), f = n + " " + fit(p);
        // Prefer the actual product name. This also covers products added later by admin.
        if (n.contains("that lung")) {
            String width = key(p.specifications()).contains("ban day: 3,2 cm")
                ? "3,2 cm theo mô tả mẫu" : "Đối chiếu chiều rộng đỉa quần";
            return accessory("Kích thước thắt lưng", List.of(
                List.of("Bản dây", width),
                List.of("Vòng eo khi đeo", "Đo qua vị trí thắt lưng trên quần"),
                List.of("Chiều dài phù hợp", "So từ chân khóa đến lỗ giữa của dây đang dùng")),
                "Chiều dài dây thực tế chưa được xác nhận trong bảng này. Hỏi cửa hàng trước khi đặt.");
        }
        if (n.contains("non ") || n.contains("mu ") || n.contains("luoi trai")) {
            return accessory("Kích cỡ nón", List.of(
                List.of("Vòng đầu", "Đo quanh trán, trên tai khoảng 1–2 cm"),
                List.of("Dải điều chỉnh", "So số đo vòng đầu với dải điều chỉnh thực tế")),
                "Không mặc định nón vừa mọi vòng đầu; cần xác nhận dải điều chỉnh với cửa hàng.");
        }
        if (n.contains("tui ") || n.contains("tote")) {
            return accessory("Kích thước túi", List.of(
                List.of("Rộng × cao", "So kích thước vật cần mang với lòng túi"),
                List.of("Độ sâu đáy", "Kiểm tra bề dày vật dụng"),
                List.of("Quai túi", "Kiểm tra độ dài để xách tay hoặc đeo vai")),
                "Kích thước và tải trọng thực tế chưa được xác nhận; liên hệ cửa hàng nếu cần vừa laptop hoặc tài liệu A4.");
        }
        if (n.contains("quan ") || c.equals("quan nam")) {
            if (n.contains("short")) return pants("Bảng size quần short", true, "Đo thêm dài quần và vòng đùi; chọn vị trí gấu phù hợp sở thích.");
            if (n.contains("jeans")) return pants("Bảng size quần jeans", false, "Kiểm tra thêm chiều dài ống, cạp và độ co giãn denim; số size chỉ là gợi ý.");
            if (n.contains("cargo")) return pants("Bảng size quần cargo", false, "Chừa khoảng cử động ở đùi và đầu gối. Đo thêm dài ống.");
            if (n.contains("chino")) return pants("Bảng size quần chino", false, "Đối chiếu thêm vòng đùi và dài ống với quần vừa người.");
            return pants("Bảng size quần nam", false, "Đối chiếu thêm vòng đùi, cạp và dài quần theo phom thực tế.");
        }
        if (n.contains("hoodie")) return top("Bảng size áo hoodie", "Phom rộng đã có độ dư theo thiết kế; thử thêm lớp áo bên trong, so chiều dài thân và tay. Không tự tăng size chỉ vì tên oversize.");
        if (n.contains("bomber")) return top("Bảng size áo bomber", "So rộng vai, dài tay và khoảng trống cho lớp áo bên trong.");
        if (n.contains("cardigan")) return top("Bảng size áo cardigan", "Chọn theo vòng ngực và lớp áo mặc trong; kiểm tra dài tay, dài thân và độ giãn thực tế.");
        if (n.contains("ao khoac") || c.equals("ao khoac")) return top("Bảng size áo khoác", "Đo thêm rộng vai và dài tay; chừa khoảng trống cho lớp áo bên trong.");
        if (n.contains("so mi") || c.equals("so mi")) {
            String tip = n.contains("linen") || f.contains("relaxed")
                ? "Phom relaxed: giữ khoảng rộng nhẹ; đối chiếu vai, dài tay và độ thoải mái khi cài cúc."
                : "Đo thêm rộng vai, dài tay và vòng cổ nếu cài cúc cổ; không chọn áo quá ôm.";
            if (n.contains("denim")) tip += " Nếu khoác ngoài áo thun, kiểm tra khoảng rộng cho lớp trong.";
            return top("Bảng size sơ mi" + (n.contains("linen") ? " linen" : n.contains("denim") ? " denim" : n.contains("oxford") ? " Oxford" : ""), tip);
        }
        if (n.contains("polo") || c.equals("ao polo")) {
            boolean slim = f.contains("slim");
            return top("Bảng size áo polo" + (slim ? " slim fit" : ""), slim
                ? "Phom slim ôm nhẹ: nếu số đo sát ranh giới hai size, đối chiếu ngực và bắp tay, ưu tiên cử động thoải mái."
                : "Phom regular: đối chiếu rộng vai, bắp tay và dài áo; kiểm tra độ vừa ở cổ.");
        }
        if (n.contains("ao thun") || c.equals("ao thun")) {
            if (f.contains("oversize")) return top("Bảng size áo thun oversize", "Dáng rộng đã có độ dư; chọn theo số đo cơ thể, so thêm ngang ngực và dài áo đang mặc. Không cần tự tăng size.");
            if (f.contains("relaxed") || n.contains("graphic")) return top("Bảng size áo thun relaxed", "Dáng rộng nhẹ; đối chiếu ngang ngực, vai và dài áo để không quá dài.");
            return top("Bảng size áo thun regular", "Đo thêm rộng vai, ngang ngực và dài áo đang mặc vừa để so với sản phẩm thực tế.");
        }
        return accessory("Hướng dẫn chọn kích cỡ", List.of(
            List.of("Kích thước cần biết", "Xem mô tả và thông số của sản phẩm"),
            List.of("Đối chiếu", "So số đo thực tế hoặc hỏi cửa hàng")),
            "Chưa có bảng số đo riêng cho loại sản phẩm này; không tự suy ra size.");
    }
}
''')

ctrl=J+'controller/ShopController.java'
replace(ctrl, '''        model.addAttribute("product", shop.activeById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND)));''', '''        var product = shop.activeById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        model.addAttribute("product", product);
        model.addAttribute("sizeGuide", com.example.mens_store.model.SizeGuide.forProduct(product));''')

p=T+'detail.html'
replace(p, '    <strong class="detail-price"', '''    <a class="ms-size-jump" href="#ms-size-guide">Xem bảng size &amp; cách đo ↓</a>
    <strong class="detail-price"''')
replace(p, '''    <section class="info-panel">
      <h3>Giữ món đồ mặc được lâu hơn</h3>''', '''    <section th:replace="~{size-guide :: guide(${sizeGuide})}"></section>
    <section class="info-panel">
      <h3>Giữ món đồ mặc được lâu hơn</h3>''')
replace(T+'fragments.html', '<link rel="stylesheet" th:href="@{/assets/css/style.css}">', '''<link rel="stylesheet" th:href="@{/assets/css/style.css}">
    <link rel="stylesheet" th:href="@{/assets/css/size-guide.css}">''')
add(T+'size-guide.html', '''<!DOCTYPE html>
<html lang="vi" xmlns:th="http://www.thymeleaf.org">
<body>
<section id="ms-size-guide" class="ms-size-guide" th:fragment="guide(g)" aria-labelledby="ms-size-title">
  <div class="ms-size-kicker">MENS STORE / SIZE GUIDE</div>
  <h2 id="ms-size-title" th:text="${g.title()}">Bảng size</h2>
  <p class="ms-size-intro" th:text="${g.introduction()}"></p>
  <div class="ms-size-table-wrap" tabindex="0" role="region" aria-label="Bảng kích cỡ sản phẩm">
    <table class="ms-size-table">
      <caption class="ms-size-caption" th:text="${g.reference() ? 'Gợi ý theo số đo cơ thể (cm)' : 'Thông số cần đối chiếu'}"></caption>
      <thead><tr><th scope="col" th:each="column : ${g.columns()}" th:text="${column}"></th></tr></thead>
      <tbody><tr th:each="row : ${g.rows()}">
        <th scope="row" th:text="${row[0]}"></th>
        <td th:each="cell, stat : ${row}" th:if="${!stat.first}" th:text="${cell}"></td>
      </tr></tbody>
    </table>
  </div>
  <div class="ms-size-tip"><strong>Cách chọn vừa người</strong><p th:text="${g.tip()}"></p></div>
  <p class="ms-size-disclaimer" th:if="${g.reference()}">Bảng số đo minh họa để tham khảo, không phải số đo đã xác nhận của mẫu hoặc size đang có hàng. Nếu giữa hai size, hãy đối chiếu phom và số đo thực tế của cửa hàng.</p>
  <p class="ms-size-note">Khi đặt hàng, ghi size/kích thước mong muốn ở phần ghi chú. Cửa hàng cần xác nhận size thực tế trước khi giao.</p>
</section>
</body>
</html>
''')
add(A+'css/size-guide.css', '''/* Product-specific size guide; isolated from purchasing and admin styles. */
.ms-size-jump{display:block;width:fit-content;margin:8px 0 14px;color:#a75932;font-weight:700;font-size:14px;text-decoration:underline;text-underline-offset:3px}
.ms-size-guide{scroll-margin-top:105px;margin:20px 0;padding:20px;background:#fff;border:1px solid #e6ded4;border-radius:16px;color:#262b2b;min-width:0}
.ms-size-kicker{font-weight:800;letter-spacing:.12em;font-size:10px;color:#9c5936;margin-bottom:7px}
.ms-size-guide h2{margin:0 0 9px;font-size:21px;line-height:1.25}
.ms-size-intro,.ms-size-note,.ms-size-disclaimer{font-size:13px;line-height:1.55;color:#626862;margin:8px 0 12px}
.ms-size-table-wrap{overflow-x:auto;border:1px solid #e6ded4;border-radius:10px;max-width:100%}
.ms-size-table-wrap:focus-visible{outline:2px solid #a75932;outline-offset:3px}
.ms-size-table{width:100%;min-width:270px;border-collapse:collapse;font-size:13px;line-height:1.45}
.ms-size-caption{caption-side:top;text-align:left;padding:9px 12px;font-size:12px;color:#646962;background:#faf7f2}
.ms-size-table th,.ms-size-table td{padding:10px 9px;text-align:left;border-bottom:1px solid #ece6df;vertical-align:top;white-space:normal}
.ms-size-table thead th{background:#282c2b;color:#fff;font-size:12px;font-weight:700}
.ms-size-table tbody th{font-weight:800;color:#202624}
.ms-size-table tbody tr:nth-child(even){background:#faf8f4}
.ms-size-table tbody tr:last-child>*{border-bottom:0}
.ms-size-tip{margin-top:13px;background:#f4efe7;border-radius:10px;padding:12px;font-size:13px;line-height:1.5}
.ms-size-tip p{margin:4px 0 0}
.ms-size-disclaimer{color:#805321;margin:12px 0 0}
.ms-size-note{margin:10px 0 0}
@media(max-width:600px){.ms-size-guide{padding:13px}.ms-size-table th,.ms-size-table td{padding:8px 6px}.ms-size-guide h2{font-size:19px}}
''')

if not pending:
    print('Da cap nhat, khong can ghi lai.')
    raise SystemExit(0)
backup=Path(tempfile.mkdtemp(prefix='mens-store-size-backup-',dir=Path.home()))
for path in pending:
    if (root/path).is_file():
        target=backup/path; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(root/path,target)
print('Sao luu:', backup)
written=[]
try:
    for path,data in pending.items():
        p=root/path; p.parent.mkdir(parents=True,exist_ok=True)
        tmp=p.with_name(p.name+'.size-update.tmp'); tmp.write_text(data,encoding='utf-8')
        if p.exists(): shutil.copymode(p,tmp)
        os.replace(tmp,p); written.append(path); print('OK:',path)
except Exception:
    for path in reversed(written):
        if (backup/path).is_file(): shutil.copy2(backup/path,root/path)
        else: (root/path).unlink(missing_ok=True)
    raise
print('Hoan tat bang size. Khong thay doi SQL, gio hang, ton kho, don hang hay .env.')
